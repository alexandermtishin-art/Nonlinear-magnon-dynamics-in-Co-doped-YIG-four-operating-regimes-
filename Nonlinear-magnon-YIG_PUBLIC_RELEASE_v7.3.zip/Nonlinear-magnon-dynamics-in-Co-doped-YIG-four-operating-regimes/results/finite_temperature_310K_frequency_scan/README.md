# Finite-temperature frequency scan at 310 K

This directory contains the completed static-effective-pair-drive Lindblad scan

`H = Omega n + U a†²a² + (eta Omega / 4)(a†² + a²)`

with `Omega=1`, `eta=1.2`, `alpha=1e-3`, `kappa=0.002`, `U=0.55`, `N=140`, vacuum initial state, and a thermal bath defined by the physical frequency.

- `raw_U_0p55_runs_26_38/` contains the original completed outputs for 0.5-10 THz.
- `room_temperature_6_to_10_THz/` contains the verified 6, 7, 8, 9, and 10 THz subset requested for the public archive.
- `finite_temperature_frequency_scan_310K_combined.csv` combines the available U=0.10 and U=0.55 frequency series for plotting.

Important: these results use the static effective pair drive and `alpha=1e-3`. They must not be numerically identified with the explicitly resonant phase-encoding protocol, which uses a different drive and can produce a much larger `|<aa>|`.
