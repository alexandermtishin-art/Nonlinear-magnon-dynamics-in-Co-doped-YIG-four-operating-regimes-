# Current numerical results used in the manuscript

Canonical protocol: resonant time-dependent pair drive; `U_audit=0.55`, `eta=1.2`, `alpha=0.001`, `kappa=0.002`; Kerr convention `(U_audit Omega/2) a†²a²`.

**Convention note (v6).** The manuscript writes the Kerr term as `U Omega a†²a²`
(Eq. 4), so the runs in this table are labelled `U_audit` and convert as
`U = U_audit/2`; the representative resonant point `U_audit = 0.55` is
`U = 0.275`. The conversion is checked against the dynamics: the mean-field
balance predicts a saturated occupation `eta/(4U) = 1.09`, against `1.213`
returned by the full Lindblad calculation (11 %), whereas reading `U_audit`
directly as `U` would predict `0.545`. The 310 K frequency scan of
`results/canonical_convention/` uses the same audit normalization and its `U = 0.10` and `U = 0.55` are
`U_audit` values, converting as `U = 0.05` and `U = 0.275`. Every calculation
behind the current manuscript is in the audit normalization; the direct
normalization `U a^d2 a^2` survives only in superseded runs and in the
1000-cycle calculation of Fig. 3, whose `U = 0.1` is already an Eq. (4) value.
The confined range actually demonstrated is therefore `U = 0.05-0.40` in Eq. (4)
units.

**Frequency-scan basis (v6.5).** The scan uses an adaptive Fock basis chosen at
each frequency from the occupancy reached, with every point repeated at 1.2N:
`N = 209` at 50 GHz (repeat 250, top-ten population 2.5e-6, worst relative
change 4.6e-5), 121 at 100 GHz, 77 at 200 GHz, 45 at and above 700 GHz. The
fixed 140-level basis quoted in earlier releases belongs to the superseded
runs 26-38.

**Microscopic values (v6).** `N_eff = M_s V/(g mu_B) = 3.0e4` for the
20 x 20 x 10 nm cell; `U = omega_a/(2 N_eff Omega) = 6.6e-5` at a 50 GHz
carrier with `K_u = 5e5 J/m^3`; equivalently `K = hbar gamma^2 K_u/(M_s^2 V)`,
`K/2pi = 3.3 MHz`. Necessary criterion `alpha N_eff < omega_a/Omega`, i.e.
`N_eff < 1/alpha` at `omega_a = Omega`: `alpha < 9.7e-5` at 50 GHz
(`V >= 1370 nm^3`) and `alpha < 3.9e-4` at 200 GHz (`V >= 342 nm^3`).
Parametric threshold `eta > 2 alpha` (growth rate `h = eta Omega/2` against
amplitude decay `kappa/2 = alpha Omega`), upper bound `eta < 4U`.

| Regime | Basis N | sigma (deg) | two-sided Gaussian-equivalent BER | status |
|---|---:|---:|---:|---|
| Regime I (4 K, 50 GHz) | 80 | 22.439862 | 6.053390e-05 | no convergence warning from current checks |
| Regime II (77 K, 50 GHz) | 120 | 29.947978 | 2.653965e-03 | no convergence warning from current checks |
| Regime III (310 K, 6 THz) | 80 | 26.140693 | 5.754951e-04 | no convergence warning from current checks |
| Regime IV (310 K, 50 GHz) | 240 | 40.705036 | 2.703386e-02 | basis truncation warning: max top10 > 1e-6 |

Important: the Regime IV value is numerically stable in sigma (N=200 to 240 changes by 0.00718 deg), but the archived diagnostic still flags the top-ten-level population at N=240 as above 1e-6. Quote the sigma with this basis-tail qualification in the reproducibility record.
