# Changelog

## 2026-08-03 public-release v5

- Added the full multimode Lindblad calculation for Regime III, which replaces
  the mean-field estimate of v4. It is solved in the excitation-number-restricted
  basis with the modes at their true level spacing, and reaches M = 8 via quantum
  trajectories. Script in `scripts/multimode/`, results in
  `results/multimode_quantum/`.
- Two controls pass: the M = 1 case reproduces the frequency scan of Fig. 10 to
  five digits, and at M = 4 the master equation and 400 trajectories agree to 1 %.
- Result: co-driven neighbours leave the two-level population intact (0.925 ->
  0.972) but suppress the pair correlation, |<aa>| falling from 0.393 to 0.128 at
  M = 8 and following M^-1.31 to within 4 %. The mechanism is cross-Kerr detuning,
  not leakage: a spatially uniform pump transfers no quanta between modes.
- Section 3 of the manuscript updated accordingly. The statement that a full
  multimode treatment "is required" has been replaced by what that treatment
  shows; the extrapolation to 589 modes is marked as an indication of direction
  rather than a result.
- Reference [3] updated from the arXiv preprint to Physica B: Condensed Matter
  (2026), in press.
- Rebuilt MANIFEST.txt and SHA256SUMS.txt.

## 2026-08-03 public-release v4

- Recomputed the 310 K frequency scan in the canonical Kerr convention
  `(U Omega/2) a^d2 a^2`; 17 points, all converged. Table 3 no longer mixes
  normalizations. New numbers at 6 THz: P0+P1 = 0.9254, <n> = 0.2452,
  |<aa>| = 0.3933.
- Recomputed the Fig. 4 U scan in the same convention; the archived
  `U_scan_quantum.csv` was in the legacy `U n^2` convention and is retained
  only for reference.
- Added the micromagnetic normal-mode analysis, which finds no mode localised
  enough to supply U = 0.1-0.55, and the exchange bound that explains why.
- Added the multimode analysis: the single-mode treatment holds on the 50 GHz
  carrier (IPR = 1.0) and fails at 6 THz (589 modes above threshold, IPR = 53).
- Added the U dependence of the pair-phase transfer, which is kinematic and
  unchanged down to U = 0.02.
- Regenerated all 15 figures with the current generator; added a numerical
  cross-check script for the manuscript.
- Rebuilt MANIFEST.txt and SHA256SUMS.txt.

## 2026-08-01 public-release v3

- Replaced the manuscript and Supplementary Information with the current FINAL Word files.
- Replaced all figure files with the complete PRM Q1/APS-style set (Fig. 1-11 and Fig. S1-S4).
- Added one script that regenerates all figures, its layout audit, and all associated CSV data.
- Added the final corrected notebook.
- Added completed low-damping pair-phase results at alpha=0.001:
  sigma = 22.440 deg (I), 29.948 deg (II), 26.141 deg (III), and 40.705 deg (IV).
- Retained the alpha=0.01 package only as clearly marked legacy material.
- Regenerated manifest and SHA-256 checksums.

## 1.0.0 — 2026-07-24

- Archived legacy notebooks and available manuscript figures.
- Added matched static-versus-resonant protocol audit.
- Added Bogoliubov–Lindblad occupation bridge and anomalous-correlator convention audit.
- Added checkpointed exploratory U–eta scan.
- Added five-phase pair-control test.
- Rewrote Supplementary Information to remove unsupported numerical claims and separate protocol-dependent results.

## 2026-07-24 - phase-control update

- Added stationary five-phase pair-control results and final Figure 5.
- Added `phase_step_test_v2.py`, which uses complex-plane extraction and supersedes the phase-unwrapping response analysis.
- Retained v1 as `phase_step_test_v1_deprecated.py` for provenance with an explicit warning.
- Added final Figure 4, Figure 5, and supplementary step-response figure.
- Added `make_final_figures.py` and a script-level README.
- Updated Supplementary Information with the measured stationary phase transfer and dynamical step-response limits.

## 2026-07-28 public-package update
- Added latest PRM manuscript and revised Supplementary Information.
- Added completed finite-temperature frequency scan through 10 THz.
- Added verified 6-10 THz raw JSON and CSV subset.
- Added combined publication figure and plotting table.
- Added archive audit and protocol-separation warning.
- Retained incomplete run-21 package only under legacy provenance.

## 2026-07-28 final public-package rebuild
- Replaced the earlier Supplementary Information snapshot with `Supplementary_Information_PRM_final.docx` and its PDF rendering.
- Matched the Supplementary Information title to the PRM manuscript title.
- Added Supplement 8 documenting the 310 K thermal Lindblad model, the Kerr-convention boundary, verified 6–10 THz values, and Figure S4.
- Added accessibility metadata for figures and repeating table-header rows.
- Regenerated manifest and SHA-256 checksums and revalidated the complete ZIP.

## v6 — 2026-08-15: spin-count convention, parametric threshold, manuscript rebuild

**The effective spin content is now the net macrospin.** Releases up to v5 used
`N_eff = S * N_ion` in `scripts/micromagnetics/mode_bound.py` and the
formula-unit count in `micromagnetic_modes.py`; the manuscript used a third
value, `6.0e4 * 5/2 = 1.5e5`, in which `6.0e4` was the magnetic moment in Bohr
magnetons mislabelled as an Fe(3+) ion count (the cell actually contains
8.4e4 Fe(3+) ions). All three are superseded by

    N_eff = M_s V / (g mu_B) = 3.0e4  for the 20 x 20 x 10 nm cell,

the net angular momentum of the mode volume. The uniform mode of a saturated
ferrimagnet is a single macrospin `S_z = M_s V/(gamma hbar)` and only the
uncompensated moment enters the acoustic branch. The choice is settled without
reference to any spin count by deriving the Kerr coefficient directly from the
anisotropy energy, `K = hbar gamma^2 K_u/(M_s^2 V)`, which reproduces
`omega_a/(2 N_eff)` exactly with the net count and is the standard
cavity-magnonics result. Consequences: `U = 6.6e-5` rather than `1.3e-5` for
the uniform mode; the most localised computed mode gives `N_eff = 7.7e3` and
`U = 2.6e-4` rather than `3.1e3` and `6.5e-4`; a mode of the required spin
content is 0.8-1.7 nm across at 5-22 THz rather than 0.5-0.8 nm at 22-64 THz.
Both micromagnetics scripts were patched and re-run; their outputs are archived
under `results/micromagnetics/`.

**The parametric threshold was off by a factor of two.** For a pair drive
`G (a^d2 + a^2)` the amplitude growth rate is `2G`, not `G`. With `G = eta
Omega/4` the growth rate is `h = eta Omega/2`, and against the amplitude decay
`kappa/2 = alpha Omega` the threshold is `eta > 2 alpha`, not `eta > 4 alpha`.
The saturation bound is unaffected: the nonlinear detuning is `2 U Omega n`,
not `U Omega n`, and the two factors of two cancel in `n_sat = eta/(4U)`, so
`eta < 4U` stands. The drive window is therefore `2 alpha < eta < 4U` and the
necessary material condition is `alpha < 2U`, i.e. `alpha N_eff < omega_a/Omega`.

**Kerr normalization made explicit.** The manuscript convention is
`H/hbar = Omega n + U Omega a^d2 a^2 + G (a^d2 + a^2)` (Eq. 4). Runs performed
with `(U_audit Omega/2) a^d2 a^2` are labelled `U_audit` throughout and convert
as `U = U_audit/2`. The conversion is verified against the computed dynamics
rather than asserted: `eta/(4U) = 1.09` at `U = 0.275` against the Lindblad
value `1.213`.

**Manuscript rebuilt.** New title and abstract; the architectural projection
layer (throughput, CMOS comparison, array power, compute-window scalability)
removed, since none of it is an output of the single-mode model; Figure 11 and
its data retired to `legacy/removed_from_manuscript_v6/`; ten main figures
remain; tables renumbered 1-4 after the removal of the demonstrated-versus-
projected table; reference list corrected for two orphaned entries and the
anisotropy value now carries its source. The PRM submission is retained under
`legacy/manuscript_PRM_2026-08/`.

**Result of all this.** The necessary criterion is now *satisfied* by good
garnet at both carriers, and the mechanism remains unavailable: the admissible
drive window sits at `eta ~ 1e-4`, three to four orders of magnitude below the
`eta = O(1)` that makes the transition non-adiabatic, and the Kerr coefficient
available is three orders below the range at which confinement appears.

### v6.1 — same day, consistency sweep of the manuscript

Five residues of the pre-v6 physics were still present in the manuscript body
and contradicted the corrected abstract and conclusions:

- Section 7 still stated the criterion as `N_eff < 1/(2 alpha)` and gave the
  three experimental bounds computed from it (three spins for as-grown Co:YIG,
  500 spins at `alpha = 1e-3`, 440 nm^3 at the best reported damping). These
  become `N_eff < 1/alpha` and, at the net spin density 7.5 nm^-3: `N_eff < 7`
  (under 1 nm^3), `N_eff < 1e3` (132 nm^3, 5.1 nm cube) and 3400 nm^3 (15 nm
  cube), the last of which leaves an open interval against the 1370 nm^3
  thermal-stability floor at 50 GHz.
- Section 7 also still closed with "fails at 50 GHz and is marginal at
  200 GHz", the pre-v6 conclusion. Rewritten to the current one.
- Section 2 gave the Fock ladder as `E_n = Omega n + U n(n-1)` and
  `Delta E_12 = Omega + 2U`, which is dimensionally inconsistent with a
  dimensionless `U`. Now `E_n = Omega[n + U n(n-1)]` and
  `Delta E_12 = Omega(1 + 2U)`.
- Section 5.1 still opened with the intermediate count `N = M_s V/mu_B`
  (6e4 "spins"). Removed; the paragraph now only fixes `M_s`, `K_u` and
  `omega_a` and hands over to the macrospin definition.
- The Bogoliubov-Lindblad bridge paragraph reverted to `U` for the audit
  normalization. Relabelled `U_audit` with the conversion stated inline, in
  agreement with Supplement S2.2.
- Supplement title updated to the general criterion.

### v6.2 — mechanical residues of the v6 rebuild

- A stray `3.0 × 10^4` had been substituted for the em dash in the first
  paragraph of the Introduction ("stabilized by the anharmonicity of the medium
  itself — the Kerr-type four-magnon frequency shift"). Restored.
- Two cells of the specification table still carried plain-text subscripts
  (`K_u V/kT`, `Ω/2πN_cyc`); set as true subscripts.
- Full mechanical sweep of the rendered PDF: no doubled tokens, no residual
  markup characters, no digits inserted into running text, em- and en-dash
  counts back to the original plus the one dash added by the v6.1 edits.

### v6.3 — copy-editing pass on the manuscript body

Eight local text defects, most predating the v6 rebuild:

- `The u(t) and v(t) represent ...` — missing head noun; now `The amplitudes
  u(t) and v(t) ...`.
- `Adopting an operating frequency Omega ~ 2 pi x 50 GHz ...` was a sentence
  fragment; merged with the damping clause that follows it.
- `alpha << 1/(Omega tau_cycle)^-1` was a double inverse; now
  `alpha << (Omega tau_cycle)^-1`.
- An orphan fragment `rate alphaOmega(t).` stood immediately after Eq. (5),
  left over from an earlier cut; removed and the sentence completed.
- `a^d2 a^2` appeared with plain digits in the Fig. 4 caption and in the parity
  paragraph; set as true superscripts, and the Fig. 4 caption now labels the
  audit normalization `U_audit` in line with the rest of the paper.
- `reliable state formation transition` — noun disagreement; now `reliable
  state transition`.
- `Delta E` in Section 7 used the Greek capital epsilon U+0395 instead of a
  Latin E. A full homoglyph scan (Greek and Cyrillic capitals that mimic Latin
  letters) now returns nothing.
- Spaces before punctuation in four places, and a stray hyphen at the end of
  the repository URL in the data-availability statement.

### v6.4 — equation objects restored, two Section 7 sentences repaired

- The Holstein-Primakoff/LLG mapping paragraph in Section 7 lost its seven
  OMath equation objects during the v6.3 copy-editing pass: the helper that
  performs run-level text substitution rebuilt the paragraph from its `w:r`
  children only and dropped everything between them. The paragraph has been
  restored from the pre-rebuild source; the seven equation objects are now
  byte-identical to the original, and the helper has been corrected so that
  non-run children (equations, drawings, bookmarks, field codes) are preserved
  verbatim. A whole-document count confirms 16 equation objects against 16 in
  the source, and 10 drawings against 11 (Figure 11 having been retired).
- `... the two levels of description are consistent: while long-term stability
  is governed by ...` was an unfinished sentence predating the rebuild; the
  first clause has been supplied.
- The condition of the Holstein-Primakoff expansion was written `... angles
  2S)` with no opening parenthesis, also predating the rebuild; now
  `... angles (<a^d a> << 2S)`.

Note on rendering: the equation objects in this paragraph do not display in
LibreOffice-based DOCX-to-PDF conversion, which silently drops `m:acc` and
`m:rad` constructs. They render correctly in Word. Text extracted from a
LibreOffice-produced PDF will therefore show gaps at these equations; this is a
converter limitation and not a defect of the document. The same gaps are
present when the pre-rebuild source is converted the same way.

### v6.5 — the archived data corrects the convention and the basis

Reading the archived run outputs rather than the prose describing them turned
up two statements that were wrong in v6.0-v6.4, including in text added during
the v6 rebuild.

**Every calculation behind the manuscript is in the audit normalization.**
`scripts/canonical_convention/colab_frequency_scan_canonical.py` line 220,
`rescan_U.py` line 20, `phase_vs_U.py` line 19, `five_phase_control.py` line 10
and `phase_step_test_v2.py` line 65 all integrate
`H = Omega n + 0.5*U*Omega a^d2 a^2 + ...`, and the scan report header states
the same. The claim that the 310 K frequency scan was already written in the
Eq. (4) convention and needed no conversion was therefore wrong: it is
`U_audit` like everything else. The direct normalization `U a^d2 a^2` survives
only in the superseded runs 21-38 and in the 1000-cycle calculation of Fig. 3
of the main text.

Consequence: the confined range actually demonstrated is `U = 0.05-0.40` in
Eq. (4) units, not `0.05-0.55`; the kinematic pair-phase floor is `U = 0.01`
(`U_audit = 0.02`), not `U = 0.02`; the Regime III runs are `U = 0.05-0.275`.
The shortfall against the delivered `U = 6.6e-5` is 760x to 6100x, so the
"three orders of magnitude" statement stands unchanged.

**The frequency-scan basis is adaptive, not fixed.** `N = 209` at 50 GHz,
121 at 100 GHz, 77 at 200 GHz, 62 at 300 GHz, 50 at 500 GHz and 45 at and above
700 GHz, each point repeated at 1.2N. The fixed 140-level basis described in
Supplement 8.1 belongs to the superseded runs 26-38, whose numbers differ (at
6 THz `P0+P1 = 0.9593` and `<n> = 0.1643` against 0.9254 and 0.2452). The
main-text change from `N = 45` to `N = 140` made in v6.0 was therefore in the
wrong direction and has been replaced by an accurate description of the
adaptive scheme.

**Low-frequency convergence is measured, not estimated.** The a priori
thermal-tail argument added in v6.0 has been replaced by the archived values:
at 50 GHz the top-ten-level population is 2.5e-6 and the largest relative
change of any reported observable between `N = 209` and `N = 250` is 4.6e-5.

Also in this release, from an external review of the Supplementary Information:
S1.2 now states the scope of the conversion explicitly and no longer switches
between `U` and `U_audit` mid-paragraph; S2.2 states why the coefficient in the
reduced equations is twice the Hamiltonian pair coefficient
(`[a, a^d2] = 2 a^d`); S3 no longer refers to a "legacy Figure 3"; S4 claims
agreement of the time-averaged occupation at the 8 % level rather than
"quantitative consistency".

The development notebook has been moved to `legacy/` with a note: it still
contains cells from the removed architectural layer (`yield_pct`,
`victorious_yield_audit`, throughput), none of which is claimed anywhere.

### v6.6 — the criterion is demoted from theorem to screening rule

**The paper's own Lindblad calculation contradicted the word "necessary".**
Fig. 3 runs the static effective drive at `U = 0.1` (Eq. 4 convention),
`eta = 1.2`, so that the saturation balance predicts `eta/(4U) = 3`. The
archived output (`results/figure_data/figure3_final_fock.csv`) gives a
late-time `<n> = 0.176` with `P0+P1 = 0.9517` over 1000 cycles. The upper bound
`eta < 4U` is therefore violated threefold while the state remains confined,
and it cannot be presented as a necessary condition.

The two bounds are not of equal standing, and the manuscript now says so. The
lower bound `eta > 2 alpha` is the exact linear parametric threshold. The upper
bound comes from the mean-field balance of Section 5.3, whose accuracy is
protocol-dependent: it reproduces the resonantly modulated occupation to 11 %
(1.09 predicted against 1.213 computed) but overestimates the static effective
drive by an order of magnitude. `alpha N_eff < omega_a/Omega` is accordingly
presented as a mean-field materials screening criterion, not a theorem. Title,
abstract, introduction, Section 8 and conclusions were rewritten.

**Eight legacy contradictions removed**, all predating or surviving the v6
rebuild:

- Section 5.1 still ended with "a quantitative mapping ... which we do not
  attempt here; establishing this mapping is left for future work" -- the exact
  opposite of the paper's central result. Replaced by a pointer to the mapping.
- "noise floor is set by hbar Omega / k_B T alone" contradicted Section 6.3,
  where raising the damping from 1e-3 to 1e-2 lowers sigma from 22.4 to 17.9
  degrees at 4 K and from 26.1 to 15.5 at 6 THz. Now stated as an ordering set
  by the temperature ratio with a damping- and protocol-dependent magnitude.
- "Regime III is experimentally accessible with existing apparatus" contradicted
  the multimode analysis of Section 6.4. Now: the excitation is available, the
  isolated mode is not established.
- 26.1 degrees was called smaller than Regime I's 22.4 degrees.
- The 50 GHz gain band was described as containing "two confined modes" in one
  place and one in another.
- "quantum eta-algorithm" survived one deletion pass.
- A passive-cooling paragraph claimed a "thermodynamic verification" with its
  method "in the Supplementary Material"; no such calculation exists there, and
  S6 states that passive-cooling figures are not validated outputs. Deleted.
- A Gaussian +/-5 % dispersion assessment with a "safety margin of more than
  600 %" had no archived script or output; S1.4 excludes undocumented
  Monte-Carlo claims from the validated results. Replaced by what Fig. 9
  actually shows.
- `U = 0.55`, `0.12` and `0.08` in the main text are audit-convention values and
  are now labelled `U_audit` throughout, as in the Supplementary Information.

Document filenames in `docs/` now carry the release number.

### v6.7 — residual labels of the demoted criterion

No new physics issue in this pass; four version-control tails from v6.6 and a
convention sweep.

- The Supplementary Information still carried the old title with "the necessary
  criterion". It now repeats the main title verbatim.
- The abstract closed the phase-noise sentence with "a structural limit that
  does not respond to optimization of the material or the drive", one line after
  stating that the absolute magnitude is damping- and protocol-dependent.
  Replaced: the ordering of the four regimes is set by the thermal occupation,
  the absolute values are not and improve with stronger damping.
- "A necessary material condition can be satisfied ..." in the conclusions and
  "the necessary condition that follows from the drive window" in Section 8
  reinstated the theorem status the title had just given up. Both now say
  screening condition.
- Section 5.2 said the requirement `N_eff < 1/alpha` "bounds the confined
  regimes"; it now says the mean-field screening rule applies to the
  confined-regime estimate.

**Convention sweep.** Fifteen further bare `U` values that are audit-convention
numbers were relabelled `U_audit`, including the captions of Figs. 5, 6 and 10
and the sigma note of Table 2. Section 5.1 now states the scope once: Figs. 4-6,
the protocol audit, the five-phase and phase-step protocols, the semiclassical
stress test and the 310 K scan are all `(U_audit Omega/2) a^d2 a^2`; Fig. 3 uses
`U Omega a^d2 a^2` directly, so its `U = 0.1` is an Eq. (4) value; Figs. 1 and 2
use the earlier `U n^2` form, which differs from both by an additional linear
shift and is retained only because those figures establish boundedness rather
than a value. A mechanical search now returns no bare `U = 0.55`, `U ~ 0.12` or
`does not respond to optimization` anywhere in the manuscript.

Document integrity after the pass: 16 equation objects and 10 drawings, matching
the source less the retired Figure 11; no residual markup characters.

### v6.8 — final consistency pass on the manuscript

Six corrections, two of them numerical.

- **`xi` was still quoted in audit units.** `xi = eta/U` is defined with the
  Eq. (4) coefficient, but the values given were `xi = 10` at the analytic
  crossover and `xi = 2.2` at the representative point, computed from
  `U_audit`. With `U = U_audit/2` these become `xi = 20` (`U = 0.06`) and
  `xi = 4.4` (`U = 0.275`). Corrected in Section 2 and Section 5.3. The related
  statement that bounded dynamics are demonstrated "in the regime `xi = O(1)`"
  is now "for `xi` between about four and twenty", and Section 4 now asks for
  the saturated occupation `xi/4` to be of order unity rather than `xi` itself
  — at the representative point `xi/4 = 1.09`, which is what the resonant
  Lindblad calculation returns (1.213).
- **One `U = 1.3e-5` survived**, in Section 6.4, written without spaces and so
  missed by earlier searches. Now `6.6e-5`, matching Section 5.1 and Table 4.
- **Regime IV insensitivity was overstated.** "cannot be reduced by optimizing
  material or drive parameters" (introduction) and "does not respond to
  optimization of U and alpha ... cannot be overcome" (conclusions) are now
  qualified to the range actually tested. Section 6.3 additionally separates the
  two calculation sets: the coarse five-combination 50 GHz scan that establishes
  the insensitivity, and the converged four-regime phase-statistics campaign of
  Table 2, which was run at `alpha = 1e-3` only because the `alpha = 0.01`
  campaign was not completed for Regime IV.
- **The Co:YIG damping block contradicted itself.** After correctly stating that
  `alpha = 1e-3` is a target and not a demonstrated property of Co:YIG, the text
  claimed "ultra-low damping can be maintained ... as verified in [22]", where
  [22] is a Bi-substituted result that the preceding paragraph explains does not
  transfer. One line is now held throughout: `K_u` is within the reported
  Co:YIG range, `alpha ~ 1e-3` is a target, and the Bi:YIG result shows what
  garnet films can reach without demonstrating that it survives Co-induced
  anisotropy. Two further instances in the conclusions were corrected the same
  way.
- Two label tails: panel (c) of Fig. 10 and the neighbouring-values sentence of
  Section 5.3 now read `U_audit`.

Integrity after the pass: 16 equation objects, 10 drawings, no residual markup.

### v6.9 — layout pass on the rendered proof

- Table 1 (notation) splits across pages. Its header row now repeats on the
  continuation page and individual rows are marked not to split.
- Table 2 (four regimes) broke the BER exponents across lines, so that
  `6.1 x 10^-` and `5` fell on separate lines. The column widths were
  rebalanced within the same total width (BER 1045 -> 1345 twips, taken from
  the Regime, carrier and n-bar columns), and all four exponents now sit on one
  line. Scientific notation and font size are unchanged.
- Table 4: the Origin cell for Gilbert damping read "optimized Co:YIG (0.15 as
  grown)", which implied that 1e-3 had been achieved in Co:YIG. It now reads
  "target for an optimized film; 0.15 as-grown Co:YIG", consistent with the
  line held since v6.8.
- Two literal `&quot;` sequences appeared in Section 2, where an earlier
  run-level edit had double-escaped a pre-existing XML entity. Repaired, and
  the editing helper now round-trips `&quot;` correctly.

Tables 3 and 4 needed no geometry change. Integrity after the pass: 16 equation
objects, 10 drawings, no residual markup or entity escapes.

### v7.0 — final checklist pass

Two defects, both introduced by earlier edits in this cycle, found by the
standing pre-submission checklist:

- **Citation order.** The `[3, 4]` attribution added to the sentence naming the
  AMT framework in the introduction appeared one paragraph before the first
  citation of `[1]` and `[2]`, breaking first-appearance numbering. The bracket
  was removed from that sentence; the framework is still attributed in the next
  paragraph, where `[3, 4]` follows `[1, 2]` correctly. First-appearance order
  is now strictly 1-29.
- **Coloured body text.** Nineteen runs carrying near-black and blue-grey
  colours (0A0A0A, 555555, 212121, 4073DD, 006699) were reintroduced when the
  Holstein-Primakoff paragraph and the Hansen reference were restored from the
  pre-rebuild source. Normalised to automatic; only hyperlink blue remains.

Checklist result for the release: build rules, style, revision traces, figure
and table numbering, caption voice, citation order, competing-interests
statement and equation/drawing counts all pass for both documents. Supplement
line spacing is 1.5 through docDefaults; the only underscores in it are inside
an archived script filename.

### v7.1 — title and abstract made readable

- The formula was removed from the title of both documents. It now reads
  "Spin content fixes the Kerr nonlinearity of a magnon mode: a mean-field
  materials criterion for nonlinear magnon confinement in Co-doped YIG". The
  criterion itself is stated in the abstract, in Section 8 and in the
  conclusions, so nothing is lost.
- The abstract no longer opens with the Hamiltonian. The convention statement
  belongs in Section 2 and Section 5.1, where it is set out in full, and in an
  abstract it delayed the result by three lines. Removed along with it: the
  explicit Kerr-frequency expression, the growth-rate and decay-rate
  expressions, the thermal-stability inequality, and the two numerical drive
  intervals, all of which are now given in words or deferred to the body.
- Five expressions remain, and they are the ones the reader needs to follow the
  argument: the definition of the effective spin content, the Kerr coefficient
  in terms of it, the drive window, the screening criterion and its resonant
  reduction. Twelve down to five, and no operator algebra before the result.

### v7.2 — abstract rewritten to journal house style

The abstract was 522 words, opened on a negation and contained none of the
vocabulary a magnetism editor scans for. It is now 306 words and follows the
structure common to recent Journal of Magnetism and Magnetic Materials and
adjacent magnonics abstracts: field context, the limitation addressed, "Here we
show ..." with the method named, the numbers, and a closing statement of what
the results provide.

Scope vocabulary now present where it was absent: magnonics, yttrium iron
garnet, Gilbert damping, saturation magnetization, magnetic anisotropy, garnet
film, ferrimagnet, magnonic devices. Keywords were reordered to the same
vocabulary, leading with Magnonics and Yttrium iron garnet.

Content dropped rather than compressed: the protocol-dependence counterexample
(a static-drive calculation at a predicted saturation of three retaining 95 % of
the population in the two lowest levels), which is given in full in Section 5.3
and Section 8; the four regime-by-regime sigma values, now a range; and the
7 nm-cube and normal-mode statements, both of which are in Section 5.1. Five
expressions remain, unchanged from v7.1.

### v7.3 — every symbol in the abstract is now introduced

The v7.2 abstract used ten undefined quantities. It now carries three relations
built on five symbols, each introduced where it first appears:

    U = omega_a / (2 N_eff Omega)        alpha N_eff < omega_a / Omega
    N_eff < 1 / alpha

with `omega_a` the anisotropy-field frequency, `Omega` the mode frequency,
`N_eff` the net spin content of the mode, `alpha` the Gilbert damping and `U`
the dimensionless Kerr coefficient. Removed as symbols and given in words
instead: the saturation magnetization, the mode volume, the g-factor and the
Bohr magneton (now "fixed by the saturation magnetization and the mode volume
alone"); the drive parameter and the two-sided drive window ("bounded below by
the Gilbert damping and above by the requirement that the saturated occupation
stay under one"); the thermal-occupation ratio ("ordered by the thermal
occupation of the driven mode"). The abstract is 318 words and reads without
reference to the body.
