# Archive audit before public upload

## Verified additions

- Completed 310 K frequency-scan outputs through 10 THz are included.
- The 6-10 THz subset is copied directly from the individual completed run JSON files (runs 34-38).
- The latest PRM manuscript and the final rewritten Supplementary Information are included in `docs/`; the Supplementary title now matches the manuscript, and Supplement 8 documents the completed 310 K scan.
- Python files compile syntactically; notebooks are valid JSON; CSV and JSON result files parse successfully; ZIP integrity was checked.

## Critical interpretation boundary

The completed frequency scan uses a **static effective pair drive** and gives, at 6 THz, `|<aa>| = 0.258933` and `P0+P1 = 0.959322`. The manuscript abstract reports `|<aa>| = 5.27` for the 6-THz room-temperature phase regime. These numbers are not interchangeable: the latter belongs to a different, explicitly resonant phase-encoding calculation. The manuscript and repository must identify the protocol next to each quoted value.

The phrase that Fock confinement “requires 6 THz or above” is stronger than the scan itself: the scan gives `P0+P1 = 0.9371` at 3 THz, `0.9501` at 4 THz, `0.9562` at 5 THz, and `0.9593` at 6 THz. A threshold is therefore criterion-dependent and should be stated as such rather than as a sharp transition.

## Incomplete source retained only as legacy

The uploaded run-21 ZIP contains an empty CSV and no individual completed runs. It is kept under `legacy/` for provenance and excluded from the verified numerical dataset.

## Supplementary Information review

The final Supplementary Information was rendered page by page and visually checked. It contains no Word comments or fields, its figures have alternative text, and all tables have marked header rows. The 6–10 THz table and Figure S4 use the archived static-effective-drive frequency-scan data. The document explicitly warns that its scan convention `U a†²a²` is not numerically interchangeable with the matched audit convention `(UΩ/2)a†²a²`.
