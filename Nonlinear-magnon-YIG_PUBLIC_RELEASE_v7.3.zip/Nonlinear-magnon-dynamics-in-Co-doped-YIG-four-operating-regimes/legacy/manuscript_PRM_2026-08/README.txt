Manuscript and Supplementary Information as submitted to Physical Review
Materials (MV10377, August 2026) and declined at editorial assessment.

Superseded by docs/Tishin_SpinContent_NecessaryCriterion_v6.docx and
docs/Supplementary_v6.docx.  These files are retained only for provenance and
must not be used for the current numbers: they carry the pre-v6 spin-count
convention (N_eff = S*N_ion), the parametric threshold eta > 4 alpha in place
of eta > 2 alpha, and the architectural projection layer.
