Removed from the manuscript in v6.

Fig11_compute_window.{pdf,png} and figure11_compute_window.csv were the
compute-window scalability figure and its data.  The figure supported the
architectural projection layer (throughput, CMOS comparison, array power),
which was removed from the manuscript because those figures are not outputs of
the single-mode model.  The computation itself is unchanged and is kept here
for provenance; it is not referenced by the current manuscript, which now has
ten main figures.
