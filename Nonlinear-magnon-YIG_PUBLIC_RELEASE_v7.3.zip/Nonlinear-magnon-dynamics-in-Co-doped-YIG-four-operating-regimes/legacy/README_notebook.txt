in_memory_computing_notebook_historical.ipynb

Development notebook for the whole project, retained for provenance. It is
historical and not a validated output of the current manuscript.

It contains cells from the architectural layer that was removed from the
manuscript in release v6 — throughput, operations-per-second, fabrication-yield
audits (`yield_pct`, `victorious_yield_audit`) and array-level power figures.
None of these quantities is claimed anywhere in the manuscript or in this
archive; Supplement 6 states explicitly that they are not validated outputs of
the single-mode simulations. The cells are kept only so that the development
history remains inspectable.

The scripts that produce every figure and number in the current manuscript are
under `scripts/`, and their outputs under `results/`. Use those, not this
notebook.
