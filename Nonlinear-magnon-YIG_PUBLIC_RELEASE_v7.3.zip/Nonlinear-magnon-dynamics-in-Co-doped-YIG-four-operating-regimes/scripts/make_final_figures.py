"""Generate publication-ready Figures 4 and 5 from archived CSV outputs.

Inputs (in current directory or --input-dir):
  protocol_audit_full_dynamics.csv
  five_phase_pair_control_summary.csv

Outputs are written to --output-dir in PNG (600 dpi), PDF, and SVG.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def save_all(fig, out: Path, stem: str) -> None:
    for ext in ("png", "pdf", "svg"):
        kwargs = {"dpi": 600} if ext == "png" else {}
        fig.savefig(out / f"{stem}.{ext}", bbox_inches="tight", **kwargs)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input-dir", type=Path, default=Path("."))
    ap.add_argument("--output-dir", type=Path, default=Path("final_figures"))
    args = ap.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    dyn_path = args.input_dir / "protocol_audit_full_dynamics.csv"
    phase_path = args.input_dir / "five_phase_pair_control_summary.csv"
    if not dyn_path.exists() or not phase_path.exists():
        raise FileNotFoundError(f"Missing required CSV(s): {dyn_path}, {phase_path}")

    dyn = pd.read_csv(dyn_path)
    ph = pd.read_csv(phase_path)

    plt.rcParams.update({
        "font.family": "serif",
        "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
        "font.size": 10,
        "axes.labelsize": 10,
        "legend.fontsize": 8.5,
        "xtick.labelsize": 9,
        "ytick.labelsize": 9,
        "axes.linewidth": 0.8,
        "lines.linewidth": 1.4,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
    })

    # Figure 4
    t = dyn["time"].to_numpy()
    nb = dyn["bogoliubov_abs_v_squared"].to_numpy()
    nl = dyn["resonant_mean_n"].to_numpy()
    tail = slice(len(t) // 2, None)
    mb, ml = nb[tail].mean(), nl[tail].mean()

    fig, ax = plt.subplots(figsize=(6.6, 4.2))
    ax.plot(t, nb, label=r"Reduced model: $n_{\rm B}=|v|^2$")
    ax.plot(t, nl, label=r"Lindblad model: $n_{\rm L}=\langle\hat n\rangle$")
    ax.axhline(1.0, ls="--", lw=1.0, label=r"$\langle\hat n\rangle=1$")
    ax.set(xlabel=r"Normalized time $\Omega t$", ylabel="Mean occupation", xlim=(t.min(), t.max()))
    ax.legend(loc="upper right", frameon=True)
    ax.text(0.025, 0.965,
            rf"$\overline{{n}}_{{\rm B}}={mb:.3f}$" "\n"
            rf"$\overline{{n}}_{{\rm L}}={ml:.3f}$" "\n"
            rf"$\overline{{n}}_{{\rm B}}/\overline{{n}}_{{\rm L}}={mb/ml:.3f}$",
            transform=ax.transAxes, va="top", fontsize=8.5,
            bbox=dict(boxstyle="round,pad=0.3", facecolor="white", edgecolor="0.75"))
    ax.tick_params(direction="in", top=True, right=True)
    fig.tight_layout()
    save_all(fig, args.output_dir, "Figure_4_Bogoliubov_Lindblad")
    plt.close(fig)

    # Figure 5
    x = ph["phi_d_rad"].to_numpy()
    y = np.unwrap(ph["mean_pair_phase_rad"].to_numpy())
    mean_n = ph["mean_n"].to_numpy()
    mean_aa = ph["mean_abs_aa"].to_numpy()
    slope, intercept = np.polyfit(x, y, 1)
    fit = intercept + slope * x
    rms = np.sqrt(np.mean((y-fit)**2))
    r2 = 1 - np.sum((y-fit)**2) / np.sum((y-y.mean())**2)
    xx = np.linspace(x.min(), x.max(), 300)

    fig, (a, b) = plt.subplots(1, 2, figsize=(7.2, 3.5))
    a.plot(xx, intercept + slope*xx, label="Linear fit")
    a.scatter(x, y, s=24, label="Lindblad result", zorder=3)
    a.set(xlabel=r"Drive phase $\phi_d$", ylabel=r"Late-time mean pair phase $\overline{\Phi}_{\rm pair}$")
    a.set_xticks(x, [r"$0$", r"$\pi/4$", r"$\pi/2$", r"$3\pi/4$", r"$\pi$"])
    a.text(0.05, 0.95, rf"slope $={slope:.5f}$" "\n" rf"$R^2={r2:.7f}$" "\n" rf"RMS $={rms:.1e}$ rad",
           transform=a.transAxes, va="top", fontsize=8.2,
           bbox=dict(boxstyle="round,pad=0.25", facecolor="white", edgecolor="0.75"))
    a.legend(loc="lower left", frameon=True)
    a.text(-0.18, 1.03, "(a)", transform=a.transAxes, fontweight="bold", fontsize=11)

    b.plot(x, mean_n, marker="o", label=r"$\overline{\langle\hat n\rangle}$")
    b.plot(x, mean_aa, marker="s", label=r"$\overline{|\langle aa\rangle|}$")
    b.set(xlabel=r"Drive phase $\phi_d$", ylabel="Late-time mean value")
    b.set_xticks(x, [r"$0$", r"$\pi/4$", r"$\pi/2$", r"$3\pi/4$", r"$\pi$"])
    b.legend(loc="best", frameon=True)
    b.text(-0.18, 1.03, "(b)", transform=b.transAxes, fontweight="bold", fontsize=11)
    for ax in (a, b):
        ax.tick_params(direction="in", top=True, right=True)
    fig.tight_layout(w_pad=2.0)
    save_all(fig, args.output_dir, "Figure_5_Pair_Phase_Control")
    plt.close(fig)

    print(f"Saved final figures to {args.output_dir.resolve()}")


if __name__ == "__main__":
    main()
