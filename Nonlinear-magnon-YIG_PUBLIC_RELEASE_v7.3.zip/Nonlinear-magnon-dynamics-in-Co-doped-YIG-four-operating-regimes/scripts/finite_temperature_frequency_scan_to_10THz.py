"""
FINITE-TEMPERATURE LINDBLAD FREQUENCY SCAN TO 10 THz

Compares U = 0.10 and U = 0.55 at T = 310 K.

Hamiltonian:
    H = Omega*n + U*a.dag()**2*a**2
        + (eta*Omega/4)*(a.dag()**2 + a**2)

Thermal collapse operators:
    L_down = sqrt[kappa*(n_th + 1)] * a
    L_up   = sqrt[kappa*n_th] * a.dag()

where:
    n_th = 1/(exp(hbar*2*pi*f/(kB*T)) - 1)

Install QuTiP if necessary:
    pip install qutip==5.3.0
"""

import json
import time
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from qutip import destroy, basis, mesolve


HBAR = 1.054571817e-34
KB = 1.380649e-23

OMEGA = 1.0
ETA = 1.2
ALPHA = 1.0e-3
KAPPA = 2.0 * ALPHA * OMEGA

TEMPERATURE_K = 310.0
U_VALUES = [0.10, 0.55]

TCYC = np.pi / OMEGA
NCYC = 20
PTS_PER_CYCLE = 10
N = 140

# Full scan. For a faster preliminary scan, remove intermediate points.
FREQUENCIES_HZ = np.array([
    50e9,
    75e9,
    100e9,
    150e9,
    200e9,
    300e9,
    500e9,
    750e9,
    1.0e12,
    1.5e12,
    2.0e12,
    3.0e12,
    4.0e12,
    5.0e12,
    6.0e12,
    7.0e12,
    8.0e12,
    9.0e12,
    10.0e12,
])

OUTPUT_DIR = Path("finite_temperature_frequency_scan_results")

SOLVER_OPTIONS = {
    "atol": 1.0e-9,
    "rtol": 1.0e-7,
    "nsteps": 500000,
    "method": "bdf",
    "store_states": False,
    "store_final_state": True,
    "progress_bar": "",
}


def thermal_occupation(freq_hz, temperature_k):
    if temperature_k <= 0.0:
        return 0.0
    x = HBAR * 2.0 * np.pi * freq_hz / (KB * temperature_k)
    return 1.0 / np.expm1(x)


def build_operators():
    a = destroy(N)
    ad = a.dag()
    n_op = ad * a

    p0 = basis(N, 0) * basis(N, 0).dag()
    p1 = basis(N, 1) * basis(N, 1).dag()
    p01_op = p0 + p1

    aa_op = a * a

    return a, ad, n_op, p01_op, aa_op


def run_case(a, ad, n_op, p01_op, aa_op, U, freq_hz):
    H = (
        OMEGA * n_op
        + U * ad * ad * a * a
        + (ETA * OMEGA / 4.0) * (ad * ad + a * a)
    )

    nth = thermal_occupation(freq_hz, TEMPERATURE_K)

    c_ops = [
        np.sqrt(KAPPA * (nth + 1.0)) * a,
        np.sqrt(KAPPA * nth) * ad,
    ]

    psi0 = basis(N, 0)

    tlist = np.linspace(
        0.0,
        NCYC * TCYC,
        NCYC * PTS_PER_CYCLE + 1,
    )

    start = time.time()

    result = mesolve(
        H,
        psi0,
        tlist,
        c_ops=c_ops,
        e_ops=[n_op, p01_op, aa_op],
        options=SOLVER_OPTIONS,
    )

    runtime = time.time() - start

    mean_n = np.real(np.asarray(result.expect[0]))
    p01 = np.real(np.asarray(result.expect[1]))
    pair = np.asarray(result.expect[2], dtype=complex)

    pair_abs = np.abs(pair)
    normalized_pair = pair_abs / (2.0 * mean_n + 1.0)

    final_state = result.final_state
    populations = np.real(np.diag(final_state.full()))
    populations = np.maximum(populations, 0.0)
    populations /= populations.sum()

    return {
        "frequency_Hz": float(freq_hz),
        "frequency_GHz": float(freq_hz / 1e9),
        "frequency_THz": float(freq_hz / 1e12),
        "temperature_K": float(TEMPERATURE_K),
        "thermal_occupation_nth": float(nth),
        "U": float(U),
        "N": int(N),
        "cycles": int(NCYC),
        "runtime_s": float(runtime),
        "max_mean_n": float(np.max(mean_n)),
        "final_mean_n": float(mean_n[-1]),
        "min_P0_plus_P1": float(np.min(p01)),
        "final_P0_plus_P1": float(p01[-1]),
        "final_P_n_ge_2": float(1.0 - p01[-1]),
        "final_pair_abs": float(pair_abs[-1]),
        "final_normalized_pair_abs": float(normalized_pair[-1]),
        "final_population_top_10_levels": float(np.sum(populations[-10:])),
        "final_population_highest_level": float(populations[-1]),
    }


def save_results(rows):
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    columns = [
        "frequency_Hz",
        "frequency_GHz",
        "frequency_THz",
        "temperature_K",
        "thermal_occupation_nth",
        "U",
        "N",
        "cycles",
        "runtime_s",
        "max_mean_n",
        "final_mean_n",
        "min_P0_plus_P1",
        "final_P0_plus_P1",
        "final_P_n_ge_2",
        "final_pair_abs",
        "final_normalized_pair_abs",
        "final_population_top_10_levels",
        "final_population_highest_level",
    ]

    matrix = np.array(
        [[row[column] for column in columns] for row in rows],
        dtype=float,
    )

    np.savetxt(
        OUTPUT_DIR / "frequency_scan_results.csv",
        matrix,
        delimiter=",",
        header=",".join(columns),
        comments="",
    )

    payload = {
        "model": {
            "Omega": OMEGA,
            "eta": ETA,
            "alpha": ALPHA,
            "kappa": KAPPA,
            "temperature_K": TEMPERATURE_K,
            "U_values": U_VALUES,
            "frequencies_Hz": FREQUENCIES_HZ.tolist(),
            "cycles": NCYC,
            "points_per_cycle": PTS_PER_CYCLE,
            "N": N,
            "initial_state": "vacuum",
        },
        "runs": rows,
    }

    with open(
        OUTPUT_DIR / "frequency_scan_summary.json",
        "w",
        encoding="utf-8",
    ) as file:
        json.dump(payload, file, indent=2, ensure_ascii=False)


def select_rows(rows, U):
    selected = [row for row in rows if np.isclose(row["U"], U)]
    return sorted(selected, key=lambda row: row["frequency_Hz"])


def plot_quantity(rows, key, ylabel, title, filename, log_y=False):
    fig, ax = plt.subplots(figsize=(8.5, 5.8))

    for U in U_VALUES:
        selected = select_rows(rows, U)
        x = np.array([row["frequency_THz"] for row in selected])
        y = np.array([row[key] for row in selected])

        ax.plot(
            x,
            y,
            marker="o",
            linewidth=1.5,
            markersize=4.5,
            label=f"U = {U:.2f}",
        )

    ax.set_xlabel("Physical frequency f (THz)")
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.set_xlim(0.0, 10.2)
    ax.grid(True, alpha=0.25)
    ax.legend(frameon=False)

    if log_y:
        ax.set_yscale("log")

    fig.tight_layout()
    fig.savefig(OUTPUT_DIR / f"{filename}.png", dpi=220)
    fig.savefig(OUTPUT_DIR / f"{filename}.pdf")
    plt.close(fig)


def plot_thermal_occupation(rows):
    selected = select_rows(rows, U_VALUES[0])
    x = np.array([row["frequency_THz"] for row in selected])
    y = np.array([row["thermal_occupation_nth"] for row in selected])

    fig, ax = plt.subplots(figsize=(8.5, 5.8))

    ax.plot(x, y, marker="o", linewidth=1.5, markersize=4.5)
    ax.axhline(1.0, linestyle="--", linewidth=1.0, label="n_th = 1")
    ax.axhline(0.1, linestyle="--", linewidth=1.0, label="n_th = 0.1")

    ax.set_xlabel("Physical frequency f (THz)")
    ax.set_ylabel("Thermal occupation n_th")
    ax.set_title("Thermal occupation at 310 K")
    ax.set_xlim(0.0, 10.2)
    ax.set_yscale("log")
    ax.grid(True, alpha=0.25)
    ax.legend(frameon=False)

    fig.tight_layout()
    fig.savefig(OUTPUT_DIR / "Figure_frequency_scan_nth.png", dpi=220)
    fig.savefig(OUTPUT_DIR / "Figure_frequency_scan_nth.pdf")
    plt.close(fig)


def make_plots(rows):
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    plot_quantity(
        rows,
        "final_P0_plus_P1",
        "Final P0 + P1",
        f"Low-Fock weight after {NCYC} cycles at 310 K",
        "Figure_frequency_scan_P01",
    )

    plot_quantity(
        rows,
        "final_mean_n",
        "Final mean occupation <n>",
        f"Mean occupation after {NCYC} cycles at 310 K",
        "Figure_frequency_scan_mean_n",
    )

    plot_quantity(
        rows,
        "final_pair_abs",
        "Final |<aa>|",
        f"Pair amplitude after {NCYC} cycles at 310 K",
        "Figure_frequency_scan_pair",
    )

    plot_quantity(
        rows,
        "final_normalized_pair_abs",
        "|<aa>| / (2<n> + 1)",
        f"Normalized pair amplitude after {NCYC} cycles at 310 K",
        "Figure_frequency_scan_normalized_pair",
    )

    plot_thermal_occupation(rows)


def main():
    print("=" * 79)
    print("FINITE-TEMPERATURE FREQUENCY SCAN TO 10 THz")
    print("=" * 79)
    print(f"Temperature: {TEMPERATURE_K:.1f} K")
    print(f"U values: {U_VALUES}")
    print(f"Basis size: N={N}")
    print(f"Duration: {NCYC} cycles")
    print(f"Frequency points: {len(FREQUENCIES_HZ)}")
    print()

    a, ad, n_op, p01_op, aa_op = build_operators()

    rows = []
    total_runs = len(U_VALUES) * len(FREQUENCIES_HZ)
    run_index = 0
    total_start = time.time()

    for U in U_VALUES:
        print("\n" + "=" * 79)
        print(f"SCAN FOR U={U:.2f}")
        print("=" * 79)

        for freq_hz in FREQUENCIES_HZ:
            run_index += 1
            nth = thermal_occupation(freq_hz, TEMPERATURE_K)

            print(
                f"[{run_index:02d}/{total_runs:02d}] "
                f"U={U:.2f}, "
                f"f={freq_hz/1e12:.3f} THz, "
                f"n_th={nth:.6f}"
            )

            row = run_case(
                a,
                ad,
                n_op,
                p01_op,
                aa_op,
                U,
                freq_hz,
            )

            rows.append(row)

            print(
                f"    final<n>={row['final_mean_n']:.6f} | "
                f"final P01={row['final_P0_plus_P1']:.6f} | "
                f"P(n>=2)={row['final_P_n_ge_2']:.6f} | "
                f"|<aa>|={row['final_pair_abs']:.6f} | "
                f"norm pair={row['final_normalized_pair_abs']:.6f} | "
                f"top10={row['final_population_top_10_levels']:.3e} | "
                f"time={row['runtime_s']:.1f}s"
            )

            # Save after every run to preserve partial results.
            save_results(rows)

    make_plots(rows)

    total_runtime = time.time() - total_start

    print("\n" + "=" * 79)
    print("SCAN COMPLETED")
    print("=" * 79)
    print(f"Total runtime: {total_runtime/3600.0:.2f} hours")
    print()
    print("Saved files:")
    print(OUTPUT_DIR / "frequency_scan_summary.json")
    print(OUTPUT_DIR / "frequency_scan_results.csv")
    print(OUTPUT_DIR / "Figure_frequency_scan_P01.png")
    print(OUTPUT_DIR / "Figure_frequency_scan_P01.pdf")
    print(OUTPUT_DIR / "Figure_frequency_scan_mean_n.png")
    print(OUTPUT_DIR / "Figure_frequency_scan_mean_n.pdf")
    print(OUTPUT_DIR / "Figure_frequency_scan_pair.png")
    print(OUTPUT_DIR / "Figure_frequency_scan_pair.pdf")
    print(OUTPUT_DIR / "Figure_frequency_scan_normalized_pair.png")
    print(OUTPUT_DIR / "Figure_frequency_scan_normalized_pair.pdf")
    print(OUTPUT_DIR / "Figure_frequency_scan_nth.png")
    print(OUTPUT_DIR / "Figure_frequency_scan_nth.pdf")


if __name__ == "__main__":
    main()
