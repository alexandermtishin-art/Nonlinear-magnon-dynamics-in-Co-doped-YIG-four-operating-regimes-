"""Exploratory U-eta Lindblad scan for occupation and Fock leakage.
Not a search for deterministic |1> preparation; pair drive preserves parity in the unitary sector.
"""
from pathlib import Path
import numpy as np,pandas as pd
from qutip import destroy,basis,qeye,mesolve
OUT=Path(__file__).resolve().parents[1]/"results"/"u_eta_scan"; OUT.mkdir(parents=True,exist_ok=True)
Omega,alpha,N=1.0,0.01,40; kappa=2*alpha*Omega
t=np.linspace(0,100,1001); tail=slice(len(t)//2,None)
Us=np.linspace(0.1,1.0,10); etas=np.linspace(0.2,2.0,10)
a=destroy(N); ad=a.dag(); n=ad*a; I=qeye(N); p0=basis(N,0)*basis(N,0).dag(); p1=basis(N,1)*basis(N,1).dag(); p2=basis(N,2)*basis(N,2).dag(); pge2=I-p0-p1
rows=[]
for U in Us:
  H0=Omega*n+0.5*U*Omega*ad*ad*a*a
  for eta in etas:
    pair=ad*ad+a*a
    def f(tt, **kwargs): return 0.5*eta*Omega*np.sin(2*Omega*tt)
    r=mesolve([H0,[pair,f]],basis(N,0),t,[np.sqrt(kappa)*a],[n,p0,p1,p2,pge2],options={"method":"bdf","nsteps":100000,"progress_bar":False})
    nt=np.real(r.expect[0]); vals=[np.real(np.asarray(x)) for x in r.expect[1:]]
    mn=nt[tail].mean(); leak=vals[3][tail].mean(); score=abs(mn-1)+2*leak+0.25*nt[tail].std()
    rows.append(dict(U=U,eta=eta,mean_n=mn,std_n=nt[tail].std(),mean_P0=vals[0][tail].mean(),mean_P1=vals[1][tail].mean(),mean_P2=vals[2][tail].mean(),mean_P_ge_2=leak,score=score))
    pd.DataFrame(rows).to_csv(OUT/"scan_checkpoint.csv",index=False)
pd.DataFrame(rows).to_csv(OUT/"scan_complete.csv",index=False)
