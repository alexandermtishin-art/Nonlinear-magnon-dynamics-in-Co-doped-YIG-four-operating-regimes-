Place current segmented checkpoint low-damping scripts here.
Added for final release v2 packaging.
