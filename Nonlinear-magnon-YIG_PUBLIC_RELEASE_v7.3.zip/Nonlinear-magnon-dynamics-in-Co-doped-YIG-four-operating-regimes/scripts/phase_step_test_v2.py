"""
=============================================================================
 STEP-RESPONSE TEST v2  -- corrected phase extraction
=============================================================================
 Why v1 needs fixing
 -------------------
 v1 extracted the response from unwrap(arg<aa>).  That fails whenever the
 anomalous correlator passes near the origin: the argument is undefined and
 np.unwrap inserts spurious 2*pi windings.  The v1 run showed exactly this:

     phi_step   min|<aa>| after settling   tau_resp   overshoot
       0.25 pi          0.4116               0.595      0.23     <- OK
       0.50 pi          0.0295              23.069      0.43     <- broken
       1.00 pi          0.0423               7.613      2.12     <- broken

 For the pi step the unwrapped level moved by -9.414 rad = -2.996 pi, i.e.
 three pi, not one; it only looked like -pi after wrapping mod 2*pi.

 Second problem: v1 boxcar-averaged over a FULL drive period (pi/Omega
 = 3.14).  A step smeared by a 3.14-wide kernel cannot show a response time
 shorter than that, so the fitted tau = 0.595 was set by the kernel, not by
 the dynamics.

 What v2 does instead
 --------------------
 Work with the rotating-frame COMPLEX correlator

     z(t) = <aa>(t) * exp(2i*Omega*t)

 which is smooth and well defined even when |z| -> 0.  The response is the
 approach of z to its new steady value:

     d(t) = |z(t) - z_inf|

 fitted as d(t) = d0 * exp(-(t - t_step)/tau).  This needs no phase
 unwrapping and no branch choice.  Smoothing uses a QUARTER drive period so
 the kernel does not dominate the fit; the residual ripple is handled by the
 fit itself.  The phase transfer is then read off from arg(z_inf) - arg(z_pre)
 using the steady levels only, where |z| is large and the phase is safe.

 Run this INSTEAD of the analysis block of v1; the propagation part is
 unchanged, so the two segments are integrated the same way.
=============================================================================
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from qutip import destroy, basis, mesolve

# ----------------------------------------------------------------- parameters
OMEGA, U, ETA, ALPHA = 1.0, 0.55, 1.2, 0.01
KAPPA = 2.0 * ALPHA * OMEGA
N = 50

T_TOTAL, T_STEP = 200.0, 100.0
PTS_PER_CYCLE = 200
PHI_STEPS = [0.0, np.pi / 8, np.pi / 4, np.pi / 2, np.pi]

DRIVE_PERIOD = np.pi / OMEGA
SMOOTH_WIN = DRIVE_PERIOD / 4.0          # <-- quarter period, not full

# ----------------------------------------------------------------- operators
a = destroy(N); ad = a.dag()
H0 = OMEGA * ad * a + 0.5 * U * OMEGA * ad * ad * a * a
H_pair = 0.5 * (ad * ad + a * a)
c_ops = [np.sqrt(KAPPA) * a]
e_ops = [ad * a, a * a]
rho0 = basis(N, 0) * basis(N, 0).dag()


def drive(phi_d):
    def _f(t, **kw):
        return ETA * OMEGA * np.sin(2.0 * OMEGA * t + phi_d)
    return _f


def run(state, tg, phi_d):
    res = mesolve([H0, [H_pair, drive(phi_d)]], state, tg,
                  c_ops=c_ops, e_ops=e_ops,
                  options={"atol": 1e-10, "rtol": 1e-8, "nsteps": 200000,
                           "store_final_state": True})
    return res, res.final_state


def grid(t0, t1):
    return np.linspace(t0, t1,
                       int(round((t1 - t0) / DRIVE_PERIOD * PTS_PER_CYCLE)) + 1)


def smooth(t, y, win):
    """Boxcar over `win`; works for complex y."""
    w = max(int(round(win / (t[1] - t[0]))), 1)
    if w % 2 == 0:
        w += 1
    k = np.ones(w) / w
    pad = w // 2
    yp = np.concatenate([np.full(pad, y[0]), y, np.full(pad, y[-1])])
    return np.convolve(yp, k, mode="valid")


# ----------------------------------------------------------------- propagate
g1 = grid(0.0, T_STEP)
r1, state_step = run(rho0, g1, 0.0)

print("=" * 78)
print("STEP-RESPONSE TEST v2 (complex-plane extraction)")
print("=" * 78)
print(f"N={N}  U={U}  eta={ETA}  alpha={ALPHA}  T_step={T_STEP}  "
      f"T_total={T_TOTAL}")
print(f"smoothing window = {SMOOTH_WIN:.3f}  (drive period = "
      f"{DRIVE_PERIOD:.3f}, damping time = {1/(ALPHA*OMEGA):.0f})")
print("=" * 78)

rows, traces = [], {}

for ps in PHI_STEPS:
    g2 = grid(T_STEP, T_TOTAL)
    r2, _ = run(state_step, g2, ps)

    t = np.concatenate([g1, g2[1:]])
    nn = np.concatenate([np.real(r1.expect[0]), np.real(r2.expect[0])[1:]])
    aa = np.concatenate([r1.expect[1], r2.expect[1][1:]])

    z = aa * np.exp(2j * OMEGA * t)          # rotating-frame complex correlator
    zs = smooth(t, z, SMOOTH_WIN)
    ns = smooth(t, nn.astype(complex), SMOOTH_WIN).real

    pre = (t > 0.8 * T_STEP) & (t < T_STEP)
    post = t > T_TOTAL - 0.2 * (T_TOTAL - T_STEP)
    z_pre, z_inf = zs[pre].mean(), zs[post].mean()
    n_pre, n_post = ns[pre].mean(), ns[post].mean()

    d_phi = np.angle(z_inf / z_pre)          # branch-safe steady-state transfer

    # --- response time from the complex distance, no unwrapping needed
    m = t >= T_STEP
    tt = t[m] - T_STEP
    dist = np.abs(zs[m] - z_inf)
    tau = np.nan
    if np.abs(z_inf - z_pre) > 0.05:
        try:
            p0 = [dist[0], 5.0, dist[-1]]
            popt, _ = curve_fit(lambda x, A, T, c: A * np.exp(-x / T) + c,
                                tt, dist, p0=p0, maxfev=60000)
            tau = abs(popt[1])
        except Exception as e:                                   # noqa
            print("   fit failed:", e)

    # --- did the pair amplitude survive the step?
    trans = (t >= T_STEP) & (t < T_STEP + 60.0)
    zmin = np.abs(zs[trans]).min()
    zpre_mod = np.abs(z_pre)
    n_peak = ns[trans].max()

    rows.append((ps, d_phi, tau, zpre_mod, zmin, zmin / zpre_mod,
                 n_pre, n_post, n_peak))
    traces[ps] = (t, zs, ns)

    print(f"\nphi_step = {ps/np.pi:.3f} pi")
    print(f"   steady-state transfer  dPhi = {d_phi:+.6f} rad "
          f"({d_phi/np.pi:+.4f} pi)"
          + (f",  -dPhi/phi_d = {-d_phi/ps:+.5f}" if ps > 1e-9 else "  (null)"))
    print(f"   tau_resp (complex fit) = {tau:.3f}   "
          f"[kernel {SMOOTH_WIN:.2f}, drive cycle {DRIVE_PERIOD:.2f}, "
          f"damping {1/(ALPHA*OMEGA):.0f}]")
    if not np.isnan(tau) and tau < 3 * SMOOTH_WIN:
        print("   WARNING: tau is within ~3x the smoothing kernel -> treat as "
              "an UPPER BOUND only")
    print(f"   |z| before = {zpre_mod:.4f},  min |z| during transient = "
          f"{zmin:.4f}  (ratio {zmin/zpre_mod:.3f})")
    if zmin / zpre_mod < 0.2:
        print("   WARNING: the pair amplitude collapses through ~0 during the "
              "step;")
        print("            phase and amplitude are NOT decoupled for this "
              "step size.")
    print(f"   <n>: pre {n_pre:.4f} -> peak {n_peak:.4f} -> post {n_post:.4f}"
          f"   (net {100*(n_post-n_pre)/n_pre:+.2f} %, "
          f"peak excursion {100*(n_peak-n_pre)/n_pre:+.1f} %)")

print("\n" + "=" * 78)
print("SUMMARY")
print("=" * 78)
print("phi_d/pi   dPhi/pi  -dPhi/phi_d   tau_resp   |z|pre   min|z|  ratio   "
      "n_peak/n_pre")
for (ps, dp, tau, zp, zm, rt, npre, npost, npk) in rows:
    ratio = (-dp / ps) if ps > 1e-9 else np.nan
    print(f"{ps/np.pi:7.3f}  {dp/np.pi:+8.4f}  {ratio:10.5f}  {tau:9.3f}  "
          f"{zp:7.4f}  {zm:7.4f}  {rt:6.3f}  {npk/npre:9.3f}")

# ----------------------------------------------------------------- figures
fig, ax = plt.subplots(1, 2, figsize=(13, 5.5))
for ps in PHI_STEPS:
    t, zs, ns = traces[ps]
    m = (t > T_STEP - 10) & (t < T_STEP + 60)
    ax[0].plot(zs[m].real, zs[m].imag, lw=1.2,
               label=rf"$\phi_d={ps/np.pi:.3f}\pi$")
    ax[1].plot(t, np.abs(zs), lw=1.2, label=rf"$\phi_d={ps/np.pi:.3f}\pi$")
ax[0].plot(0, 0, "k+", ms=12)
ax[0].set_xlabel(r"Re $\langle aa\rangle e^{2i\Omega t}$")
ax[0].set_ylabel(r"Im $\langle aa\rangle e^{2i\Omega t}$")
ax[0].set_title("Trajectory through the step (complex plane)")
ax[0].set_aspect("equal"); ax[0].grid(alpha=.3); ax[0].legend(fontsize=8)
ax[1].axvline(T_STEP, color="k", ls=":", lw=1)
ax[1].set_xlabel(r"$\Omega t$")
ax[1].set_ylabel(r"$|\langle aa\rangle|$")
ax[1].set_title("Pair-correlation amplitude across the step")
ax[1].grid(alpha=.3); ax[1].legend(fontsize=8)
plt.tight_layout()
plt.savefig("pair_step_complex.png", dpi=150)
plt.show()
