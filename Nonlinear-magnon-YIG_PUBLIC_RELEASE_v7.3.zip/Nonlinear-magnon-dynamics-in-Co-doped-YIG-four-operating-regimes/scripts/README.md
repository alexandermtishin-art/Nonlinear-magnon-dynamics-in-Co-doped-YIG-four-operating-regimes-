# Script map

## Current/recommended

- `protocol_audit.py` - matched static/resonant protocol audit, Bogoliubov-Lindblad bridge, parity, and anomalous correlator convention.
- `five_phase_control.py` - stationary five-phase transfer test.
- `phase_step_test_v2.py` - **recommended** dynamical step-response test using the rotating-frame complex correlator. This replaces v1 for response-time extraction.
- `make_final_figures.py` - rebuilds publication-ready Figures 4 and 5 from CSV outputs.
- `partial_u_eta_scan.py` - exploratory checkpointed scan; not evidence for deterministic one-Fock-state preparation.

## Historical/deprecated

- `phase_step_test_v1_deprecated.py` - retained for provenance. Its phase-unwrapping/full-period smoothing can create unreliable response times when the pair amplitude passes near zero. Do not use its fitted `tau_resp` in the manuscript.
- `legacy_regen_fig12.py` - legacy figure helper; exact Hamiltonian convention must be checked before interpretation.
