"""
=============================================================================
 1000-CYCLE FULL-QUANTUM STABILITY VERIFICATION  (Figure 3)
=============================================================================
 Extends the 100-cycle stress test of Fig. 2 to 1000 drive cycles under the
 full Lindblad master equation, to verify directly (not semiclassically) that
 the driven magnon mode stays bounded over the long time.

 Protocol (identical to Fig. 2, only the duration changes):
     H   = Omega*n + U*n^2 + (eta*Omega/4)*(a^dag^2 + a^2)      [Fig 1-3 convention]
     L   = sqrt(kappa) a ,   kappa = 2*alpha*Omega
     init = vacuum
 Parameters: Omega=1, U=0.1, eta=1.2, alpha=1e-3, 1000 cycles.

 Notes
 -----
 * The drive term sin-free here is the static effective pair drive; one drive
   "cycle" is T = pi/Omega (period of the a^dag^2+a^2 parametric term).
 * N is chosen by convergence: N=35 and N=45 agree to the quoted precision,
   and the top Fock levels carry <1e-22, so N=35 is used for the long run.
 * Output is sampled at 20 points/cycle. The solver integrates adaptively
   between output points; the reported max is sampling-limited and is stated
   as such (see the Fig. 2 discussion in the manuscript).

 Runtime: ~70 s at N=35 on a standard Colab CPU.
=============================================================================
"""

import time
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from qutip import destroy, basis, mesolve

# ------------------------------------------------------------------ parameters
OMEGA = 1.0
U     = 0.1
ETA   = 1.2
ALPHA = 1e-3
KAPPA = 2 * ALPHA * OMEGA
TCYC  = np.pi / OMEGA
NCYC  = 1000
PTS_PER_CYCLE = 20

CHECK_CONVERGENCE = True      # run N=35 and N=45 at 100 cycles first
N_MAIN = 35

# ------------------------------------------------------------------ helpers
def run(N, ncyc, pts_per_cycle=PTS_PER_CYCLE):
    a = destroy(N); ad = a.dag()
    H = OMEGA * ad * a + U * ad * ad * a * a + (ETA * OMEGA / 4.0) * (ad * ad + a * a)
    c = [np.sqrt(KAPPA) * a]
    t = np.linspace(0, ncyc * TCYC, ncyc * pts_per_cycle + 1)
    t0 = time.time()
    r = mesolve(H, basis(N, 0), t, c_ops=c, e_ops=[ad * a],
                options={"atol": 1e-9, "rtol": 1e-7, "nsteps": 300000,
                         "store_final_state": True})
    n = np.real(r.expect[0])
    pops = np.real(np.diag(r.final_state.full()))
    return t, n, pops, round(time.time() - t0, 1)


# ------------------------------------------------------------------ convergence
if CHECK_CONVERGENCE:
    print("Convergence check at 100 cycles:")
    for N in (35, 45):
        _, n, pops, dt = run(N, 100, 10)
        print(f"  N={N:2d} ({dt:4.1f}s): max={n.max():.4f} final={n[-1]:.4f} "
              f"P01={pops[0]+pops[1]:.5f} P>=10={pops[10:].sum():.2e} "
              f"Ptop3={pops[-3:].sum():.1e}")

# ------------------------------------------------------------------ main run
print(f"\n1000-cycle run at N={N_MAIN} ...")
t, n, pops, dt = run(N_MAIN, NCYC)
cyc = t / TCYC

# per-cycle envelopes
w = PTS_PER_CYCLE
pk = np.array([n[i:i + w].max() for i in range(0, len(n) - 1, w)])
mn = np.array([n[i:i + w].mean() for i in range(0, len(n) - 1, w)])
xc = np.arange(len(pk)) + 0.5

summary = dict(
    N=N_MAIN, ncyc=NCYC, runtime=dt,
    max_n=float(n.max()), final_n=float(n[-1]),
    n_100=float(n[100 * PTS_PER_CYCLE]),
    n_500=float(n[500 * PTS_PER_CYCLE]),
    n_900=float(n[900 * PTS_PER_CYCLE]),
    P0=float(pops[0]), P1=float(pops[1]), P01=float(pops[0] + pops[1]),
    P_ge2=float(pops[2:].sum()), P_ge10=float(pops[10:].sum()),
    P_top3=float(pops[-3:].sum()),
    plateau=float(mn[-5:].mean()),
)
print(json.dumps(summary, indent=2))

# ------------------------------------------------------------------ save data
with open("figure3_1000cycles_summary.json", "w") as f:
    json.dump(summary, f, indent=2)
# per-cycle envelope CSV
np.savetxt("figure3_1000cycles_envelope.csv",
           np.column_stack([xc, pk, mn]),
           delimiter=",", header="cycle,per_cycle_max,per_cycle_mean", comments="")
# final Fock distribution CSV
np.savetxt("figure3_1000cycles_final_fock.csv",
           np.column_stack([np.arange(len(pops)), pops]),
           delimiter=",", header="fock_level,probability", comments="")

# ------------------------------------------------------------------ figure
fig, ax = plt.subplots(1, 2, figsize=(13, 4.6))
ax[0].plot(cyc, n, lw=0.4, color="#4C72B0", alpha=0.55, label=r"$\langle n\rangle(t)$")
ax[0].plot(xc, pk, lw=1.6, color="#C44E52", label="per-cycle max")
ax[0].plot(xc, mn, lw=1.6, color="#DD8452", label="per-cycle mean")
ax[0].axhline(n[-1], ls=":", lw=1, color="k")
ax[0].set_xlabel("Number of cycles $t/T$")
ax[0].set_ylabel(r"Mean occupancy $\langle n\rangle$")
ax[0].set_xlim(0, NCYC); ax[0].set_ylim(0, 0.37)
ax[0].legend(frameon=False, fontsize=9, loc="upper right")
ax[0].set_title("Long-time quantum stability over 1000 cycles")

lv = np.arange(0, 8)
ax[1].bar(lv, pops[:8], color="#4C72B0", width=0.65)
ax[1].set_xlabel("Fock level $n$")
ax[1].set_ylabel("Probability")
ax[1].set_title("Final Fock-state distribution (cycle 1000)")
ax[1].set_ylim(0, 1.0)
for i in (0, 1):
    ax[1].text(i, pops[i] + 0.02, f"{pops[i]:.3f}", ha="center", fontsize=8)

plt.tight_layout()
plt.savefig("Figure_3_1000cycles.png", dpi=150)
plt.savefig("Figure_3_1000cycles.pdf")
print("\nsaved: Figure_3_1000cycles.png/.pdf, "
      "figure3_1000cycles_summary.json, "
      "figure3_1000cycles_envelope.csv, figure3_1000cycles_final_fock.csv")
