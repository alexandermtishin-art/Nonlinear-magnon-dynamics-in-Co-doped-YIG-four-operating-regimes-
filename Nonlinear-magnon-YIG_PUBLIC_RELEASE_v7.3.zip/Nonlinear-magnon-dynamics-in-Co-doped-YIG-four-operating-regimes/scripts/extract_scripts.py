"""
=============================================================================
 NOTEBOOK -> SCRIPT EXTRACTOR
=============================================================================
 Purpose
 -------
 Figures 3, 6, 7, 8, 9 and S1 of the manuscript have no generating script in
 the software archive, so PROVENANCE.md marks them unreproducible.  The code
 that made them is sitting in the legacy Colab notebooks as individual cells.
 This script pulls every code cell out into a standalone .py file, cleans the
 Colab-only lines, tries to compile (and optionally run) each one, and writes
 an INDEX.md that maps cell -> candidate manuscript figure.

 It does NOT decide for you which cell is the real source of a figure.  It
 gives you the shortlist with titles and axis labels so you can confirm by
 eye, then move the confirmed files into archive/scripts/.

 Usage in Colab
 --------------
   1. put the notebooks in NB_PATHS (or leave the glob and drop them in
      /content)
   2. run
   3. read INDEX.md, check the candidates against the printed figures
   4. rename the confirmed ones, e.g. fig08_universal_phase_map.py
=============================================================================
"""

import ast
import hashlib
import warnings
import json
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

# ------------------------------------------------------------------ config
# Leave NB_PATHS empty to auto-discover; or list the notebooks explicitly, e.g.
#   NB_PATHS = [Path("/content/in_memory_computing.ipynb")]
NB_PATHS = []
OUT_DIR  = Path("/content/extracted_scripts")

# Where to look for notebooks, in order.  Missing paths are skipped.
SEARCH_DIRS = [
    Path("/content"),
    Path.cwd(),
    Path("/content/drive/MyDrive"),
    Path("/content/drive/MyDrive/Colab Notebooks"),
]
ZIP_SEARCH  = True      # also look inside any .zip found in SEARCH_DIRS
ASK_UPLOAD  = True      # last resort: open the Colab file-upload dialog

TRY_COMPILE = True      # ast.parse every extracted cell
TRY_RUN     = False     # actually execute them (slow; many will need edits)
RUN_TIMEOUT = 300       # seconds per cell

MIN_CHARS   = 120       # ignore trivial cells (!pip install lines etc.)

# Title fragments -> manuscript figure.  Extend as you confirm matches.
FIGURE_HINTS = {
    "long-term energy dynamics":            "Figure 1",
    "final state distribution":             "Figure 1",
    "stress test: 100 operational cycles":  "Figure 2",
    "spectral occupancy":                   "Figure 2",
    "in-memory computing capacity":         "Figure 6",
    "magnetic quality":                     "Figure 6",
    "divergence vs localization":           "Figure 7",
    "bosonic divergence":                   "Figure 7",
    "magnon dynamics & localization":       "Figure 7",
    "universal phase map":                  "Figure 8",
    "universal scaling of magnon":          "Figure 8",
    "phase transition: magnon occupancy":   "Figure 8",
    "stability stress-test":                "Figure 9",
    "coherent stability map":               "Figure 9",
    "phase transition boundaries":          "Figure 9",
    "onset of stability":                   "Figure 9",
    "hyperbolic to euclidean":              "(retired claim - do not reuse)",
    "energy brake parameter (u)":           "Figure 3 candidate",
    "nonlinear energy brake parameter":     "Figure 3 candidate",
}

# lines that only make sense inside Colab
COLAB_LINE = re.compile(
    r"^\s*(!|%|from\s+google\.colab|import\s+google\.colab|files\.download|"
    r"drive\.mount|display\(|get_ipython\()")


# ------------------------------------------------------------------ helpers
def slug(text: str, n: int = 45) -> str:
    text = re.sub(r"\$[^$]*\$", "", text)                 # drop latex
    text = re.sub(r"[^a-zA-Z0-9]+", "_", text).strip("_").lower()
    return (text[:n].rstrip("_") or "untitled")


def clean(src: str):
    """Strip Colab-only lines; return (cleaned_source, list_of_removed)."""
    kept, removed = [], []
    for line in src.splitlines():
        (removed if COLAB_LINE.match(line) else kept).append(line)
    return "\n".join(kept).strip(), removed


def meta(src: str):
    """Pull plot titles, axis labels and a few tell-tale features."""
    titles = re.findall(r"title\(\s*[rfu]{0,2}['\"]([^'\"]{0,90})", src)
    xlabels = re.findall(r"xlabel\(\s*[rfu]{0,2}['\"]([^'\"]{0,50})", src)
    ylabels = re.findall(r"ylabel\(\s*[rfu]{0,2}['\"]([^'\"]{0,50})", src)
    feats = []
    for name, pat in [("qutip.mesolve", r"mesolve"), ("expm", r"\bexpm\("),
                      ("solve_ivp", r"solve_ivp"), ("savefig", r"savefig"),
                      ("to_csv", r"to_csv"), ("random", r"np\.random|seed\(")]:
        if re.search(pat, src):
            feats.append(name)
    return titles, xlabels, ylabels, feats


def guess_figure(titles, xlabels, ylabels):
    hay = " | ".join(titles + xlabels + ylabels).lower()
    hits = {fig for frag, fig in FIGURE_HINTS.items() if frag in hay}
    return sorted(hits)


# ------------------------------------------------------------------ extract
if OUT_DIR.exists():
    shutil.rmtree(OUT_DIR)
OUT_DIR.mkdir(parents=True)

print("=" * 76)
print("NOTEBOOK -> SCRIPT EXTRACTOR")
print("=" * 76)

# ------------------------------------------------------------------ find notebooks
def find_notebooks():
    """Locate .ipynb files: on disk, then inside zips, then via upload."""
    found, seen = [], set()

    def add(p: Path):
        p = Path(p).resolve()
        if p.suffix.lower() == ".ipynb" and p.is_file() and p not in seen \
                and ".ipynb_checkpoints" not in p.parts:
            seen.add(p)
            found.append(p)

    dirs, seen_dirs = [], set()
    for d in SEARCH_DIRS:                       # de-duplicate resolved paths
        if not d.exists():
            continue
        r = d.resolve()
        if r in seen_dirs or any(r.is_relative_to(x) for x in seen_dirs):
            continue
        seen_dirs.add(r)
        dirs.append(r)

    for d in dirs:
        try:
            for p in d.rglob("*.ipynb"):
                if "_nb_from_zip" not in p.parts:
                    add(p)
        except (PermissionError, OSError):
            pass
    if found:
        print(f"  found {len(found)} notebook(s) on disk")
        return found

    if ZIP_SEARCH:
        import zipfile
        dest = Path("/content/_nb_from_zip")
        seen_zips = set()
        for d in dirs:
            for z in sorted(d.rglob("*.zip")):
                if z.resolve() in seen_zips:
                    continue
                seen_zips.add(z.resolve())
                try:
                    with zipfile.ZipFile(z) as zf:
                        names = [n for n in zf.namelist()
                                 if n.lower().endswith(".ipynb")
                                 and ".ipynb_checkpoints" not in n]
                        if not names:
                            continue
                        dest.mkdir(parents=True, exist_ok=True)
                        print(f"  {z.name}: {len(names)} notebook(s) inside")
                        for n in names:
                            target = dest / Path(n).name
                            k = 1
                            while target.exists():
                                target = dest / f"{Path(n).stem}__{k}.ipynb"
                                k += 1
                            target.write_bytes(zf.read(n))
                            add(target)
                except zipfile.BadZipFile:
                    continue
        if found:
            return found

    if ASK_UPLOAD:
        try:
            from google.colab import files as _f      # type: ignore
            print("  nothing found -- select your .ipynb file(s) to upload")
            up = _f.upload()
            for name in up:
                if name.lower().endswith(".ipynb"):
                    add(Path("/content") / name)
        except Exception as e:
            print(f"  upload dialog unavailable ({e})")
    return found


if not NB_PATHS:
    print("\nlooking for notebooks ...")
    NB_PATHS = find_notebooks()

if not NB_PATHS:
    print("\nNo notebooks found. Either:")
    print("  * upload the .ipynb files to /content, or")
    print("  * upload the archive zip to /content (it will be searched), or")
    print("  * set NB_PATHS = [Path('/full/path/to/notebook.ipynb')] at the top.")
    print("\nWhat is currently in /content:")
    for p in sorted(Path("/content").glob("*"))[:40]:
        print("   ", p.name + ("/" if p.is_dir() else ""))
    raise RuntimeError("no notebooks to extract")

print("\nnotebooks to process:")
for p in NB_PATHS:
    print("   ", p)
rows, seen_hash, used_names = [], {}, set()
for nb_i, nb_path in enumerate(NB_PATHS):
    try:
        nb = json.loads(nb_path.read_text(encoding="utf-8"))
    except Exception as e:
        print(f"  ! cannot read {nb_path.name}: {e}")
        continue
    cells = [c for c in nb.get("cells", []) if c.get("cell_type") == "code"]
    print(f"\n{nb_path.name}: {len(cells)} code cells")
    for idx, cell in enumerate(cells):
        raw = "".join(cell.get("source", []))
        body, removed = clean(raw)
        if len(body) < MIN_CHARS:
            continue
        digest = hashlib.sha256(body.encode()).hexdigest()[:12]
        if digest in seen_hash:                      # identical cell in both nbs
            seen_hash[digest]["also_in"].append(f"{nb_path.stem}[{idx}]")
            continue

        titles, xl, yl, feats = meta(body)
        figs = guess_figure(titles, xl, yl)
        tag = f"nb{nb_i}_{slug(nb_path.stem, 16)}"
        base = f"{tag}__cell_{idx:03d}__{slug(titles[0] if titles else 'no_title', 38)}"
        name, k = base + ".py", 1
        while name in used_names:                # never overwrite a sibling cell
            name = f"{base}__{k}.py"; k += 1
        used_names.add(name)
        out = OUT_DIR / name

        ok, err = True, ""
        if TRY_COMPILE:
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    ast.parse(body)
            except SyntaxError as e:
                ok, err = False, f"line {e.lineno}: {e.msg}"

        header = [
            '"""',
            f"Extracted from {nb_path.name}, code cell {idx}.",
            f"Plot title(s): {titles or '(none)'}",
            f"Axes: x={xl or '-'}  y={yl or '-'}",
            f"Candidate manuscript figure: {', '.join(figs) if figs else 'UNIDENTIFIED'}",
            "",
            "Colab-only lines removed on extraction:" if removed else "No Colab-only lines.",
        ]
        header += [f"    {l.strip()}" for l in removed[:8]]
        header += ['"""', "", "import matplotlib", 'matplotlib.use("Agg")', ""]
        out.write_text("\n".join(header) + body + "\n", encoding="utf-8")

        rec = dict(file=name, nb=nb_path.stem, cell=idx, chars=len(body),
                   titles=titles, xl=xl, figs=figs, feats=feats,
                   compiles=ok, err=err, also_in=[], ran="")
        seen_hash[digest] = rec
        rows.append(rec)

print(f"\nextracted {len(rows)} unique cells -> {OUT_DIR}")

# ------------------------------------------------------------------ run
if TRY_RUN:
    print("\nexecuting extracted cells ...")
    for rec in rows:
        if not rec["compiles"]:
            rec["ran"] = "skipped (syntax)"
            continue
        try:
            r = subprocess.run([sys.executable, rec["file"]], cwd=OUT_DIR,
                               capture_output=True, text=True, timeout=RUN_TIMEOUT)
            rec["ran"] = "ok" if r.returncode == 0 else \
                "FAILED: " + (r.stderr.strip().splitlines() or ["?"])[-1][:110]
        except subprocess.TimeoutExpired:
            rec["ran"] = f"timeout >{RUN_TIMEOUT}s"
        print(f"   {rec['file'][:50]:52s} {rec['ran'][:60]}")

# ------------------------------------------------------------------ index
lines = ["# Extracted cell index", "",
         f"Generated {datetime.now(timezone.utc).isoformat(timespec='seconds')}",
         f"Source notebooks: {', '.join(p.name for p in NB_PATHS)}", "",
         "| File | Cell | Candidate figure | Title | Features | Compiles |" +
         (" Runs |" if TRY_RUN else ""),
         "|---|---|---|---|---|---|" + ("---|" if TRY_RUN else "")]
for r in rows:
    t = (r["titles"][0] if r["titles"] else "-")[:60].replace("|", "/")
    lines.append(f"| `{r['file']}` | {r['nb']}[{r['cell']}] | "
                 f"{', '.join(r['figs']) or '?'} | {t} | "
                 f"{', '.join(r['feats']) or '-'} | "
                 f"{'yes' if r['compiles'] else 'NO: ' + r['err']} |"
                 + (f" {r['ran']} |" if TRY_RUN else ""))

lines += ["", "## Shortlist by manuscript figure", ""]
wanted = ["Figure 1", "Figure 2", "Figure 3 candidate", "Figure 6",
          "Figure 7", "Figure 8", "Figure 9"]
for fig in wanted:
    cands = [r for r in rows if fig in r["figs"]]
    lines.append(f"**{fig}** — {len(cands)} candidate(s)")
    for r in cands:
        lines.append(f"  - `{r['file']}` — {(r['titles'][0] if r['titles'] else '')[:70]}")
    lines.append("")

dupes = [r for r in rows if r["also_in"]]
if dupes:
    lines += ["## Cells identical in both notebooks", ""]
    lines += [f"- `{r['file']}` also in {', '.join(r['also_in'])}" for r in dupes]

lines += ["", "## Caveats", "",
          "- A matching plot title is not proof of provenance. Regenerate the",
          "  figure and compare it with the version used in the manuscript",
          "  before moving a file into `archive/scripts/`.",
          "- Several cells use the legacy Kerr normalization `U*n**2` rather than",
          "  `(U*Omega/2)*a^dag^2 a^2`. Record which convention each confirmed",
          "  script uses; the symbol U is not transferable between them.",
          "- Cells that draw on random sampling need an explicit seed before the",
          "  output can be called reproducible."]

(OUT_DIR / "INDEX.md").write_text("\n".join(lines), encoding="utf-8")
print(f"index written -> {OUT_DIR/'INDEX.md'}")

# ------------------------------------------------------------------ summary
print("\nshortlist:")
for fig in wanted:
    c = [r["file"] for r in rows if fig in r["figs"]]
    print(f"   {fig:20s} {len(c)} candidate(s): {', '.join(c[:3])}{' ...' if len(c) > 3 else ''}")
bad = [r["file"] for r in rows if not r["compiles"]]
if bad:
    print(f"\n   {len(bad)} cell(s) do not compile standalone: {', '.join(bad[:5])}")

try:
    from google.colab import files as colab_files      # type: ignore
    shutil.make_archive("/content/extracted_scripts", "zip", OUT_DIR)
    colab_files.download("/content/extracted_scripts.zip")
except Exception:
    print("\n(zip/download only available inside Colab)")
