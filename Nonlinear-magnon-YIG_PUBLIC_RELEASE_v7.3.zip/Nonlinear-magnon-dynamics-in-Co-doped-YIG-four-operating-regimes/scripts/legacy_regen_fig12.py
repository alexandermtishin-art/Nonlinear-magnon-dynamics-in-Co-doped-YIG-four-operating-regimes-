"""
Regeneration of Figures 1 and 2 with kappa = 2*alpha*Omega, the rate specified
in Eq. (5) of the manuscript.  Layout, colours and panel structure follow the
original notebook cells 1 and 2 exactly; only the dissipation rate changes.
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.linalg import expm

def evolve(U, eta, alpha, N, tmax, nsteps, Om=1.0, kfac=2.0):
    a = np.zeros((N, N))
    for i in range(N-1):
        a[i, i+1] = np.sqrt(i+1)
    ad = a.T; nop = ad @ a
    H = Om*nop + U*(nop@nop) + (eta*Om/4.0)*(ad@ad + a@a)
    kap = kfac*alpha*Om
    I = np.eye(N)
    L = -1j*(np.kron(I, H) - np.kron(H.T, I)) \
        + kap*(np.kron(a.conj(), a) - 0.5*np.kron(I, ad@a) - 0.5*np.kron((ad@a).T, I))
    P = expm(L*(tmax/nsteps))
    v = np.zeros(N*N, complex); v[0] = 1.0
    nv = np.arange(N).astype(float)
    ns = np.empty(nsteps+1); ns[0] = 0.0
    for k in range(nsteps):
        v = P @ v
        ns[k+1] = np.real(np.diag(v.reshape(N, N, order='F'))) @ nv
    d = np.real(np.diag(v.reshape(N, N, order='F')))
    return np.linspace(0, tmax, nsteps+1), ns, d

# ------------------------------------------------------------------ Figure 1
t1, nh, dh = evolve(0.1, 1.2, 0.15,  40, 100.0, 3000)
t1, nl, dl = evolve(0.1, 1.2, 0.001, 40, 100.0, 3000)

fig, axes = plt.subplots(1, 2, figsize=(15, 5))
axes[0].plot(t1, nh, label=r'$\alpha=0.15$ (Dissipative saturation)', color='red', alpha=0.7)
axes[0].plot(t1, nl, label=r'$\alpha=10^{-3}$ (Coherent localization)', color='blue')
axes[0].set_title("Long-term Energy Dynamics")
axes[0].set_xlabel(r"Normalized Time ($\Omega t$)")
axes[0].set_ylabel(r"Mean Occupancy $\langle n \rangle$")
axes[0].grid(True, linestyle='--', alpha=0.5); axes[0].legend()
axes[1].bar(np.arange(8)-0.2, dh[:8], width=0.4, label=r'$\alpha=0.15$', color='red', alpha=0.5)
axes[1].bar(np.arange(8)+0.2, dl[:8], width=0.4, label=r'$\alpha=10^{-3}$', color='blue', alpha=0.5)
axes[1].set_title("Final State Distribution (Fock Basis)")
axes[1].set_xlabel("Fock Level n"); axes[1].set_ylabel("Probability")
axes[1].set_xlim(-0.5, 7.5); axes[1].legend()
plt.tight_layout(); fig.savefig('/home/claude/fig1_new.png', dpi=100); plt.close(fig)

# ------------------------------------------------------------------ Figure 2
T = 2*np.pi
t2, n2, d2 = evolve(0.1, 1.2, 0.001, 45, 100*T, 4000)

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 5))
ax1.plot(t2/T, n2, color='blue', lw=0.8)
ax1.set_title("Stress Test: 100 Operational Cycles")
ax1.set_xlabel("Number of Cycles (t/T)")
ax1.set_ylabel(r"Mean Occupancy $\langle n \rangle$")
ax1.grid(True, alpha=0.3)
ax2.bar(np.arange(15), d2[:15], color='blue', alpha=0.6)
ax2.set_title("Spectral Occupancy (N=100 Basis)")
ax2.set_xlabel("Fock Level n"); ax2.set_ylabel("Probability")
ax2.set_xlim(-0.5, 14.5)
plt.tight_layout(); fig.savefig('/home/claude/fig2_new.png', dpi=100); plt.close(fig)

print("FIG 1  cycles covered: %.2f   alpha=0.15 max<n>=%.4f  alpha=1e-3 max<n>=%.4f"
      % (100.0/T, nh.max(), nl.max()))
print("FIG 1  final P(0)+P(1): high %.4f   low %.4f" % (dh[0]+dh[1], dl[0]+dl[1]))
print("FIG 2  <n> final %.4f  max %.4f  P(n>=10) %.2e  P(0)+P(1) %.5f"
      % (n2[-1], n2.max(), d2[10:].sum(), d2[0]+d2[1]))
from PIL import Image
for f in ('fig1_new.png', 'fig2_new.png'):
    print(f, Image.open('/home/claude/'+f).size)
