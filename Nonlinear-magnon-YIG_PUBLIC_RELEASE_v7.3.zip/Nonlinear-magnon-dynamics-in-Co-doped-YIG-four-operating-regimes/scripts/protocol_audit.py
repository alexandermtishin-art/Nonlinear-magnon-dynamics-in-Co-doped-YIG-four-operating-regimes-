"""Protocol audit for static and resonantly modulated pair drives.

Outputs CSV tables and publication-quality diagnostic figures.
Model convention:
 H0 = Omega*n + (U*Omega/2) a^dagger^2 a^2
 kappa = 2 alpha Omega
"""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp
from qutip import destroy, basis, qeye, mesolve

OUT = Path(__file__).resolve().parents[1] / "results" / "protocol_audit"
OUT.mkdir(parents=True, exist_ok=True)
Omega, U, eta, alpha, N = 1.0, 0.55, 1.2, 0.01, 50
kappa = 2 * alpha * Omega
t = np.linspace(0, 100, 3001)
tail = slice(len(t)//2, None)
a = destroy(N); ad = a.dag(); n = ad*a; aa = a*a
pair = ad*ad + a*a; ident = qeye(N)
H0 = Omega*n + 0.5*U*Omega*ad*ad*a*a
p0 = basis(N,0)*basis(N,0).dag(); p1 = basis(N,1)*basis(N,1).dag(); p2 = basis(N,2)*basis(N,2).dag()
pge2 = ident-p0-p1
parity = sum(((-1)**j)*(basis(N,j)*basis(N,j).dag()) for j in range(N))
c_ops=[np.sqrt(kappa)*a]
opts={"method":"bdf","nsteps":100000,"atol":1e-9,"rtol":1e-7,"progress_bar":False}

def solve(H):
    r=mesolve(H,basis(N,0),t,c_ops,[n,p0,p1,p2,pge2,parity,aa],options=opts)
    return {"n":np.real(r.expect[0]),"P0":np.real(r.expect[1]),"P1":np.real(r.expect[2]),
            "P2":np.real(r.expect[3]),"Pge2":np.real(r.expect[4]),"parity":np.real(r.expect[5]),
            "aa":np.asarray(r.expect[6],complex)}

static=solve(H0+(eta*Omega/4)*pair)
def coeff(tt, **kwargs): return 0.5*eta*Omega*np.sin(2*Omega*tt)
resonant=solve([H0,[pair,coeff]])

def bog_rhs(tt,y):
    u=y[0]+1j*y[1]; v=y[2]+1j*y[3]
    shift=U*Omega*abs(v)**2; G=eta*Omega*np.sin(2*Omega*tt)
    du=-1j*((Omega+shift)*u+G*v)-alpha*Omega*u
    dv=+1j*((Omega+shift)*v+G*u)-alpha*Omega*v
    return [du.real,du.imag,dv.real,dv.imag]
b=solve_ivp(bog_rhs,(0,100),[1,0,0,0],t_eval=t,method="DOP853",atol=1e-10,rtol=1e-9)
u=b.y[0]+1j*b.y[1]; v=b.y[2]+1j*b.y[3]; nb=abs(v)**2

rows=[]
for name,d in [("static_effective",static),("resonant_modulated",resonant)]:
    rows.append(dict(protocol=name,mean_n=np.mean(d["n"][tail]),std_n=np.std(d["n"][tail]),
                     mean_P0=np.mean(d["P0"][tail]),mean_P1=np.mean(d["P1"][tail]),
                     mean_P2=np.mean(d["P2"][tail]),mean_P_ge_2=np.mean(d["Pge2"][tail]),
                     max_P1=np.max(d["P1"]),mean_abs_aa=np.mean(abs(d["aa"][tail])),
                     final_parity=d["parity"][-1]))
pd.DataFrame(rows).to_csv(OUT/"summary.csv",index=False)

cands={"u_v":u*v,"u_conj_v":u*np.conj(v),"minus_u_v":-u*v,"minus_u_conj_v":-u*np.conj(v)}
audit=[]
for name,c in cands.items():
    mask=(abs(c)>1e-7)&(abs(resonant["aa"])>1e-7)
    pdiff=np.angle(resonant["aa"][mask]*np.conj(c[mask]))
    audit.append(dict(candidate=name,
      complex_rms=np.sqrt(np.mean(abs(c[tail]-resonant["aa"][tail])**2)),
      magnitude_rms=np.sqrt(np.mean((abs(c[tail])-abs(resonant["aa"][tail]))**2)),
      magnitude_correlation=np.corrcoef(abs(c[tail]),abs(resonant["aa"][tail]))[0,1],
      mean_phase_shift=np.angle(np.mean(np.exp(1j*pdiff))),
      phase_resultant=abs(np.mean(np.exp(1j*pdiff)))))
pd.DataFrame(audit).to_csv(OUT/"anomalous_correlator_audit.csv",index=False)

pd.DataFrame({"time":t,"static_n":static["n"],"resonant_n":resonant["n"],"bogoliubov_v2":nb,
              "static_parity":static["parity"],"resonant_parity":resonant["parity"],
              "resonant_abs_aa":abs(resonant["aa"]),"resonant_arg_aa":np.unwrap(np.angle(resonant["aa"])),
              "bog_u_conj_v_abs":abs(u*np.conj(v))}).to_csv(OUT/"dynamics.csv",index=False)

plt.figure(figsize=(10,5.5)); plt.plot(t,static["n"],label="Static effective pair drive"); plt.plot(t,resonant["n"],label="Resonant time-dependent pair drive"); plt.axhline(1,ls="--",label="Mean occupation = 1"); plt.xlabel(r"Normalized time $\Omega t$"); plt.ylabel(r"Mean occupation $\langle n\rangle$"); plt.legend(); plt.tight_layout(); plt.savefig(OUT/"protocol_audit_mean_occupation.png",dpi=300); plt.close()
plt.figure(figsize=(10,5.5)); plt.plot(t,nb,label=r"Bogoliubov $|v|^2$"); plt.plot(t,resonant["n"],label=r"Lindblad $\langle n\rangle$"); plt.axhline(1,ls="--"); plt.xlabel(r"Normalized time $\Omega t$"); plt.ylabel("Mean occupation"); plt.legend(); plt.tight_layout(); plt.savefig(OUT/"matched_bogoliubov_lindblad_occupation.png",dpi=300); plt.close()
plt.figure(figsize=(10,5.5)); plt.plot(t,static["parity"],label="Static"); plt.plot(t,resonant["parity"],label="Resonant"); plt.xlabel(r"Normalized time $\Omega t$"); plt.ylabel(r"$\langle(-1)^{\hat n}\rangle$"); plt.legend(); plt.tight_layout(); plt.savefig(OUT/"parity.png",dpi=300); plt.close()
print(pd.DataFrame(rows).to_string(index=False))
