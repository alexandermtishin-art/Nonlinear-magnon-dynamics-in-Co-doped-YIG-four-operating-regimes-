"""Re-run the U scan of Fig. 4 in the canonical Kerr convention
(U*Omega/2) a^dag2 a^2 -- the same convention as the protocol audit, the
five-phase control runs and the phase-statistics campaign.  The archived
U_scan_quantum.csv was generated with the legacy U n^2 term and is therefore
not on the same footing as the rest of the paper."""
import numpy as np, pandas as pd
from qutip import destroy, basis, mesolve, ket2dm

OM, ETA, ALPHA, N = 1.0, 1.2, 0.01, 50
KAP = 2 * ALPHA * OM
OPTS = {"method": "bdf", "nsteps": 200000, "atol": 1e-9, "rtol": 1e-7,
        "store_final_state": True, "progress_bar": ""}
US = [0.0, 0.05, 0.1, 0.12, 0.15, 0.2, 0.3, 0.4, 0.5, 0.55, 0.6, 0.7, 0.8]

a = destroy(N); ad = a.dag(); n = ad * a
P01 = ket2dm(basis(N, 0)) + ket2dm(basis(N, 1))
t = np.linspace(0, 100.0, 3001)
rows = []
for U in US:
    H = OM * n + 0.5 * U * OM * ad * ad * a * a + (ETA * OM / 4) * (ad * ad + a * a)
    r = mesolve(H, basis(N, 0), t, c_ops=[np.sqrt(KAP) * a],
                e_ops=[n, P01], options=OPTS)
    nn = np.real(r.expect[0]); p = np.real(r.expect[1])
    pops = np.real(np.diag(r.final_state.full()))
    rows.append(dict(U=U, max_n=nn.max(), final_n=nn[-1], P01=p[-1],
                     P_n_ge_2=pops[2:].sum(), P_n_ge_10=pops[10:].sum()))
    print('U=%.2f  max=%.4f  final=%.4f  P01=%.4f  P>=2=%.4f'
          % (U, nn.max(), nn[-1], p[-1], pops[2:].sum()), flush=True)
df = pd.DataFrame(rows)
df.to_csv('figs_q1/data/figure4_U_scan_canonical.csv', index=False)
print('\nsaved figure4_U_scan_canonical.csv')
