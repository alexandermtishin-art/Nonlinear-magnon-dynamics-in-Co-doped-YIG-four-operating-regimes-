"""
=============================================================================
 310 K FREQUENCY SCAN IN THE CANONICAL KERR CONVENTION  --  COLAB, RESUMABLE
=============================================================================

WHY
---
Table 3 of the manuscript currently mixes two Kerr conventions: the sigma
column comes from runs with H_Kerr = (U*Omega/2) a^dag2 a^2, while the
P0+P1 column comes from the archived frequency scan, which used
H_Kerr = U a^dag2 a^2.  For Omega = 1 the second is twice the anharmonicity
of the first, so the same nominal U = 0.55 means different physics in the two
sets.  This script re-runs the frequency scan in the canonical convention, so
that every number in Table 3 and in Fig. 10 rests on one normalization.

MODEL (protocol unchanged from the archived scan)
-------------------------------------------------
    H     = Omega n + (U*Omega/2) a^dag2 a^2 + (eta*Omega/4)(a^dag2 + a^2)
    c_ops = sqrt(kappa (nth+1)) a ,  sqrt(kappa nth) a^dag
    kappa = 2 alpha Omega ,  Omega = 1, U = 0.55, eta = 1.2, alpha = 1e-3
    psi0  = vacuum,  20 drive cycles of T = pi,  T_bath = 310 K
    nth(f) = 1 / (exp(h f / kB T) - 1)   with f the physical drive frequency

HONESTY OF THE RESULT
---------------------
Nothing is accepted on trust:
  * the basis size is raised until the population of the ten highest Fock
    levels falls below TOP10_TOL, and the accepted N is recorded;
  * every accepted point is then repeated at a larger basis and kept only if
    the observables agree to REPEAT_TOL, so convergence is demonstrated rather
    than assumed;
  * the trace of the final density matrix is recorded as an integrator check;
  * all of this goes into the output files, including the runs that failed the
    checks.

CRASH SAFETY
------------
Colab sessions die and Drive mounts drop.  Three levels of protection:

  1. Every finished point is appended to a CSV immediately, so a completed
     point is never recomputed.
  2. Long points are integrated in segments; after each segment the density
     matrix is written to a .npz checkpoint, so an interrupted point resumes
     from the last segment instead of from the vacuum.
  3. Everything is written to local disk first and then mirrored to Drive.  If
     the Drive copy fails the run continues on local disk and retries the
     mirror at the next write; if the mount is gone it is re-mounted.  Local
     files are the authoritative copy inside a session, Drive is the copy that
     survives the session.

USAGE
-----
Paste into a Colab cell and run.  Re-running after any interruption continues
where it stopped; it is safe to run it any number of times.  When it prints
ALL POINTS COMPLETE the scan is done and the summary files are on Drive.
=============================================================================
"""

# --------------------------------------------------------------------------
# 0. Environment
# --------------------------------------------------------------------------
import os
import sys
import json
import time
import shutil
import traceback

try:
    import qutip
except ImportError:
    os.system('pip install -q qutip==5.3.0')
    import qutip

import numpy as np
import pandas as pd
from qutip import Qobj, destroy, basis, mesolve, ket2dm

DRIVE_DIR = '/content/drive/MyDrive/frequency_scan_canonical'
LOCAL_DIR = '/content/frequency_scan_canonical'
CKPT_DIR = 'checkpoints'

RESULTS_CSV = 'frequency_scan_canonical.csv'
ATTEMPTS_CSV = 'frequency_scan_all_attempts.csv'
PROGRESS_TXT = 'CURRENT_PROGRESS.txt'
SUMMARY_JSON = 'frequency_scan_summary.json'
REPORT_TXT = 'frequency_scan_report.txt'


def mount_drive(force=False):
    """Mount Drive, tolerating the case where it is already mounted or the
    session has no Drive at all."""
    try:
        from google.colab import drive
        drive.mount('/content/drive', force_remount=force)
        os.makedirs(DRIVE_DIR, exist_ok=True)
        return True
    except Exception as exc:
        print('   [drive] not available (%s)' % type(exc).__name__)
        return False


HAVE_DRIVE = mount_drive()
os.makedirs(LOCAL_DIR, exist_ok=True)
os.makedirs(os.path.join(LOCAL_DIR, CKPT_DIR), exist_ok=True)


def drive_alive():
    """Cheap test that the mount is still writable."""
    if not HAVE_DRIVE:
        return False
    try:
        probe = os.path.join(DRIVE_DIR, '.probe')
        with open(probe, 'w') as fh:
            fh.write('ok')
        os.remove(probe)
        return True
    except Exception:
        return False


def mirror(name):
    """Copy one file from local to Drive, remounting once if needed."""
    global HAVE_DRIVE
    src = os.path.join(LOCAL_DIR, name)
    if not os.path.exists(src):
        return
    for attempt in (0, 1):
        if not drive_alive():
            if attempt == 0:
                HAVE_DRIVE = mount_drive(force=True)
                continue
            print('   [drive] mirror of %s postponed' % name)
            return
        try:
            dst = os.path.join(DRIVE_DIR, name)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copyfile(src, dst)
            return
        except Exception as exc:
            print('   [drive] copy failed (%s), retrying' % type(exc).__name__)
    return


def atomic_write(name, text):
    """Write locally through a temp file, then mirror."""
    path = os.path.join(LOCAL_DIR, name)
    tmp = path + '.tmp'
    with open(tmp, 'w') as fh:
        fh.write(text)
    os.replace(tmp, path)
    mirror(name)


def append_csv(name, record):
    path = os.path.join(LOCAL_DIR, name)
    header = not os.path.exists(path)
    pd.DataFrame([record]).to_csv(path, mode='a', header=header, index=False)
    mirror(name)


def restore_from_drive():
    """First run in a fresh session: pull back whatever the previous session
    left on Drive."""
    if not drive_alive():
        return
    for name in (RESULTS_CSV, ATTEMPTS_CSV):
        src = os.path.join(DRIVE_DIR, name)
        if os.path.exists(src) and not os.path.exists(os.path.join(LOCAL_DIR, name)):
            shutil.copyfile(src, os.path.join(LOCAL_DIR, name))
            print('   [drive] restored', name)
    src_ck = os.path.join(DRIVE_DIR, CKPT_DIR)
    if os.path.isdir(src_ck):
        for fn in os.listdir(src_ck):
            dst = os.path.join(LOCAL_DIR, CKPT_DIR, fn)
            if not os.path.exists(dst):
                shutil.copyfile(os.path.join(src_ck, fn), dst)
        print('   [drive] restored %d checkpoint(s)' % len(os.listdir(src_ck)))


restore_from_drive()

# --------------------------------------------------------------------------
# 1. Physics
# --------------------------------------------------------------------------
HBAR = 1.054571817e-34
KB = 1.380649e-23
H_PLANCK = 6.62607015e-34

OMEGA = 1.0
U = 0.55
ETA = 1.2
ALPHA = 1.0e-3
KAPPA = 2.0 * ALPHA * OMEGA
NCYC = 20
TCYC = np.pi / OMEGA
T_BATH = 310.0

# frequency grid in THz; denser through the crossover region
FREQS_THZ = [0.05, 0.10, 0.20, 0.30, 0.50, 0.70, 1.00, 1.50, 2.00,
             3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.00, 10.00]

TOP10_TOL = 1e-5         # truncation: population of the ten highest levels
REPEAT_TOL = 2e-3        # relative agreement required between N and 1.35 N
N_MAX = 260
SEG_CYCLES = 1           # cycles per checkpointed segment

SOLVER = {"method": "bdf", "nsteps": 300000, "atol": 1e-9, "rtol": 1e-7,
          "store_final_state": True, "progress_bar": ""}


def n_thermal(f_thz):
    return 1.0 / np.expm1(H_PLANCK * f_thz * 1e12 / (KB * T_BATH))


def build(N, nb):
    a = destroy(N)
    ad = a.dag()
    n = ad * a
    H = (OMEGA * n + 0.5 * U * OMEGA * ad * ad * a * a
         + (ETA * OMEGA / 4.0) * (ad * ad + a * a))
    c_ops = [np.sqrt(KAPPA * (nb + 1.0)) * a, np.sqrt(KAPPA * nb) * ad]
    e_ops = [n, ket2dm(basis(N, 0)) + ket2dm(basis(N, 1)), a * a]
    return H, c_ops, e_ops


def ckpt_name(f_thz, N):
    return os.path.join(CKPT_DIR, 'f%.3fTHz_N%d.npz' % (f_thz, N))


def save_ckpt(f_thz, N, rho, done_cycles):
    name = ckpt_name(f_thz, N)
    path = os.path.join(LOCAL_DIR, name)
    tmp = path + '.tmp.npz'
    np.savez_compressed(tmp, rho=rho, done_cycles=done_cycles, N=N, f=f_thz)
    os.replace(tmp, path)
    mirror(name)


def load_ckpt(f_thz, N):
    path = os.path.join(LOCAL_DIR, ckpt_name(f_thz, N))
    if not os.path.exists(path):
        return None, 0
    try:
        z = np.load(path)
        return z['rho'], int(z['done_cycles'])
    except Exception:
        print('   [ckpt] unreadable, restarting this point from vacuum')
        return None, 0


def drop_ckpt(f_thz, N):
    for base in (LOCAL_DIR, DRIVE_DIR if HAVE_DRIVE else LOCAL_DIR):
        p = os.path.join(base, ckpt_name(f_thz, N))
        if os.path.exists(p):
            try:
                os.remove(p)
            except Exception:
                pass


def run_point(f_thz, N):
    """Integrate 20 cycles in checkpointed segments; return observables."""
    nb = n_thermal(f_thz)
    H, c_ops, e_ops = build(N, nb)
    rho, done = load_ckpt(f_thz, N)
    state = Qobj(rho) if rho is not None else basis(N, 0)
    if rho is not None:
        print('      resuming at cycle %d/%d' % (done, NCYC), flush=True)
    t_start = time.time()
    while done < NCYC:
        seg = min(SEG_CYCLES, NCYC - done)
        tlist = np.linspace(0.0, seg * TCYC, 3)
        res = mesolve(H, state, tlist, c_ops=c_ops, e_ops=e_ops, options=SOLVER)
        state = res.final_state
        done += seg
        save_ckpt(f_thz, N, state.full(), done)
        el = time.time() - t_start
        print('      cycle %2d/%d   %.0f s elapsed, ~%.0f s left' %
              (done, NCYC, el, el * (NCYC - done) / max(done, 1)), flush=True)
        atomic_write(PROGRESS_TXT,
                     'frequency %.3f THz, N = %d, cycle %d/%d\nsaved %s UTC\n' %
                     (f_thz, N, done, NCYC,
                        time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime())))
    rho_f = state.full()
    pops = np.real(np.diag(rho_f))
    a = destroy(N)
    mean_n = float(pops @ np.arange(N))
    rec = dict(frequency_THz=f_thz, nth=nb, N=N,
               mean_n=mean_n,
               P0_plus_P1=float(pops[0] + pops[1]),
               P_n_ge_2=float(pops[2:].sum()),
               abs_aa=float(abs(np.trace(rho_f @ (a * a).full()))),
               normalized_pair=float(abs(np.trace(rho_f @ (a * a).full()))
                                     / (2 * mean_n + 1)),
               top10=float(pops[-10:].sum()),
               trace=float(np.real(np.trace(rho_f))),
               runtime_s=round(time.time() - t_start, 1),
               saved_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
    return rec


def agree(a_rec, b_rec):
    """Relative agreement of the reported observables between two basis sizes."""
    keys = ('mean_n', 'P0_plus_P1', 'abs_aa')
    worst = 0.0
    for k in keys:
        d = abs(a_rec[k] - b_rec[k]) / max(abs(a_rec[k]), 1e-12)
        worst = max(worst, d)
    return worst


def start_basis(nb):
    """Size the basis from the occupancy the run actually reaches, not from the
    bath temperature.  With kappa*t_end = 0.126 the bath only drives the mode
    11.8% of the way towards n_th in 20 cycles, so a basis scaled on n_th is
    wildly oversized: at 50 GHz it asks for N ~ 950 where N ~ 200 suffices.
    The occupancy is estimated as

        n_est = n_th (1 - exp(-kappa t_end)) + n_par ,   n_par ~ 0.3

    and the truncation level from the geometric tail of a thermal-like state,
    x = n_est/(1 + n_est), N = ln(TOP10_TOL)/ln(x) + margin.  Verified against
    a direct run at 0.2 THz: the rule gives N = 77, which yields a top-ten
    population of 2.2e-7 and observables identical to N = 100."""
    frac = 1.0 - np.exp(-KAPPA * NCYC * TCYC)
    n_est = nb * frac + 0.3
    x = n_est / (1.0 + n_est)
    if x < 0.05:
        return 45
    return int(min(N_MAX, max(45, np.log(TOP10_TOL) / np.log(x) + 25)))


# --------------------------------------------------------------------------
# 2. Driver
# --------------------------------------------------------------------------
def main():
    path_done = os.path.join(LOCAL_DIR, RESULTS_CSV)
    done_f = set()
    if os.path.exists(path_done):
        done_f = set(np.round(pd.read_csv(path_done).frequency_THz, 6))
    # cheapest first, so a session that dies still leaves most of the scan
    todo = sorted((f for f in FREQS_THZ if round(f, 6) not in done_f),
                  key=lambda f: -f)
    print('=' * 74)
    print('canonical-convention frequency scan at %.0f K' % T_BATH)
    print('H_Kerr = (U*Omega/2) a^d2 a^2,  U = %.2f, eta = %.1f, alpha = %g' %
          (U, ETA, ALPHA))
    print('%d of %d points already done; %d to go' %
          (len(done_f), len(FREQS_THZ), len(todo)))
    print('=' * 74)

    for f in todo:
        nb = n_thermal(f)
        N = start_basis(nb)
        print('\nf = %.2f THz   nth = %.3f   starting basis N = %d' %
              (f, nb, N), flush=True)
        rec = None
        while True:
            try:
                rec = run_point(f, N)
            except Exception:
                print(traceback.format_exc())
                print('   point failed at N = %d; will be retried on rerun' % N)
                return
            rec['check'] = 'truncation' if rec['top10'] > TOP10_TOL else 'ok'
            append_csv(ATTEMPTS_CSV, rec)
            print('   N=%-4d <n>=%9.4f  P0+P1=%.5f  |<aa>|=%.5f  top10=%.1e  '
                  'trace=%.9f  %.0f s' %
                  (rec['N'], rec['mean_n'], rec['P0_plus_P1'], rec['abs_aa'],
                     rec['top10'], rec['trace'], rec['runtime_s']), flush=True)
            if rec['top10'] > TOP10_TOL and N < N_MAX:
                N = int(min(N_MAX, N * 1.25))
                print('   truncated, enlarging basis to N = %d' % N)
                continue
            break

        # convergence has to be shown, not assumed: repeat at a larger basis
        N_big = int(min(N_MAX, N * 1.20))
        if N_big > N:
            print('   convergence check at N = %d ...' % N_big, flush=True)
            big = run_point(f, N_big)
            big['check'] = 'convergence-check'
            append_csv(ATTEMPTS_CSV, big)
            worst = agree(rec, big)
            print('   worst relative change %.2e (tolerance %.0e)' %
                  (worst, REPEAT_TOL))
            rec['converged'] = bool(worst < REPEAT_TOL)
            rec['convergence_N'] = N_big
            rec['convergence_worst_rel'] = worst
            if not rec['converged']:
                rec = big
                rec['converged'] = False
                rec['convergence_N'] = N_big
                rec['convergence_worst_rel'] = worst
                print('   NOT converged; the larger-basis values are reported')
            drop_ckpt(f, N_big)
        else:
            rec['converged'] = None
            rec['convergence_N'] = None
            rec['convergence_worst_rel'] = None

        append_csv(RESULTS_CSV, rec)
        drop_ckpt(f, N)

    # ---------------------------------------------------------------- report
    if not os.path.exists(path_done):
        print('nothing computed yet')
        return
    df = pd.read_csv(path_done).sort_values('frequency_THz')
    lines = []
    lines.append('310 K frequency scan, canonical Kerr convention '
                 '(U*Omega/2) a^d2 a^2')
    lines.append('U = %.2f, eta = %.1f, alpha = %g, %d cycles of T = pi, '
                 'static effective pair drive' % (U, ETA, ALPHA, NCYC))
    lines.append('')
    lines.append('%-9s %-9s %-5s %-11s %-10s %-10s %-10s %-9s' %
                 ('f (THz)', 'nth', 'N', '<n>', 'P0+P1', '|<aa>|',
                    'top10', 'converged'))
    for _, r in df.iterrows():
        lines.append('%-9.2f %-9.3f %-5d %-11.5f %-10.5f %-10.5f %-10.1e %-9s' %
                     (r.frequency_THz, r.nth, r.N, r.mean_n, r.P0_plus_P1,
                        r.abs_aa, r.top10, r.get('converged', '')))
    lines.append('')
    lines.append('points complete: %d of %d' % (len(df), len(FREQS_THZ)))
    bad = df[df.top10 > TOP10_TOL] if 'top10' in df else df.iloc[0:0]
    if len(bad):
        lines.append('WARNING: %d point(s) still truncated at N_MAX = %d: %s' %
                     (len(bad), N_MAX, list(bad.frequency_THz)))
    txt = '\n'.join(lines)
    atomic_write(REPORT_TXT, txt + '\n')
    atomic_write(SUMMARY_JSON, json.dumps(
        {str(r.frequency_THz): r.dropna().to_dict() for _, r in df.iterrows()},
        indent=1))
    print()
    print(txt)
    if len(df) == len(FREQS_THZ):
        print('\nALL POINTS COMPLETE')
        print('files on Drive:', DRIVE_DIR if HAVE_DRIVE else '(local only) '
              + LOCAL_DIR)
    else:
        print('\nrun this cell again to continue')


if __name__ == '__main__':
    main()
