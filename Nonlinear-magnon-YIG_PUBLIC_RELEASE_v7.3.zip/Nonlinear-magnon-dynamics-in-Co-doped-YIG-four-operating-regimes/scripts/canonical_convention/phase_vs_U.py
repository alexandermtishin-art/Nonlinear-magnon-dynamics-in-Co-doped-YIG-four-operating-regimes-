"""Does the pair-phase transfer survive at small U?

The five-phase control result (slope -0.99984, R^2 = 0.9999993) was obtained at
U = 0.55.  If the transfer coefficient is kinematic it should not depend on U,
and would then be the one result of the paper that survives the fact that
U = 0.1-0.55 is not reachable in a garnet.  Protocol identical to
scripts/five_phase_control.py; only U and the basis size are varied.
"""
import numpy as np, time
from qutip import destroy, basis, mesolve
OM, ETA, ALPHA = 1.0, 1.2, 0.01
KAP = 2*ALPHA*OM
OPTS = {"method":"bdf","nsteps":200000,"atol":1e-9,"rtol":1e-7,"progress_bar":""}
PH = [0.0, np.pi/2, np.pi]

def run(U, N):
    t = np.linspace(0,100,3001); tail = np.arange(len(t)) >= len(t)//2
    a = destroy(N); ad = a.dag(); n = ad*a; aa = a*a; pair = ad*ad + a*a
    H0 = OM*n + 0.5*U*OM*ad*ad*a*a
    c = [np.sqrt(KAP)*a]
    out = []
    for p in PH:
        f = lambda tt, p=p, **kw: 0.5*ETA*OM*np.sin(2*OM*tt + p)
        r = mesolve([H0,[pair,f]], basis(N,0), t, c_ops=c, e_ops=[n,aa], options=OPTS)
        nt = np.real(r.expect[0]); mt = np.asarray(r.expect[1], complex)
        amp = np.abs(mt)
        phi = np.unwrap(np.angle(mt)) + 2*OM*t
        v = tail & (amp > max(1e-6, 0.02*amp.max()))
        w = (phi[v] + np.pi) % (2*np.pi) - np.pi
        R = abs(np.mean(np.exp(1j*w)))
        out.append((np.angle(np.mean(np.exp(1j*w))), nt[tail].mean(),
                    amp[tail].mean(), np.degrees(np.sqrt(-2*np.log(R)))))
    ph_out = np.unwrap([o[0] for o in out])
    slope, icpt = np.polyfit(PH, ph_out, 1)
    pred = icpt + slope*np.array(PH)
    ss = 1 - np.sum((ph_out-pred)**2)/max(np.sum((ph_out-np.mean(ph_out))**2),1e-30)
    return slope, ss, np.mean([o[1] for o in out]), np.mean([o[2] for o in out]), \
           np.mean([o[3] for o in out])

print('%-8s %-5s %-11s %-12s %-10s %-10s %-8s'%('U','N','slope','R^2','<n>','|<aa>|','sigma'))
for U,N in ((0.55,50),(0.10,60)):
    t0=time.time(); s,r2,nn,aa_,sg = run(U,N)
    print('%-8g %-5d %-11.5f %-12.7f %-10.4f %-10.4f %-8.2f  (%.0f c)'
          %(U,N,s,r2,nn,aa_,sg,time.time()-t0), flush=True)
