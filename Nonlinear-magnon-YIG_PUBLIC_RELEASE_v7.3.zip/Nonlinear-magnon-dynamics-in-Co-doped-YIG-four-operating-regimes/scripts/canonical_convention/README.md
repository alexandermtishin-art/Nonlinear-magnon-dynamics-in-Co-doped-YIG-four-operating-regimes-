# Canonical Kerr convention

The archived frequency scan used `H_Kerr = U a^d2 a^2`; the protocol audit, the
five-phase runs and the phase-statistics campaign use
`H_Kerr = (U Omega/2) a^d2 a^2`.  For Omega = 1 the first is twice the
anharmonicity of the second, so results must not be carried between them.
These scripts put the scans on the canonical footing.

`rescan_U.py`
: the Fig. 4 U scan, 13 points, canonical convention.  At U = 0.55 it gives
  max_t<n> = 0.2288, late-time <n> = 0.1179, P0+P1 = 0.9684, matching the
  protocol audit.

`colab_frequency_scan_canonical.py`
: the 310 K frequency scan, 17 points from 50 GHz to 10 THz.  Written for Colab
  and designed to survive interruption: every finished point is appended to CSV
  immediately, long points are integrated in checkpointed one-cycle segments,
  and all writes go to local disk first and are then mirrored to Drive, with a
  remount attempt if the mount is lost.  Basis size is chosen from the occupancy
  the run actually reaches, not from the bath temperature, and every point is
  repeated at 1.2 N to demonstrate convergence rather than assume it.

`phase_vs_U.py`
: does the pair-phase transfer depend on U?  Repeating the five-phase protocol
  at U = 0.55, 0.10 and 0.02, over which the late-time occupancy rises from 1.2
  to 30 magnons, leaves the slope at -1.00000 with R^2 = 0.999999 throughout.
  The transfer is kinematic, so phase encoding survives in the parameter range
  where Fock-manifold confinement does not.
