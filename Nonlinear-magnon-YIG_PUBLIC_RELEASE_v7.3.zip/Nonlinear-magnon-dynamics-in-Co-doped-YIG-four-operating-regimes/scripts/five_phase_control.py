"""Five-phase test for externally controlled anomalous pair coherence."""
from pathlib import Path
import numpy as np, pandas as pd, matplotlib.pyplot as plt
from qutip import destroy,basis,mesolve
OUT=Path(__file__).resolve().parents[1]/"results"/"five_phase_control"; OUT.mkdir(parents=True,exist_ok=True)
Omega,U,eta,alpha,N=1.0,0.55,1.2,0.01,50; kappa=2*alpha*Omega
t=np.linspace(0,100,3001); tail=np.arange(len(t))>=len(t)//2
phases=np.array([0,np.pi/4,np.pi/2,3*np.pi/4,np.pi])
a=destroy(N); ad=a.dag(); n=ad*a; aa=a*a; pair=ad*ad+a*a
H0=Omega*n+0.5*U*Omega*ad*ad*a*a; c=[np.sqrt(kappa)*a]
opts={"method":"bdf","nsteps":100000,"atol":1e-9,"rtol":1e-7,"progress_bar":False}
wrap=lambda x:(x+np.pi)%(2*np.pi)-np.pi
rows=[]; dyn={"time":t}
for i,p in enumerate(phases):
    def f(tt, **kwargs): return 0.5*eta*Omega*np.sin(2*Omega*tt+p)
    r=mesolve([H0,[pair,f]],basis(N,0),t,c,[n,aa],options=opts)
    nt=np.real(r.expect[0]); mt=np.asarray(r.expect[1],complex); amp=abs(mt)
    phi=np.unwrap(np.angle(mt))+2*Omega*t
    valid=tail&(amp>max(1e-6,0.02*amp.max())); w=wrap(phi[valid]); z=np.mean(np.exp(1j*w)); R=abs(z)
    rows.append(dict(phi_d_rad=p,phi_d_over_pi=p/np.pi,mean_n=nt[tail].mean(),std_n=nt[tail].std(),
      mean_abs_aa=amp[tail].mean(),std_abs_aa=amp[tail].std(),mean_pair_phase_rad=np.angle(z),
      phase_resultant_length=R,phase_circular_std_rad=np.sqrt(-2*np.log(R))))
    dyn[f"phi_{i}_mean_n"]=nt; dyn[f"phi_{i}_abs_aa"]=amp; dyn[f"phi_{i}_rotating_phase"]=phi
s=pd.DataFrame(rows); s.to_csv(OUT/"summary.csv",index=False); pd.DataFrame(dyn).to_csv(OUT/"dynamics.csv",index=False)
x=s.phi_d_rad.to_numpy(); y=np.unwrap(s.mean_pair_phase_rad.to_numpy()); slope,intercept=np.polyfit(x,y,1); yf=intercept+slope*x
r2=1-np.sum((y-yf)**2)/np.sum((y-y.mean())**2)
pd.DataFrame({"quantity":["slope","intercept_rad","fit_rms_rad","r_squared"],"value":[slope,intercept,np.sqrt(np.mean((y-yf)**2)),r2]}).to_csv(OUT/"fit.csv",index=False)
plt.figure(figsize=(8,5.5)); plt.scatter(x,y,label="Lindblad result"); xx=np.linspace(x.min(),x.max(),300); plt.plot(xx,intercept+slope*xx,label=f"fit slope={slope:.3f}, R²={r2:.4f}"); plt.xlabel(r"Drive phase $\phi_d$"); plt.ylabel("Late-time rotating-frame pair phase"); plt.legend(); plt.tight_layout(); plt.savefig(OUT/"phase_transfer.png",dpi=300); plt.close()
print(s.to_string(index=False)); print(f"slope={slope:.10f}, intercept={intercept:.10f}, R2={r2:.10f}")
