
# =============================================================================
# GOOGLE COLAB — НОВЫЙ РАСЧЁТ ТОЛЬКО С 21-ГО ПРОГОНА
# =============================================================================
#
# Считает только оставшиеся 18 точек:
#
#   U = 0.55
#   f = 0.075, 0.100, 0.150, ..., 10.000 THz
#
# Первая точка U=0.55, f=0.050 THz уже была рассчитана ранее,
# поэтому здесь она намеренно пропущена.
#
# Все результаты после КАЖДОЙ точки сохраняются в Google Drive:
#
#   MyDrive/finite_temperature_frequency_scan_FROM_RUN_21/
#
# Если Colab прервётся ночью, просто снова запустите эту же ячейку:
# программа прочитает checkpoint и продолжит только отсутствующие точки.
#
# Модель:
#
#   H = Omega*n
#       + U*a.dag()**2*a**2
#       + (eta*Omega/4)*(a.dag()**2 + a**2)
#
#   L_down = sqrt[kappa*(n_th+1)] * a
#   L_up   = sqrt[kappa*n_th]     * a.dag()
#
#   n_th = 1 / (exp(hbar*2*pi*f/(kB*T)) - 1)
#
# =============================================================================


# -----------------------------------------------------------------------------
# 1. Установка библиотек
# -----------------------------------------------------------------------------

import os
import sys
import csv
import json
import time
import shutil
import zipfile
import subprocess
from pathlib import Path
from datetime import datetime, timezone

import numpy as np


try:
    import qutip
except ImportError:
    subprocess.check_call([
        sys.executable,
        "-m",
        "pip",
        "install",
        "-q",
        "qutip==5.3.0",
    ])


import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from qutip import destroy, basis, mesolve


# -----------------------------------------------------------------------------
# 2. Подключение Google Drive
# -----------------------------------------------------------------------------

from google.colab import drive, files


def find_or_mount_drive():
    """
    Использует уже подключённый Google Drive либо монтирует его
    в свободную папку, чтобы не конфликтовать с /content/drive.
    """

    possible_roots = [
        Path("/content/drive/MyDrive"),
        Path("/content/gdrive/MyDrive"),
        Path("/content/gdrive2/MyDrive"),
    ]

    for root in possible_roots:
        if root.exists():
            print(f"Google Drive уже подключён: {root}")
            return root

    mountpoint = Path("/content/gdrive2")

    if mountpoint.exists():
        if mountpoint.is_symlink():
            mountpoint.unlink()
        elif mountpoint.is_dir():
            shutil.rmtree(mountpoint)
        else:
            mountpoint.unlink()

    drive.mount(str(mountpoint))

    root = mountpoint / "MyDrive"

    if not root.exists():
        raise RuntimeError(
            "Google Drive подключён, но папка MyDrive не найдена."
        )

    print(f"Google Drive подключён: {root}")
    return root


MY_DRIVE = find_or_mount_drive()


# -----------------------------------------------------------------------------
# 3. Параметры модели
# -----------------------------------------------------------------------------

HBAR = 1.054571817e-34
KB = 1.380649e-23

OMEGA = 1.0
ETA = 1.2
ALPHA = 1.0e-3
KAPPA = 2.0 * ALPHA * OMEGA

TEMPERATURE_K = 310.0

# Считаем только U=0.55.
U = 0.55

# Прогон 20 (50 GHz) уже был выполнен ранее.
# Новый расчёт начинается с общего номера 21.
FREQUENCIES_HZ = np.array([
    75e9,
    100e9,
    150e9,
    200e9,
    300e9,
    500e9,
    750e9,
    1.0e12,
    1.5e12,
    2.0e12,
    3.0e12,
    4.0e12,
    5.0e12,
    6.0e12,
    7.0e12,
    8.0e12,
    9.0e12,
    10.0e12,
], dtype=float)

FIRST_GLOBAL_RUN_INDEX = 21
TOTAL_GLOBAL_RUNS = 38

N = 140
NCYC = 20
PTS_PER_CYCLE = 10
TCYC = np.pi / OMEGA

SOLVER_OPTIONS = {
    "atol": 1.0e-9,
    "rtol": 1.0e-7,
    "nsteps": 500000,
    "method": "bdf",
    "store_states": False,
    "store_final_state": True,
    "progress_bar": "",
}


# -----------------------------------------------------------------------------
# 4. Папки и файлы
# -----------------------------------------------------------------------------

OUTPUT_DIR = (
    MY_DRIVE
    / "finite_temperature_frequency_scan_FROM_RUN_21"
)

INDIVIDUAL_DIR = OUTPUT_DIR / "individual_runs"
PLOTS_DIR = OUTPUT_DIR / "plots"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
INDIVIDUAL_DIR.mkdir(parents=True, exist_ok=True)
PLOTS_DIR.mkdir(parents=True, exist_ok=True)

CSV_PATH = OUTPUT_DIR / "frequency_scan_U_0p55_from_run_21.csv"
SUMMARY_PATH = OUTPUT_DIR / "frequency_scan_U_0p55_from_run_21.json"
CHECKPOINT_PATH = OUTPUT_DIR / "checkpoint_U_0p55_from_run_21.json"
LOG_PATH = OUTPUT_DIR / "calculation_log.txt"
ZIP_PATH = OUTPUT_DIR / "frequency_scan_U_0p55_FROM_RUN_21_latest.zip"


CSV_COLUMNS = [
    "global_run_index",
    "local_run_index",
    "frequency_Hz",
    "frequency_GHz",
    "frequency_THz",
    "temperature_K",
    "thermal_occupation_nth",
    "U",
    "N",
    "cycles",
    "points_per_cycle",
    "runtime_s",
    "max_mean_n",
    "final_mean_n",
    "min_P0_plus_P1",
    "final_P0_plus_P1",
    "final_P_n_ge_2",
    "final_pair_abs",
    "final_normalized_pair_abs",
    "final_population_top_10_levels",
    "final_population_highest_level",
    "completed_at_utc",
]


# -----------------------------------------------------------------------------
# 5. Вспомогательные функции
# -----------------------------------------------------------------------------

def utc_now():
    return datetime.now(timezone.utc).isoformat()


def log(message=""):
    message = str(message)
    print(message, flush=True)

    with open(LOG_PATH, "a", encoding="utf-8") as handle:
        handle.write(f"[{utc_now()}] {message}\n")


def thermal_occupation(freq_hz, temperature_k):
    if temperature_k <= 0.0:
        return 0.0

    exponent = (
        HBAR * 2.0 * np.pi * freq_hz
        / (KB * temperature_k)
    )

    return 1.0 / np.expm1(exponent)


def expected_global_index(local_index):
    return FIRST_GLOBAL_RUN_INDEX + local_index - 1


def frequency_key(freq_hz):
    return f"{float(freq_hz):.6f}"


def build_operators():
    a = destroy(N)
    ad = a.dag()
    n_op = ad * a

    p0 = basis(N, 0) * basis(N, 0).dag()
    p1 = basis(N, 1) * basis(N, 1).dag()
    p01_op = p0 + p1

    aa_op = a * a

    return a, ad, n_op, p01_op, aa_op


# -----------------------------------------------------------------------------
# 6. Загрузка уже выполненных точек
# -----------------------------------------------------------------------------

def normalize_row(raw):
    row = {}

    integer_fields = {
        "global_run_index",
        "local_run_index",
        "N",
        "cycles",
        "points_per_cycle",
    }

    string_fields = {"completed_at_utc"}

    for column in CSV_COLUMNS:
        value = raw[column]

        if column in integer_fields:
            row[column] = int(float(value))
        elif column in string_fields:
            row[column] = str(value)
        else:
            row[column] = float(value)

    return row


def row_is_valid(row):
    local_index = int(row["local_run_index"])

    if not 1 <= local_index <= len(FREQUENCIES_HZ):
        return False

    expected_freq = FREQUENCIES_HZ[local_index - 1]
    expected_global = expected_global_index(local_index)

    return (
        int(row["global_run_index"]) == expected_global
        and np.isclose(row["frequency_Hz"], expected_freq, atol=1.0)
        and np.isclose(row["U"], U, atol=1e-12)
        and np.isclose(
            row["temperature_K"],
            TEMPERATURE_K,
            atol=1e-12,
        )
        and int(row["N"]) == N
        and int(row["cycles"]) == NCYC
        and int(row["points_per_cycle"]) == PTS_PER_CYCLE
    )


def load_existing_rows():
    rows_by_frequency = {}

    # Сначала читаем общий CSV.
    if CSV_PATH.exists():
        try:
            with open(
                CSV_PATH,
                "r",
                encoding="utf-8",
                newline="",
            ) as handle:
                reader = csv.DictReader(handle)

                for raw in reader:
                    row = normalize_row(raw)

                    if row_is_valid(row):
                        rows_by_frequency[
                            frequency_key(row["frequency_Hz"])
                        ] = row

        except Exception as exc:
            log(f"Не удалось прочитать CSV: {exc}")

    # Затем читаем индивидуальные JSON — они имеют приоритет.
    for json_path in sorted(INDIVIDUAL_DIR.glob("run_*.json")):
        try:
            with open(
                json_path,
                "r",
                encoding="utf-8",
            ) as handle:
                payload = json.load(handle)

            raw = payload.get("result", payload)
            row = normalize_row(raw)

            if row_is_valid(row):
                rows_by_frequency[
                    frequency_key(row["frequency_Hz"])
                ] = row

        except Exception as exc:
            log(
                f"Не удалось прочитать {json_path.name}: {exc}"
            )

    return rows_by_frequency


# -----------------------------------------------------------------------------
# 7. Сохранение
# -----------------------------------------------------------------------------

def individual_json_path(row):
    global_index = int(row["global_run_index"])
    freq_thz = row["frequency_THz"]

    freq_text = (
        f"{freq_thz:.3f}"
        .replace(".", "p")
    )

    return (
        INDIVIDUAL_DIR
        / f"run_{global_index:03d}_U_0p55_f_{freq_text}THz.json"
    )


def save_individual_row(row):
    path = individual_json_path(row)
    temporary = path.with_suffix(".json.tmp")

    payload = {
        "model": {
            "Hamiltonian":
                "H = Omega*n + U*a.dag()**2*a**2 "
                "+ (eta*Omega/4)*(a.dag()**2 + a**2)",
            "Omega": OMEGA,
            "eta": ETA,
            "alpha": ALPHA,
            "kappa": KAPPA,
            "temperature_K": TEMPERATURE_K,
            "U": U,
            "N": N,
            "cycles": NCYC,
            "points_per_cycle": PTS_PER_CYCLE,
            "initial_state": "vacuum",
        },
        "result": row,
    }

    with open(
        temporary,
        "w",
        encoding="utf-8",
    ) as handle:
        json.dump(
            payload,
            handle,
            indent=2,
            ensure_ascii=False,
        )

    os.replace(temporary, path)


def ordered_rows(rows_by_frequency):
    rows = list(rows_by_frequency.values())
    return sorted(
        rows,
        key=lambda row: row["frequency_Hz"],
    )


def save_csv(rows_by_frequency):
    temporary = CSV_PATH.with_suffix(".csv.tmp")

    with open(
        temporary,
        "w",
        encoding="utf-8",
        newline="",
    ) as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=CSV_COLUMNS,
        )
        writer.writeheader()

        for row in ordered_rows(rows_by_frequency):
            writer.writerow(row)

    os.replace(temporary, CSV_PATH)


def missing_frequencies(rows_by_frequency):
    completed_keys = set(rows_by_frequency.keys())

    return [
        float(freq_hz)
        for freq_hz in FREQUENCIES_HZ
        if frequency_key(freq_hz) not in completed_keys
    ]


def save_summary_and_checkpoint(rows_by_frequency):
    rows = ordered_rows(rows_by_frequency)
    missing = missing_frequencies(rows_by_frequency)

    summary = {
        "generated_at_utc": utc_now(),
        "description":
            "Continuation of the original 38-run scan. "
            "Contains global runs 21-38 only.",
        "model": {
            "Hamiltonian":
                "H = Omega*n + U*a.dag()**2*a**2 "
                "+ (eta*Omega/4)*(a.dag()**2 + a**2)",
            "Omega": OMEGA,
            "eta": ETA,
            "alpha": ALPHA,
            "kappa": KAPPA,
            "temperature_K": TEMPERATURE_K,
            "U": U,
            "N": N,
            "cycles": NCYC,
            "points_per_cycle": PTS_PER_CYCLE,
            "initial_state": "vacuum",
        },
        "completed_new_runs": len(rows),
        "expected_new_runs": len(FREQUENCIES_HZ),
        "missing_frequencies_Hz": missing,
        "runs": rows,
    }

    checkpoint = {
        "updated_at_utc": utc_now(),
        "completed_new_runs": len(rows),
        "expected_new_runs": len(FREQUENCIES_HZ),
        "completed_global_run_indices": [
            int(row["global_run_index"])
            for row in rows
        ],
        "missing_frequencies_Hz": missing,
        "next_frequency_Hz":
            missing[0] if missing else None,
    }

    for path, payload in [
        (SUMMARY_PATH, summary),
        (CHECKPOINT_PATH, checkpoint),
    ]:
        temporary = path.with_suffix(path.suffix + ".tmp")

        with open(
            temporary,
            "w",
            encoding="utf-8",
        ) as handle:
            json.dump(
                payload,
                handle,
                indent=2,
                ensure_ascii=False,
            )

        os.replace(temporary, path)


def create_zip_backup():
    temporary_zip = ZIP_PATH.with_name(
        ZIP_PATH.stem + "_writing.zip"
    )

    if temporary_zip.exists():
        temporary_zip.unlink()

    with zipfile.ZipFile(
        temporary_zip,
        mode="w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=6,
    ) as archive:

        for path in OUTPUT_DIR.rglob("*"):
            if not path.is_file():
                continue

            if path in {ZIP_PATH, temporary_zip}:
                continue

            relative = (
                Path(OUTPUT_DIR.name)
                / path.relative_to(OUTPUT_DIR)
            )

            archive.write(
                path,
                relative.as_posix(),
            )

    os.replace(temporary_zip, ZIP_PATH)


def save_all(rows_by_frequency, make_zip=True):
    save_csv(rows_by_frequency)
    save_summary_and_checkpoint(rows_by_frequency)

    if make_zip:
        create_zip_backup()


# -----------------------------------------------------------------------------
# 8. Один расчёт
# -----------------------------------------------------------------------------

def run_one_frequency(
    local_index,
    freq_hz,
    a,
    ad,
    n_op,
    p01_op,
    aa_op,
):
    global_index = expected_global_index(local_index)

    H = (
        OMEGA * n_op
        + U * ad * ad * a * a
        + (ETA * OMEGA / 4.0) * (ad * ad + a * a)
    )

    nth = thermal_occupation(
        freq_hz,
        TEMPERATURE_K,
    )

    c_ops = [
        np.sqrt(KAPPA * (nth + 1.0)) * a,
        np.sqrt(KAPPA * nth) * ad,
    ]

    psi0 = basis(N, 0)

    tlist = np.linspace(
        0.0,
        NCYC * TCYC,
        NCYC * PTS_PER_CYCLE + 1,
    )

    start_time = time.time()

    result = mesolve(
        H,
        psi0,
        tlist,
        c_ops=c_ops,
        e_ops=[
            n_op,
            p01_op,
            aa_op,
        ],
        options=SOLVER_OPTIONS,
    )

    runtime_s = time.time() - start_time

    mean_n = np.real(
        np.asarray(result.expect[0])
    )

    p01 = np.real(
        np.asarray(result.expect[1])
    )

    pair = np.asarray(
        result.expect[2],
        dtype=complex,
    )

    pair_abs = np.abs(pair)

    normalized_pair = (
        pair_abs
        / (2.0 * mean_n + 1.0)
    )

    final_state = result.final_state

    populations = np.real(
        np.diag(final_state.full())
    )

    populations = np.maximum(
        populations,
        0.0,
    )

    probability_sum = populations.sum()

    if probability_sum <= 0.0:
        raise RuntimeError(
            "Некорректная финальная плотность вероятности."
        )

    populations /= probability_sum

    row = {
        "global_run_index": int(global_index),
        "local_run_index": int(local_index),
        "frequency_Hz": float(freq_hz),
        "frequency_GHz": float(freq_hz / 1e9),
        "frequency_THz": float(freq_hz / 1e12),
        "temperature_K": float(TEMPERATURE_K),
        "thermal_occupation_nth": float(nth),
        "U": float(U),
        "N": int(N),
        "cycles": int(NCYC),
        "points_per_cycle": int(PTS_PER_CYCLE),
        "runtime_s": float(runtime_s),
        "max_mean_n": float(np.max(mean_n)),
        "final_mean_n": float(mean_n[-1]),
        "min_P0_plus_P1": float(np.min(p01)),
        "final_P0_plus_P1": float(p01[-1]),
        "final_P_n_ge_2": float(1.0 - p01[-1]),
        "final_pair_abs": float(pair_abs[-1]),
        "final_normalized_pair_abs": float(
            normalized_pair[-1]
        ),
        "final_population_top_10_levels": float(
            np.sum(populations[-10:])
        ),
        "final_population_highest_level": float(
            populations[-1]
        ),
        "completed_at_utc": utc_now(),
    }

    return row


# -----------------------------------------------------------------------------
# 9. Графики только для новых 18 точек U=0.55
# -----------------------------------------------------------------------------

def make_plots(rows_by_frequency):
    rows = ordered_rows(rows_by_frequency)

    if not rows:
        return

    x = np.array([
        row["frequency_THz"]
        for row in rows
    ])

    plots = [
        (
            "final_P0_plus_P1",
            "Final P0 + P1",
            "Low-Fock weight at U = 0.55 and T = 310 K",
            "Figure_U_0p55_P01",
            False,
        ),
        (
            "final_mean_n",
            "Final mean occupation <n>",
            "Mean occupation at U = 0.55 and T = 310 K",
            "Figure_U_0p55_mean_n",
            False,
        ),
        (
            "final_pair_abs",
            "Final |<aa>|",
            "Pair amplitude at U = 0.55 and T = 310 K",
            "Figure_U_0p55_pair",
            False,
        ),
        (
            "final_normalized_pair_abs",
            "|<aa>| / (2<n> + 1)",
            "Normalized pair amplitude at U = 0.55 and T = 310 K",
            "Figure_U_0p55_normalized_pair",
            False,
        ),
        (
            "thermal_occupation_nth",
            "Thermal occupation n_th",
            "Thermal occupation at T = 310 K",
            "Figure_U_0p55_nth",
            True,
        ),
    ]

    for key, ylabel, title, filename, log_y in plots:
        y = np.array([
            row[key]
            for row in rows
        ])

        fig, ax = plt.subplots(
            figsize=(8.5, 5.8)
        )

        ax.plot(
            x,
            y,
            marker="o",
            linewidth=1.5,
            markersize=4.5,
        )

        ax.set_xlabel(
            "Physical frequency f (THz)"
        )
        ax.set_ylabel(ylabel)
        ax.set_title(title)
        ax.set_xlim(0.0, 10.2)
        ax.grid(True, alpha=0.25)

        if log_y:
            ax.set_yscale("log")

        fig.tight_layout()

        fig.savefig(
            PLOTS_DIR / f"{filename}.png",
            dpi=220,
        )

        fig.savefig(
            PLOTS_DIR / f"{filename}.pdf"
        )

        plt.close(fig)


# -----------------------------------------------------------------------------
# 10. Основной цикл
# -----------------------------------------------------------------------------

def main():
    print("=" * 79)
    print("НОВЫЙ РАСЧЁТ: ТОЛЬКО ПРОГОНЫ 21–38")
    print("=" * 79)
    print(f"Google Drive: {MY_DRIVE}")
    print(f"Папка результатов: {OUTPUT_DIR}")
    print(f"U = {U}")
    print(f"T = {TEMPERATURE_K} K")
    print(f"N = {N}")
    print(f"Число циклов = {NCYC}")
    print()

    rows_by_frequency = load_existing_rows()
    missing = missing_frequencies(rows_by_frequency)

    print(
        f"Уже завершено в новом расчёте: "
        f"{len(rows_by_frequency)}/{len(FREQUENCIES_HZ)}"
    )

    if missing:
        first_freq = missing[0]

        local_index = int(
            np.where(
                np.isclose(
                    FREQUENCIES_HZ,
                    first_freq,
                )
            )[0][0]
        ) + 1

        global_index = expected_global_index(
            local_index
        )

        print(
            f"Следующий прогон: "
            f"{global_index}/{TOTAL_GLOBAL_RUNS}, "
            f"U={U:.2f}, "
            f"f={first_freq/1e12:.3f} THz"
        )
    else:
        print("Все новые 18 точек уже рассчитаны.")
        make_plots(rows_by_frequency)
        save_all(rows_by_frequency, make_zip=True)
        return

    a, ad, n_op, p01_op, aa_op = build_operators()

    try:
        for local_index, freq_hz in enumerate(
            FREQUENCIES_HZ,
            start=1,
        ):
            key = frequency_key(freq_hz)

            if key in rows_by_frequency:
                continue

            global_index = expected_global_index(
                local_index
            )

            nth = thermal_occupation(
                freq_hz,
                TEMPERATURE_K,
            )

            log("")
            log("-" * 79)
            log(
                f"Прогон {global_index}/{TOTAL_GLOBAL_RUNS} "
                f"| новый {local_index}/{len(FREQUENCIES_HZ)}"
            )
            log(
                f"U={U:.2f}, "
                f"f={freq_hz/1e12:.3f} THz, "
                f"n_th={nth:.6f}"
            )

            row = run_one_frequency(
                local_index=local_index,
                freq_hz=freq_hz,
                a=a,
                ad=ad,
                n_op=n_op,
                p01_op=p01_op,
                aa_op=aa_op,
            )

            save_individual_row(row)

            rows_by_frequency[key] = row

            save_all(
                rows_by_frequency,
                make_zip=True,
            )

            make_plots(rows_by_frequency)

            log(
                f"ГОТОВО: "
                f"final<n>={row['final_mean_n']:.6f} | "
                f"P01={row['final_P0_plus_P1']:.6f} | "
                f"P(n>=2)={row['final_P_n_ge_2']:.6f} | "
                f"|<aa>|={row['final_pair_abs']:.6f} | "
                f"norm_pair="
                f"{row['final_normalized_pair_abs']:.6f} | "
                f"top10="
                f"{row['final_population_top_10_levels']:.3e} | "
                f"time={row['runtime_s']:.1f}s"
            )

            log(
                "Результат, checkpoint, графики и ZIP "
                "сохранены в Google Drive."
            )

    except KeyboardInterrupt:
        log("")
        log(
            "Расчёт остановлен. "
            "Все завершённые точки уже сохранены."
        )

        save_all(
            rows_by_frequency,
            make_zip=True,
        )

        make_plots(rows_by_frequency)

        log(f"ZIP: {ZIP_PATH}")
        return

    except Exception as exc:
        log("")
        log(
            f"ОШИБКА: "
            f"{type(exc).__name__}: {exc}"
        )

        save_all(
            rows_by_frequency,
            make_zip=True,
        )

        make_plots(rows_by_frequency)

        raise

    make_plots(rows_by_frequency)

    save_all(
        rows_by_frequency,
        make_zip=True,
    )

    print()
    print("=" * 79)
    print("ВСЕ ПРОГОНЫ 21–38 ЗАВЕРШЕНЫ")
    print("=" * 79)
    print(f"CSV: {CSV_PATH}")
    print(f"JSON: {SUMMARY_PATH}")
    print(f"Checkpoint: {CHECKPOINT_PATH}")
    print(f"Графики: {PLOTS_DIR}")
    print(f"ZIP: {ZIP_PATH}")
    print()
    print(
        "Файлы уже сохранены на Google Drive. "
        "Для локального скачивания ZIP выполните:"
    )
    print(f"files.download(r'{ZIP_PATH}')")


main()
