# Multimode analysis

Tests the single-mode approximation on both carriers.

`multimode_stability.py`
: linear parametric growth rate s(delta) = sqrt(h^2 - delta^2) - kappa/2 across
  the confined spectrum f(k) = f_uniform + gamma (2A/Ms) k^2; counts the modes
  above threshold.  One mode on the 50 GHz carrier, where the 36 GHz exchange
  gap exceeds the 15 GHz gain band; 589 at 6 THz, where the level spacing has
  fallen to the damping linewidth.

`multimode_meanfield.py`
: mean-field integration of all modes in the gain band with self- and
  cross-Kerr coupling, seeded equally, over the same 20 drive cycles.  Inverse
  participation ratio 1.0 at 50 GHz, the excitation staying entirely in the
  driven mode, against 52.8 at 6 THz, where the nominally driven mode retains
  0.4% of the total.

The uniform-mode offset in the spectrum is essential: omitting it changes the
count on the microwave carrier from 1 to 3.

`colab_multimode_regime3.py`
: the full multimode Lindblad calculation that replaces the mean-field estimate
  above. It solves the master equation for M co-driven modes at the true level
  spacing in the excitation-number-restricted basis, so the dimension is
  C(M + N_exc, N_exc) instead of N^M, and switches to quantum trajectories once
  the density matrix becomes too large. Written for Colab and resumable: each
  case is appended to CSV as soon as it finishes, and all writes are mirrored to
  Drive with a remount attempt if the mount is lost.

  Results are in `results/multimode_quantum/`. Two controls: the M = 1 case
  reproduces the frequency scan of Fig. 10 to five digits, and at M = 4 the
  master equation and 400 trajectories agree to 1 %.

  | M | <n> target | P0+P1 | abs(<aa>) |
  | --- | --- | --- | --- |
  | 1 | 0.2452 | 0.9254 | 0.3933 |
  | 2 | 0.2363 | 0.9285 | 0.3729 |
  | 3 | 0.1301 | 0.9790 | 0.1170 |
  | 4 | 0.2146 | 0.9379 | 0.3236 |
  | 5 | 0.1781 | 0.9625 | 0.2286 |
  | 6 | 0.1576 | 0.9710 | 0.1917 |
  | 8 | 0.1329 | 0.9724 | 0.1279 |

  Adding co-driven neighbours leaves the two-level population intact — it rises
  from 0.925 to 0.972 — but suppresses the pair correlation that carries the
  phase: abs(<aa>) falls by a factor of three by M = 8, monotonically for
  M >= 4 and following abs(<aa>) ~ M^-1.31 to within 4 %. The M = 3 point sits
  off that trend and is reported as measured rather than smoothed.

  The mechanism is not leakage. For a spatially uniform pump the overlap
  integral of the drive with a pair of mode functions vanishes unless the two
  coincide, so the pump excites each mode within itself and transfers no quanta
  between modes; the modes are coupled only through the cross-Kerr term, which
  detunes the target mode out of parametric resonance.

  Extrapolating the fitted power law to the 589 modes of the gain band would
  give abs(<aa>) of order 1e-3. That is two decades beyond the computed range
  and is recorded as an indication of direction, not as a result.

An earlier version of the quantum calculation placed all M modes at exactly the
same frequency. Exact degeneracy creates collective states whose response is
sensitive to a symmetry the real spectrum does not have, and the resulting
M-dependence was not monotonic. The script above uses the true spacing,
delta = 6.3 GHz / 6 THz, arranged symmetrically about the target mode.
