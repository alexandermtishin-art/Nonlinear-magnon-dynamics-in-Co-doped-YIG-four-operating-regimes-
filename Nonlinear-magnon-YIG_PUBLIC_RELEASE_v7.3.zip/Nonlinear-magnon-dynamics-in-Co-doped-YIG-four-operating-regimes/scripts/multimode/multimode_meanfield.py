"""Mean-field multimode dynamics, deterministic small seed.

Avoids the truncated-Wigner subtlety in which the 1/2 zero point produces a
spurious Kerr detuning: every mode is seeded with the same small amplitude and
the question asked is how the excitation is distributed at the end, not what
its absolute size is.

    da_j/dt = -i[ d_j + U(n_j + 2 sum_{l!=j} n_l) ] a_j - i h conj(a_j) - (k/2) a_j
"""
import numpy as np
from scipy.integrate import solve_ivp
gyro=1.760859630e11; Ms=1.4e5; A=3.65e-12; D=2*A/Ms
L=20e-9; Lz=10e-9
ETA=1.2; ALPHA=1e-3; U=0.55; NCYC=20
def f_of_k(k): return gyro*D*k**2/(2*np.pi)
dkx=dky=np.pi/L; dkz=np.pi/Lz
ks=[]
for i in range(0,120):
    for j in range(0,120):
        for l in range(0,60):
            if i==j==l==0: continue
            ks.append(np.sqrt((i*dkx)**2+(j*dky)**2+(l*dkz)**2))
f_exch=f_of_k(np.array(ks))   # exchange contribution only

def run(f0, seed_amp=1e-3, nph=8):
    h=ETA/4.0; kap=2*ALPHA
    # spectrum: uniform mode at f_uni plus the exchange contribution
    f_uni=50e9
    f_all=f_uni+f_exch
    sel=np.abs(f_all-f0)<h*f0
    d=np.concatenate(([0.0],(f_all[sel]-f0)/f0))
    M=len(d); t_end=NCYC*np.pi
    rng=np.random.default_rng(1)
    acc=np.zeros(M)
    for r in range(nph):
        ph=rng.uniform(0,2*np.pi,M)
        a0=seed_amp*np.exp(1j*ph)
        def rhs(t,y):
            a=y[:M]+1j*y[M:]
            n=np.abs(a)**2; tot=n.sum()
            sh=d+U*(n+2*(tot-n))
            da=-1j*sh*a-1j*h*np.conj(a)-0.5*kap*a
            return np.concatenate([da.real,da.imag])
        s=solve_ivp(rhs,[0,t_end],np.concatenate([a0.real,a0.imag]),
                    rtol=1e-8,atol=1e-12,method='RK45')
        a=s.y[:M,-1]+1j*s.y[M:,-1]
        acc+=np.abs(a)**2
    n=acc/nph
    return M,n

for f0,lab in ((50e9,'50 GHz'),(6e12,'6 THz')):
    M,n=run(f0)
    tot=n.sum()
    order=np.argsort(n)[::-1]
    print('=== %s ==='%lab)
    print('  modes in the gain band: %d'%M)
    print('  fraction in target mode (d=0): %.1f%%'%(100*n[0]/tot))
    print('  fraction in three most populated: %.1f%%'%(100*n[order[:3]].sum()/tot))
    print('  participating modes (inverse participation ratio): %.1f'%(tot**2/(n**2).sum()))
    print()
