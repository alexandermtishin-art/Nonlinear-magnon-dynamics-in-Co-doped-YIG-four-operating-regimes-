"""
Parametric stability across the confined magnon spectrum.

The single-mode treatment used throughout the manuscript assumes the drive
addresses one mode.  A parametric drive of amplitude h = eta*Omega/4 at
frequency 2*Omega amplifies every mode whose pair resonance lies close enough
to the pump: for a mode detuned by delta the pair amplitude grows at

    s(delta) = sqrt(h^2 - delta^2) - kappa/2      (|delta| < h)

so all modes with |delta| < sqrt(h^2 - (kappa/2)^2) are above threshold.

MODE SPECTRUM
-------------
    f(k) = f_uniform + gamma (2A/Ms) k^2 ,   k_i = n_i pi / L_i

The uniform-mode offset matters: omitting it moves the whole ladder down and
changes the count on the microwave carrier from 1 to 3.  It is included here.

RESULT
------
    50 GHz : first non-uniform mode 36 GHz above the uniform one, outside the
             15 GHz gain band                        -> 1 mode unstable
    6 THz  : level spacing ~6 GHz, gain band 1.8 THz  -> 589 modes unstable
"""
import numpy as np

GYRO = 1.760859630e11
MS = 1.4e5
A_EX = 3.65e-12
D = 2 * A_EX / MS
LX = LY = 20e-9
LZ = 10e-9
ETA = 1.2
ALPHA = 1.0e-3
F_UNIFORM = 50e9


def f_exchange(k):
    return GYRO * D * k ** 2 / (2 * np.pi)


def spectrum(nmax=120, nzmax=60):
    dkx, dky, dkz = np.pi / LX, np.pi / LY, np.pi / LZ
    ks = []
    for i in range(nmax):
        for j in range(nmax):
            for l in range(nzmax):
                if i == j == l == 0:
                    continue
                ks.append(np.hypot(np.hypot(i * dkx, j * dky), l * dkz))
    return F_UNIFORM + f_exchange(np.array(ks))


def report(f0, label, uniform_is_target):
    f_modes = spectrum()
    h = ETA * f0 / 4.0
    kap = 2 * ALPHA * f0
    thr = np.sqrt(max(h ** 2 - (kap / 2) ** 2, 0.0))
    delta = f_modes - f0
    unstable = np.abs(delta) < thr
    n = int(unstable.sum()) + (1 if uniform_is_target else 0)
    print('=== %s ===' % label)
    print('  drive amplitude h = eta f / 4 : %.3g Hz' % h)
    print('  damping kappa                 : %.3g Hz' % kap)
    print('  threshold detuning            : %.3g Hz' % thr)
    print('  modes above threshold         : %d' % n)
    if uniform_is_target:
        print('  nearest non-uniform mode      : %.1f GHz above the uniform one'
              % ((f_modes.min() - f0) / 1e9))
    else:
        win = (f_modes > 0.9 * f0) & (f_modes < 1.1 * f0)
        print('  nearest confined mode         : %.1f GHz from the carrier'
              % (np.sort(np.abs(delta))[0] / 1e9))
        print('  mean level spacing near f0    : %.1f GHz'
              % (0.2 * f0 / max(int(win.sum()), 1) / 1e9))
        print('  damping linewidth alpha f0    : %.1f GHz' % (ALPHA * f0 / 1e9))
    print()


if __name__ == '__main__':
    report(50e9, '50 GHz carrier (uniform mode)', uniform_is_target=True)
    report(6e12, '6 THz carrier (exchange magnon)', uniform_is_target=False)
