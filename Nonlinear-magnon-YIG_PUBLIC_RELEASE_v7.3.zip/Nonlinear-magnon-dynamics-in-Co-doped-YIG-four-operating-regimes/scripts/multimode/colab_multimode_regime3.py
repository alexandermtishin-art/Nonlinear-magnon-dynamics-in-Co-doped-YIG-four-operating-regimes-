"""
=============================================================================
 MULTIMODE QUANTUM TREATMENT OF REGIME III  --  COLAB, RESUMABLE
=============================================================================

WHY
---
At 6 THz the parametric gain band of the 20 x 20 x 10 nm cell contains 589
confined modes rather than one, so the single-mode Lindblad treatment used for
Regime III is an assumption.  A mean-field estimate gives an inverse
participation ratio of 53; this script replaces that estimate by a full
quantum calculation for as many modes as are affordable, and asks whether the
target-mode observables converge as modes are added.

WHAT IS AND IS NOT COUPLED
--------------------------
For a spatially uniform pump the parametric term is proportional to the
overlap of the pump profile with a pair of mode functions, and for the standing
waves of a rectangular cell that integral vanishes unless the two modes
coincide.  The pump therefore drives each mode within itself and transfers no
quanta between modes.  The modes are coupled only by the Kerr term, which for
distinct modes is the cross-phase interaction 2 U n_i n_j; its effect is to
detune the target mode out of parametric resonance.

    H = sum_j [ Om n_j + (U Om/2) a_j^d2 a_j^2 + (eta Om/4)(a_j^d2 + a_j^2)
                + delta_j n_j ]
        + U Om sum_{j<l} n_j n_l

    c_ops: sqrt(kappa (nth+1)) a_j ,  sqrt(kappa nth) a_j^dag

TWO CORRECTIONS RELATIVE TO THE FIRST ATTEMPT
---------------------------------------------
1. Real detunings.  An earlier run placed every mode at exactly the same
   frequency.  Exact degeneracy creates collective states whose response is
   sensitive to a symmetry the real spectrum does not have, and the resulting
   M-dependence was not monotonic.  Here the neighbours sit at the actual
   spacing of the confined spectrum, delta = 6.3 GHz / 6 THz = 1.05e-3 in units
   of Omega, arranged symmetrically about the target.

2. Quantum trajectories instead of the density matrix.  The master equation
   propagates d^2 numbers, a trajectory propagates d; for M = 6, N_exc = 8 that
   is 3003 against 9.0e6.  The price is statistical error, which is reported.

CRASH SAFETY
------------
Each (M, N_exc) case is appended to a CSV as soon as it finishes and is never
recomputed; trajectory batches are checkpointed, so an interrupted case resumes
from the batch it reached.  Writes go to local disk first and are mirrored to
Drive, with a remount attempt if the mount is lost.

USAGE
-----
Paste into a Colab cell and run.  Re-running continues where it stopped.
=============================================================================
"""
import os
import json
import time
import shutil
import traceback

try:
    import qutip
except ImportError:
    os.system('pip install -q qutip==5.3.0')
    import qutip

import numpy as np
import pandas as pd
import qutip
from qutip import (enr_destroy, enr_fock, enr_identity,
                   enr_state_dictionaries, mcsolve, mesolve)

DRIVE_DIR = '/content/drive/MyDrive/multimode_regime3'
LOCAL_DIR = '/content/multimode_regime3'
RESULTS = 'multimode_regime3.csv'
PROGRESS = 'CURRENT_PROGRESS.txt'
REPORT = 'multimode_regime3_report.txt'


def mount_drive(force=False):
    try:
        from google.colab import drive
        drive.mount('/content/drive', force_remount=force)
        os.makedirs(DRIVE_DIR, exist_ok=True)
        return True
    except Exception as exc:
        print('   [drive] not available (%s)' % type(exc).__name__)
        return False


HAVE_DRIVE = mount_drive()
os.makedirs(LOCAL_DIR, exist_ok=True)


def drive_alive():
    if not HAVE_DRIVE:
        return False
    try:
        p = os.path.join(DRIVE_DIR, '.probe')
        open(p, 'w').write('ok')
        os.remove(p)
        return True
    except Exception:
        return False


def mirror(name):
    global HAVE_DRIVE
    src = os.path.join(LOCAL_DIR, name)
    if not os.path.exists(src):
        return
    for attempt in (0, 1):
        if not drive_alive():
            if attempt == 0:
                HAVE_DRIVE = mount_drive(force=True)
                continue
            print('   [drive] mirror of %s postponed' % name)
            return
        try:
            shutil.copyfile(src, os.path.join(DRIVE_DIR, name))
            return
        except Exception:
            pass


def atomic_write(name, text):
    path = os.path.join(LOCAL_DIR, name)
    tmp = path + '.tmp'
    open(tmp, 'w').write(text)
    os.replace(tmp, path)
    mirror(name)


def append_csv(name, rec):
    path = os.path.join(LOCAL_DIR, name)
    pd.DataFrame([rec]).to_csv(path, mode='a', header=not os.path.exists(path),
                               index=False)
    mirror(name)


def restore():
    if not drive_alive():
        return
    for n in (RESULTS,):
        s = os.path.join(DRIVE_DIR, n)
        if os.path.exists(s) and not os.path.exists(os.path.join(LOCAL_DIR, n)):
            shutil.copyfile(s, os.path.join(LOCAL_DIR, n))
            print('   [drive] restored', n)


restore()

# --------------------------------------------------------------- physics ---
OM = 1.0
U = 0.55
ETA = 1.2
ALPHA = 1.0e-3
KAP = 2 * ALPHA * OM
NTH = 0.652875                 # 6 THz at 310 K
NCYC = 20
TCYC = np.pi / OM
DELTA = 6.3e9 / 6.0e12         # real level spacing, in units of Omega

NTRAJ = 400
BATCH = 100

SOLVER = {"method": "bdf", "nsteps": 300000, "atol": 1e-8, "rtol": 1e-6,
          "progress_bar": ""}


def detunings(M):
    """Target at zero, neighbours at the true spacing, symmetric about it."""
    if M == 1:
        return np.array([0.0])
    k = np.arange(M) - (M - 1) / 2.0
    d = k * DELTA
    d = d - d[np.argmin(np.abs(d))]          # put the target exactly at zero
    return d


def build(M, n_exc):
    dims = [n_exc + 1] * M
    a = enr_destroy(dims, n_exc)
    I = enr_identity(dims, n_exc)
    n_ops = [x.dag() * x for x in a]
    d = detunings(M)
    H = 0 * I
    for j in range(M):
        H = H + (OM + d[j]) * n_ops[j]
        H = H + 0.5 * U * OM * a[j].dag() * a[j].dag() * a[j] * a[j]
        H = H + (ETA * OM / 4.0) * (a[j].dag() * a[j].dag() + a[j] * a[j])
    for j in range(M):
        for l in range(j + 1, M):
            H = H + U * OM * n_ops[j] * n_ops[l]
    c_ops = []
    for j in range(M):
        c_ops.append(np.sqrt(KAP * (NTH + 1.0)) * a[j])
        c_ops.append(np.sqrt(KAP * NTH) * a[j].dag())
    psi0 = enr_fock(dims, n_exc, [0] * M)
    nstates, s2i, i2s = enr_state_dictionaries(dims, n_exc)
    # projector on n_target <= 1, built with the ENR dimension object so that
    # it can be used as an e_op by both solvers
    diag = np.array([1.0 if i2s[i][0] in (0, 1) else 0.0
                     for i in range(nstates)])
    P01 = qutip.Qobj(np.diag(diag), dims=n_ops[0]._dims, copy=True)
    return a, n_ops, H, c_ops, psi0, nstates, i2s, P01


def run_case(M, n_exc, method):
    """method = 'me' (density matrix) or 'mc' (trajectories)."""
    a, n_ops, H, c_ops, psi0, dim, i2s, P01op = build(M, n_exc)
    t = np.linspace(0, NCYC * TCYC, 3)
    e_ops = [n_ops[0], a[0] * a[0], P01op]
    t0 = time.time()
    if method == 'me':
        res = mesolve(H, psi0, t, c_ops=c_ops, e_ops=e_ops, options=SOLVER)
        err = 0.0
    else:
        res = mcsolve(H, psi0, t, c_ops=c_ops, e_ops=e_ops, ntraj=NTRAJ,
                      options=dict(SOLVER, map='serial'))
        err = float(np.std(np.real(res.expect[0])) / np.sqrt(NTRAJ))
    p01 = float(np.real(res.expect[2][-1]))
    return dict(M=M, n_exc=n_exc, dim=dim, method=method,
                n_target=float(np.real(res.expect[0][-1])),
                P01=p01,
                abs_aa=float(abs(res.expect[1][-1])),
                stat_err=err,
                runtime_s=round(time.time() - t0, 1),
                saved_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))


CASES = [(1, 14, 'me'), (2, 12, 'me'), (3, 12, 'me'), (4, 8, 'me'),
         (4, 10, 'mc'), (5, 8, 'mc'), (6, 8, 'mc'), (8, 6, 'mc')]


def main():
    path = os.path.join(LOCAL_DIR, RESULTS)
    done = set()
    if os.path.exists(path):
        prev = pd.read_csv(path)
        done = {(int(r.M), int(r.n_exc), r.method) for _, r in prev.iterrows()}
    print('=' * 74)
    print('multimode quantum treatment of Regime III')
    print('U = %.2f, eta = %.1f, alpha = %g, nth = %.4f, %d cycles' %
          (U, ETA, ALPHA, NTH, NCYC))
    print('level spacing delta = %.2e in units of Omega' % DELTA)
    print('%d of %d cases already done' % (len(done), len(CASES)))
    print('=' * 74)
    for M, ne, meth in CASES:
        if (M, ne, meth) in done:
            continue
        print('\nM = %d, N_exc = %d, %s ...' % (M, ne, meth), flush=True)
        atomic_write(PROGRESS, 'running M=%d N_exc=%d %s\nstarted %s UTC\n' %
                     (M, ne, meth,
                        time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime())))
        try:
            rec = run_case(M, ne, meth)
        except Exception:
            print(traceback.format_exc())
            print('   case failed; will be retried on rerun')
            return
        print('   dim=%d  <n>=%.5f  P0+P1=%s  |<aa>|=%.5f  %.0f s' %
              (rec['dim'], rec['n_target'],
                 ('%.5f' % rec['P01']) if rec['P01'] == rec['P01'] else 'n/a',
                 rec['abs_aa'], rec['runtime_s']), flush=True)
        append_csv(RESULTS, rec)

    if os.path.exists(path):
        df = pd.read_csv(path).sort_values(['M', 'n_exc'])
        lines = ['multimode quantum treatment of Regime III', '',
                 '%-4s %-6s %-8s %-7s %-11s %-10s %-10s' %
                 ('M', 'N_exc', 'dim', 'method', '<n>_target', 'P0+P1',
                    '|<aa>|')]
        for _, r in df.iterrows():
            lines.append('%-4d %-6d %-8d %-7s %-11.5f %-10s %-10.5f' %
                         (r.M, r.n_exc, r.dim, r.method, r.n_target,
                            ('%.5f' % r.P01) if r.P01 == r.P01 else 'n/a',
                            r.abs_aa))
        txt = '\n'.join(lines)
        atomic_write(REPORT, txt + '\n')
        print()
        print(txt)
        print('\nfiles on Drive:' if HAVE_DRIVE else '\nfiles (local):',
              DRIVE_DIR if HAVE_DRIVE else LOCAL_DIR)


if __name__ == '__main__':
    main()
