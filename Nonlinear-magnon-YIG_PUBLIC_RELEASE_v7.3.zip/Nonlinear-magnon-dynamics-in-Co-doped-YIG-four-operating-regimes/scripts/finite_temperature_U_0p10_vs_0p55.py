"""
FINITE-TEMPERATURE KERR COMPARISON AT 310 K

Compares U=0.10 and U=0.55 for the same Lindblad model used previously.
Install first if needed:
    pip install qutip==5.3.0
"""

import json
import time
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from qutip import destroy, basis, mesolve

HBAR = 1.054571817e-34
KB = 1.380649e-23

OMEGA = 1.0
ETA = 1.2
ALPHA = 1.0e-3
KAPPA = 2.0 * ALPHA * OMEGA

FREQ_HZ = 50.0e9
TEMPERATURE_K = 310.0
U_VALUES = [0.10, 0.55]

TCYC = np.pi / OMEGA
NCYC = 20
PTS_PER_CYCLE = 10

BASIS_SIZES = [100, 120, 140]
N_MAIN = max(BASIS_SIZES)

OUTPUT_DIR = Path("finite_temperature_U_scan_results")

SOLVER_OPTIONS = {
    "atol": 1.0e-9,
    "rtol": 1.0e-7,
    "nsteps": 500000,
    "method": "bdf",
    "store_states": False,
    "store_final_state": True,
    "progress_bar": "text",
}


def thermal_occupation(freq_hz: float, temperature_k: float) -> float:
    if temperature_k <= 0.0:
        return 0.0
    x = HBAR * 2.0 * np.pi * freq_hz / (KB * temperature_k)
    return 1.0 / np.expm1(x)


def build_model(N: int, U: float):
    a = destroy(N)
    ad = a.dag()
    n_op = ad * a

    H = (
        OMEGA * n_op
        + U * ad * ad * a * a
        + (ETA * OMEGA / 4.0) * (ad * ad + a * a)
    )

    p0 = basis(N, 0) * basis(N, 0).dag()
    p1 = basis(N, 1) * basis(N, 1).dag()
    p01 = p0 + p1
    aa = a * a

    nth = thermal_occupation(FREQ_HZ, TEMPERATURE_K)
    c_ops = [
        np.sqrt(KAPPA * (nth + 1.0)) * a,
        np.sqrt(KAPPA * nth) * ad,
    ]

    return H, c_ops, n_op, p01, aa, nth


def run_case(N: int, U: float):
    H, c_ops, n_op, p01_op, aa_op, nth = build_model(N, U)
    psi0 = basis(N, 0)

    tlist = np.linspace(
        0.0,
        NCYC * TCYC,
        NCYC * PTS_PER_CYCLE + 1,
    )

    start = time.time()
    result = mesolve(
        H,
        psi0,
        tlist,
        c_ops=c_ops,
        e_ops=[n_op, p01_op, aa_op],
        options=SOLVER_OPTIONS,
    )
    runtime = time.time() - start

    mean_n = np.real(np.asarray(result.expect[0]))
    p01 = np.real(np.asarray(result.expect[1]))
    pair = np.asarray(result.expect[2], dtype=complex)
    pair_abs = np.abs(pair)
    pair_phase = np.angle(pair)
    pair_phase[pair_abs < 1.0e-12] = np.nan
    normalized_pair = pair_abs / (2.0 * mean_n + 1.0)

    final_state = result.final_state
    pops = np.real(np.diag(final_state.full()))
    pops = np.maximum(pops, 0.0)
    pops /= pops.sum()

    summary = {
        "U": float(U),
        "N": int(N),
        "temperature_K": float(TEMPERATURE_K),
        "frequency_Hz": float(FREQ_HZ),
        "thermal_occupation_nth": float(nth),
        "cycles": int(NCYC),
        "runtime_s": float(runtime),
        "max_mean_n": float(np.max(mean_n)),
        "final_mean_n": float(mean_n[-1]),
        "min_P0_plus_P1": float(np.min(p01)),
        "final_P0_plus_P1": float(p01[-1]),
        "final_P_n_ge_2": float(1.0 - p01[-1]),
        "final_pair_abs": float(pair_abs[-1]),
        "final_pair_phase_rad": None if np.isnan(pair_phase[-1]) else float(pair_phase[-1]),
        "final_normalized_pair_abs": float(normalized_pair[-1]),
        "final_population_top_10_levels": float(np.sum(pops[-10:])),
        "final_population_highest_level": float(pops[-1]),
    }

    return {
        "U": U,
        "N": N,
        "cycles_axis": tlist / TCYC,
        "mean_n": mean_n,
        "p01": p01,
        "pair_abs": pair_abs,
        "pair_phase": pair_phase,
        "normalized_pair": normalized_pair,
        "pops": pops,
        "summary": summary,
    }


def print_summary(s: dict):
    print(
        f"U={s['U']:.2f} | N={s['N']:3d} | "
        f"final<n>={s['final_mean_n']:.6f} | "
        f"final P01={s['final_P0_plus_P1']:.6f} | "
        f"P(n>=2)={s['final_P_n_ge_2']:.6f} | "
        f"|<aa>|={s['final_pair_abs']:.6f} | "
        f"norm pair={s['final_normalized_pair_abs']:.6f} | "
        f"top10={s['final_population_top_10_levels']:.3e} | "
        f"top1={s['final_population_highest_level']:.3e} | "
        f"time={s['runtime_s']:.1f}s"
    )


def save_results(all_results, main_results):
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    payload = {
        "model": {
            "Omega": OMEGA,
            "eta": ETA,
            "alpha": ALPHA,
            "kappa": KAPPA,
            "frequency_Hz": FREQ_HZ,
            "temperature_K": TEMPERATURE_K,
            "thermal_occupation_nth": thermal_occupation(FREQ_HZ, TEMPERATURE_K),
            "U_values": U_VALUES,
            "basis_sizes": BASIS_SIZES,
            "cycles": NCYC,
            "points_per_cycle": PTS_PER_CYCLE,
            "initial_state": "vacuum",
            "Hamiltonian_convention": "H = Omega*n + U*a†²a² + (eta*Omega/4)(a†²+a²)",
        },
        "runs": [r["summary"] for r in all_results],
    }

    with open(OUTPUT_DIR / "finite_temperature_U_scan_summary.json", "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)

    columns = [main_results[0]["cycles_axis"]]
    header = ["cycle"]

    for result in main_results:
        tag = f"U_{result['U']:.2f}".replace(".", "p")
        columns.extend([
            result["mean_n"],
            result["p01"],
            result["pair_abs"],
            result["normalized_pair"],
            result["pair_phase"],
        ])
        header.extend([
            f"mean_n_{tag}",
            f"P0_plus_P1_{tag}",
            f"pair_abs_{tag}",
            f"normalized_pair_abs_{tag}",
            f"pair_phase_rad_{tag}",
        ])

    np.savetxt(
        OUTPUT_DIR / "finite_temperature_U_scan_timeseries.csv",
        np.column_stack(columns),
        delimiter=",",
        header=",".join(header),
        comments="",
    )


def make_figure(main_results):
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(2, 2, figsize=(13.5, 9.0))

    for result in main_results:
        label = f"U = {result['U']:.2f}"
        ax[0, 0].plot(result["cycles_axis"], result["mean_n"], linewidth=1.5, label=label)
        ax[0, 1].plot(result["cycles_axis"], result["p01"], linewidth=1.5, label=label)
        ax[1, 0].plot(result["cycles_axis"], result["pair_abs"], linewidth=1.5, label=label)
        ax[1, 1].plot(result["cycles_axis"], result["normalized_pair"], linewidth=1.5, label=label)

    ax[0, 0].set_xlabel("Number of cycles $t/T$")
    ax[0, 0].set_ylabel(r"$\langle n\rangle$")
    ax[0, 0].set_title("Mean occupation")
    ax[0, 0].legend(frameon=False)

    ax[0, 1].set_xlabel("Number of cycles $t/T$")
    ax[0, 1].set_ylabel(r"$P_0+P_1$")
    ax[0, 1].set_ylim(-0.02, 1.02)
    ax[0, 1].set_title("Low-Fock weight")
    ax[0, 1].legend(frameon=False)

    ax[1, 0].set_xlabel("Number of cycles $t/T$")
    ax[1, 0].set_ylabel(r"$|\langle aa\rangle|$")
    ax[1, 0].set_title("Absolute pair amplitude")
    ax[1, 0].legend(frameon=False)

    ax[1, 1].set_xlabel("Number of cycles $t/T$")
    ax[1, 1].set_ylabel(r"$|\langle aa\rangle|/(2\langle n\rangle+1)$")
    ax[1, 1].set_title("Normalized pair amplitude")
    ax[1, 1].legend(frameon=False)

    fig.suptitle(
        "Finite-temperature Kerr comparison at 310 K\n"
        f"$f={FREQ_HZ/1e9:.0f}$ GHz, $\\eta={ETA}$, $\\alpha={ALPHA}$, N={N_MAIN}, {NCYC} cycles",
        fontsize=13,
    )

    plt.tight_layout(rect=[0.0, 0.0, 1.0, 0.95])
    fig.savefig(OUTPUT_DIR / "Figure_finite_temperature_U_scan.png", dpi=200)
    fig.savefig(OUTPUT_DIR / "Figure_finite_temperature_U_scan.pdf")
    plt.close(fig)


def main():
    print("=" * 79)
    print("FINITE-TEMPERATURE KERR COMPARISON")
    print("=" * 79)
    print(f"Frequency: {FREQ_HZ/1e9:.1f} GHz")
    print(f"Temperature: {TEMPERATURE_K:.1f} K")
    print(f"Thermal occupation: {thermal_occupation(FREQ_HZ, TEMPERATURE_K):.6f}")
    print(f"Cycles: {NCYC}")
    print(f"Basis sizes: {BASIS_SIZES}")
    print(f"U values: {U_VALUES}")

    all_results = []
    main_results = []

    for U in U_VALUES:
        print("\n" + "=" * 79)
        print(f"RUNS FOR U={U:.2f}")
        print("=" * 79)

        for N in BASIS_SIZES:
            result = run_case(N, U)
            all_results.append(result)
            print_summary(result["summary"])
            if N == N_MAIN:
                main_results.append(result)

    save_results(all_results, main_results)
    make_figure(main_results)

    print("\n" + "=" * 79)
    print("SAVED FILES")
    print("=" * 79)
    print(OUTPUT_DIR / "finite_temperature_U_scan_summary.json")
    print(OUTPUT_DIR / "finite_temperature_U_scan_timeseries.csv")
    print(OUTPUT_DIR / "Figure_finite_temperature_U_scan.png")
    print(OUTPUT_DIR / "Figure_finite_temperature_U_scan.pdf")

    print("\nConvergence rule:")
    print(
        "Trust a result only if final <n> and final P0+P1 are stable as N increases "
        "and the population in the highest 10 levels is negligible."
    )


if __name__ == "__main__":
    main()
