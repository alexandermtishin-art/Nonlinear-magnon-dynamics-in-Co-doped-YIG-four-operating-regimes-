"""
Exchange cost of confining a magnon mode, and the U it would produce.

The Kerr coefficient of a mode is fixed by its spin content:

    U = omega_a / (2 N_eff Omega) ,   N_eff = Ms V / (g muB)

N_eff is the net angular momentum of the mode volume: the uniform mode of a
ferrimagnet is a single macrospin S_z = Ms V/(gamma hbar), and only the
uncompensated moment enters the acoustic branch.  Reaching U = 0.05-0.55
requires N_eff = 4-40, i.e. a region of order one
nanometre.  Confining a mode to a size L costs exchange energy ~ A/L^2, which
puts the mode at a frequency far above any drive used here.  This script
tabulates both sides of that trade for Co:YIG parameters.
"""
import numpy as np

MU0 = 4e-7 * np.pi
MUB = 9.2740100783e-24
GYRO = 1.760859630e11
MS = 1.4e5
A_EX = 3.65e-12
KU = 5.0e5
G_FACTOR = 2.0
V_CELL = 20e-9 * 20e-9 * 10e-9

rho = MS / (G_FACTOR * MUB) / 1e27                 # net spin content per nm^3
rho_mub = MS / MUB / 1e27                          # magnetic moment per nm^3, in muB
f_a = GYRO * (2 * KU / MS) / (2 * np.pi)           # anisotropy frequency, Hz
OMEGA = 50e9

print('moment density      : %.1f muB per nm^3'  % rho_mub)
print('net spin content    : %.3f per nm^3 (Ms/(g muB))' % rho)
print('anisotropy field    : %.2f T  ->  f_a = %.1f GHz' % (2 * KU / MS, f_a / 1e9))
print()
print('%-10s %-12s %-14s %-16s %-10s'
      % ('N_eff', 'volume nm^3', 'size L (nm)', 'exchange f (THz)', 'U'))
print('-' * 66)
for n in (3.6, 20, 40, 100, 1000, 7548, 2582):
    v = n / rho
    L = v ** (1 / 3) * 1e-9
    f_ex = GYRO * MU0 * (2 * A_EX / (MU0 * MS)) * (np.pi / L) ** 2 / (2 * np.pi)
    print('%-10.1f %-12.2f %-14.2f %-16.1f %-10.2e'
          % (n, v, L * 1e9, f_ex / 1e12, f_a / (2 * n * OMEGA)))
print()
print('exchange length sqrt(2A/mu0 Ms^2) : %.1f nm'
      % (np.sqrt(2 * A_EX / (MU0 * MS ** 2)) * 1e9))
print('domain-wall width sqrt(A/Ku)      : %.2f nm' % (np.sqrt(A_EX / KU) * 1e9))
print('YIG lattice constant              : 1.24 nm')
print()
print('A mode of 4-40 units of net spin would be 0.8-1.7 nm across, at or below')
print('the 1.24 nm YIG unit cell and well below the domain-wall width, and would')
print('sit at 5-22 THz, far detuned from a 50 GHz drive.')
