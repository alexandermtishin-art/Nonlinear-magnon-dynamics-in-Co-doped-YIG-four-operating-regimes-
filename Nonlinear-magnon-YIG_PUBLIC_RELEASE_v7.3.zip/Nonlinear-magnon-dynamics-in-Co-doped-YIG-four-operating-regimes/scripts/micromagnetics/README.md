# Micromagnetics

Two scripts that test whether the Kerr coefficient used in the Lindblad
calculations, U = 0.05-0.55, can be realized by a mode of the 20 x 20 x 10 nm
Co:YIG cell.

`micromagnetic_modes.py`
: eigenmodes of the linearised Landau-Lifshitz equation on a 2 nm mesh
  (exchange, uniaxial anisotropy, dipolar coupling, free boundaries).  Reports
  the frequency, participation ratio and implied N_eff of every mode, and the
  U each would produce.  Validated against the analytic standing-wave spectrum:
  198.9 GHz computed against 200.2 GHz analytic for the uniform mode.
  Result: no localised mode.  The least extended of the 25 lowest occupies a
  quarter of the cell (126.8 of 500 mesh cells), N_eff = 7.7e3, U = 2.6e-4.
  Output archived in `results/micromagnetics/micromagnetic_modes_output.txt`.

`mode_bound.py`
: the analytic counterpart.  Tabulates the volume, linear size and exchange
  frequency of a mode with a given spin content.  A mode of 4-40 units of net
  spin would be 0.8-1.7 nm across, at or below the 1.24 nm YIG unit cell and
  well below the domain-wall width, and would sit at 5-22 THz.
  Output archived in `results/micromagnetics/mode_bound_output.txt`.

## Note on spin counting (changed in v6)

N_eff is the **net angular momentum** of the mode volume,

    N_eff = M_s V / (g mu_B)

not the sum of the bare Fe(3+) spin lengths and not the number of formula
units.  The uniform mode of a saturated ferrimagnet is a single macrospin,
S_z = M_s V/(gamma hbar), reduced by one unit per magnon through the
Holstein-Primakoff substitution S_z = N_eff - n; the two Fe(3+) sublattices are
antiparallel and only the uncompensated moment enters the acoustic branch.
Equivalently, and without reference to any spin count at all, the Kerr
coefficient is

    K = hbar gamma^2 K_u / (M_s^2 V) ,

which reproduces omega_a/(2 N_eff) exactly with the net count and is the
standard cavity-magnonics result for the anisotropy-induced Kerr term of the
Kittel mode.

For this cell M_s = 1.4e5 A/m gives a moment of 6.0e4 mu_B, 8.4e4 Fe(3+) ions,
and a net spin content N_eff = 3.0e4, hence U = 6.6e-5 for the uniform mode at
a 50 GHz carrier with K_u = 5e5 J/m^3.

Releases up to v5 used N_eff = S * N_ion = 1.5e5 in `mode_bound.py` and the
formula-unit count in `micromagnetic_modes.py`, giving U = 1.3e-5 and 6.5e-4
respectively.  Both are superseded.  Part of the cavity-magnonics literature
does normalize the macrospin by the total ion spin density; that convention
gives an N_eff larger than the one used here by a factor of seven at 310 K,
and every conclusion drawn from the smallness of U is conservative with respect
to it.
