#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
===============================================================================
 ALL MANUSCRIPT FIGURES IN ONE FILE  --  APS (PRM/PRB) STYLE
 "Nonlinear magnon dynamics in Co-doped YIG: four operating regimes"
===============================================================================

WHY THIS FILE EXISTS
--------------------
Before this script the figures of the paper were scattered across three places:
the public archive (CSV outputs for Figs 4, 5, 6, 10 and S2), a set of one-off
scripts that were never deposited (Figs 1-3), and a working Colab notebook
(Figs 7-9 and 11).  Figures 1-3 and 7-9 existed in the archive only as bitmaps,
with no numbers behind them.  This file regenerates every figure from a single
place and writes the underlying numbers to CSV, so the whole figure set has one
reproducible source.

USAGE
-----
    python make_all_figures.py                 # everything
    python make_all_figures.py 4 6 10          # selected figures
    python make_all_figures.py --archive PATH  # point at the archive root

    --archive must contain results/... from the public deposit; it is needed
    only for Figs 4, 5, 6, 10 and S2.  Figures 1-3, 7-9 and 11 are computed
    from scratch and need no input files.

OUTPUT
------
    figures/FigN_*.pdf   vector, for submission
    figures/FigN_*.png   600 dpi, for inspection
    figures/data/*.csv   the numbers behind every recomputed panel

REQUIREMENTS
------------
    numpy, scipy, pandas, matplotlib; qutip>=5 only for Fig. 3.

-------------------------------------------------------------------------------
 PROVENANCE AND CONVENTIONS  --  read before quoting any number
-------------------------------------------------------------------------------
 Fig. 1,2   H = Om n + U n^2 + (eta Om/4)(a^d2 + a^2)          Lindblad, Liouvillian
            Fig. 1: N=40, Om t in [0,100], alpha = 0.15 and 1e-3
            Fig. 2: N=45, 100 cycles of T = 2 pi, alpha = 1e-3
 Fig. 3     H = Om n + U a^d2 a^2 + (eta Om/4)(a^d2 + a^2)     QuTiP mesolve
            N=35, 1000 cycles of T = pi, alpha = 1e-3
 Fig. 4,5,6,10, S2   archived CSV, canonical (U Om/2) a^d2 a^2
 Fig. 7,8,9 semiclassical coupled-mode model, notebook cells 51/56/88
 Fig. 11    analytic, notebook cell 18

 THREE Kerr conventions appear above: U n^2 (Figs 1-2), U a^d2 a^2 (Fig. 3) and
 (U Om/2) a^d2 a^2 (Fig. 4 onwards).  They are NOT interchangeable: with
 a^d2 a^2 = n(n-1) the same symbol U means a different physical anharmonicity in
 each.  This is reproduced here as it stands in the sources; it is a property of
 the original calculations, not of this code.  Likewise "one cycle" is T = 2 pi
 in Fig. 2 and T = pi in Fig. 3.

 The semiclassical model of Figs 7-9 is
      G(t)    = eta * Om0 * sin(2 Om0 t)
      dU      = U * Om0 * |v|^2
      du/dt   = -i (Om0 + dU) u - i G conj(v)   [- alpha Om0 u]
      dv/dt   = -i (Om0 + dU) v - i G conj(u)   [- alpha Om0 v]
 integrated with forward Euler, u(0)=1.  The damping terms in brackets are
 present only in Fig. 9.  Note this pair does not preserve |u|^2 - |v|^2, so it
 is not a canonical Bogoliubov transformation; it is kept because it is the
 model that produced the published figures.
===============================================================================
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.linalg import expm
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.ticker import AutoMinorLocator, LogLocator

# ------------------------------------------------------------------ settings
ARCHIVE = Path('Nonlinear-magnon-dynamics-in-Co-doped-YIG-four-operating-regimes')
OUT = Path('figures')
DATA = OUT / 'data'

COL1, COL2 = 3.375, 6.9          # APS single / double column width, inches

# Wong colour-blind-safe palette; every colour is also coded by line style
BLUE, ORANGE, GREEN = '#0072B2', '#E69F00', '#009E73'
RED, PURPLE, BROWN, GREY = '#D55E00', '#CC79A7', '#8C564B', '#666666'

STYLE = {
    'font.family': 'serif',
    'font.serif': ['DejaVu Serif', 'Liberation Serif', 'Times New Roman'],
    'mathtext.fontset': 'dejavuserif',
    'font.size': 8, 'axes.labelsize': 8,
    'xtick.labelsize': 7, 'ytick.labelsize': 7, 'legend.fontsize': 6.5,
    'axes.linewidth': 0.6, 'lines.linewidth': 1.1, 'lines.markersize': 3.0,
    'xtick.direction': 'in', 'ytick.direction': 'in',
    'xtick.top': True, 'ytick.right': True,
    'xtick.major.width': 0.6, 'ytick.major.width': 0.6,
    'xtick.minor.width': 0.45, 'ytick.minor.width': 0.45,
    'xtick.major.size': 3.0, 'ytick.major.size': 3.0,
    'xtick.minor.size': 1.7, 'ytick.minor.size': 1.7,
    'legend.frameon': False, 'legend.handlelength': 1.9,
    'legend.labelspacing': 0.3,
    'savefig.bbox': 'tight', 'savefig.pad_inches': 0.02,
    'pdf.fonttype': 42, 'ps.fonttype': 42,      # embed TrueType, not curves
}


# ------------------------------------------------------------------ helpers
def panels(axes, letters, corner=(0.055, 0.945, 'top', 'left')):
    """Label a whole figure, every panel in the SAME corner.

    The default corner is top left, as is usual in PRB.  If a panel has data
    there, its vertical range is opened up until the corner is free, rather
    than moving that one label somewhere else -- panel labels of one figure
    must not sit in different corners.  Only if that fails for some panel do
    all labels move outside the frame together.
    """
    axes = list(axes)
    x, y, va, ha = corner

    def _try(ax, letter):
        fig = ax.figure
        ink, origin = _ink_mask(ax, hide_legend=False)
        H = np.asarray(fig.canvas.buffer_rgba()).shape[0]
        txt = ax.text(x, y, f'({letter})', transform=ax.transAxes, fontsize=8,
                      fontweight='bold', va=va, ha=ha)
        txt._is_placement_probe = True
        fig.canvas.draw()
        bb = txt.get_window_extent(fig.canvas.get_renderer())
        return txt, _region_is_clean(ink, origin, bb, H, pad=3)

    placed, all_ok = [], True
    for ax, letter in zip(axes, letters):
        txt, ok = _try(ax, letter)
        for _ in range(4):                 # make room instead of moving away
            if ok:
                break
            txt.remove()
            _open_up(ax, 1.18)
            txt, ok = _try(ax, letter)
        placed.append(txt)
        if not ok:
            all_ok = False

    if not all_ok:                          # whole figure goes outside
        for txt, ax, letter in zip(placed, axes, letters):
            if txt is not None:
                txt.remove()
            t = ax.text(-0.16, 1.02, f'({letter})', transform=ax.transAxes,
                        fontsize=8, fontweight='bold', va='bottom', ha='left')
            t._is_placement_probe = True
    return placed


def panel(ax, letter, **kw):
    """Single-panel convenience wrapper around `panels`."""
    return panels([ax], [letter])[0]


def place_text(ax, label, spots, **kw):
    """Put a short annotation at the first candidate spot that is free.

    `spots` is a list of (x, y, va, ha) in axes coordinates.  The rasterised
    content of the axes is checked underneath each candidate, exactly as for
    legends and panel labels, so an annotation can never land on a curve.
    """
    fig = ax.figure
    ink, origin = _ink_mask(ax, hide_legend=False)
    H = np.asarray(fig.canvas.buffer_rgba()).shape[0]
    txt = None
    for x, y, va, ha in spots:
        if txt is not None:
            txt.remove()
        txt = ax.text(x, y, label, transform=ax.transAxes, va=va, ha=ha, **kw)
        txt._is_placement_probe = True
        fig.canvas.draw()
        bb = txt.get_window_extent(fig.canvas.get_renderer())
        if _region_is_clean(ink, origin, bb, H, pad=3):
            return txt
    return txt


def _ink_mask(ax, hide_legend=True):
    """Rasterise the axes content and return a boolean 'ink' mask plus the
    pixel bounds of the data area.  Anything drawn -- curves, markers, bars,
    guide lines, annotations -- shows up here, which is what makes the
    collision test reliable."""
    fig = ax.figure
    hidden = []
    for art in list(ax.texts):
        if getattr(art, '_is_placement_probe', False):
            art.set_visible(False); hidden.append(art)
    leg = ax.get_legend()
    if hide_legend and leg is not None:
        leg.set_visible(False); hidden.append(leg)
    # inward-pointing ticks are part of the frame, not of the data: a legend
    # near an edge always grazes them, and that is normal in APS figures
    ax.tick_params(which='both', length=0)
    fig.canvas.draw()
    buf = np.asarray(fig.canvas.buffer_rgba())[:, :, :3]
    for art in hidden:
        art.set_visible(True)
    ax.tick_params(which='major', length=3.0)
    ax.tick_params(which='minor', length=1.7)
    H = buf.shape[0]
    ab = ax.get_window_extent(fig.canvas.get_renderer())
    x0, x1 = int(ab.x0) + 2, int(ab.x1) - 2
    y0, y1 = int(H - ab.y1) + 2, int(H - ab.y0) - 2
    sub = buf[max(y0, 0):max(y1, 1), max(x0, 0):max(x1, 1)]
    ink = sub.min(axis=2) < 235
    return ink, (x0, y0)


def _region_is_clean(ink, origin, bbox, H, pad=2):
    """True if the rectangle `bbox` (display coords) contains no ink."""
    x0, y0 = origin
    i0 = int(H - bbox.y1) - y0 - pad
    i1 = int(H - bbox.y0) - y0 + pad
    j0 = int(bbox.x0) - x0 - pad
    j1 = int(bbox.x1) - x0 + pad
    i0, j0 = max(i0, 0), max(j0, 0)
    i1, j1 = min(i1, ink.shape[0]), min(j1, ink.shape[1])
    if i1 <= i0 or j1 <= j0:
        return True
    sub = ink[i0:i1, j0:j1]
    if sub.size == 0:
        return True
    # absolute tolerance: a few stray antialiased pixels are fine, but a
    # fraction-of-area rule would let a thin curve cross a large legend
    return sub.sum() <= 4


def place_legend(ax, ncol=1, extra=(), headroom=1.0):
    """APS house style: legend INSIDE the frame, no box.

    Candidate corners are tried in order; each placement is accepted only if
    the rasterised axes content is blank underneath it.  If no corner is
    clean the vertical range is opened up and the search repeats.
    """
    order = ('upper right', 'upper left', 'lower right', 'lower left',
             'center right', 'center left', 'upper center', 'lower center')
    h, l = ax.get_legend_handles_labels()
    for ax2 in extra:
        h2, l2 = ax2.get_legend_handles_labels()
        h += h2; l += l2
    if not h:
        return None
    fig = ax.figure
    if headroom != 1.0:
        _open_up(ax, headroom)

    for attempt in range(5):
        ink, origin = _ink_mask(ax)
        H = np.asarray(fig.canvas.buffer_rgba()).shape[0]
        for nc in range(ncol, 0, -1):
            for fs in (None, 6.5, 6.0):
                kw = {} if fs is None else {'fontsize': fs}
                for loc in order:
                    leg = ax.legend(h, l, loc=loc, ncol=nc, frameon=False,
                                    handletextpad=0.5, columnspacing=1.2,
                                    borderpad=0.2, **kw)
                    fig.canvas.draw()
                    bb = leg.get_window_extent(fig.canvas.get_renderer())
                    if _region_is_clean(ink, origin, bb, H):
                        return leg
                # nothing in a corner: sweep anchors across the frame
                for ay in (0.98, 0.86, 0.74, 0.62, 0.38, 0.26, 0.14, 0.02):
                    for ax_ in (0.02, 0.28, 0.55, 0.98):
                        va = 'upper' if ay > 0.5 else 'lower'
                        ha = 'left' if ax_ < 0.5 else 'right'
                        leg = ax.legend(h, l, loc=f'{va} {ha}', ncol=nc,
                                        frameon=False, handletextpad=0.5,
                                        columnspacing=1.2, borderpad=0.2,
                                        bbox_to_anchor=(ax_, ay),
                                        bbox_transform=ax.transAxes, **kw)
                        fig.canvas.draw()
                        bb = leg.get_window_extent(fig.canvas.get_renderer())
                        ab = ax.get_window_extent(fig.canvas.get_renderer())
                        if bb.x0 < ab.x0 or bb.x1 > ab.x1 or \
                           bb.y0 < ab.y0 or bb.y1 > ab.y1:
                            continue                    # must stay in the frame
                        if _region_is_clean(ink, origin, bb, H):
                            return leg
        _open_up(ax, 1.35)
    return leg


def _open_up(ax, factor):
    """Extend the y range upwards to free space for a legend."""
    lo, hi = ax.get_ylim()
    if ax.get_yscale() == 'log':
        ax.set_ylim(lo, hi * factor ** 3)
    else:
        ax.set_ylim(lo, lo + (hi - lo) * factor)


def minor(ax):
    ax.xaxis.set_minor_locator(AutoMinorLocator(2))
    ax.yaxis.set_minor_locator(AutoMinorLocator(2))


def save(fig, stem):
    OUT.mkdir(exist_ok=True); DATA.mkdir(exist_ok=True)
    fig.savefig(OUT / f'{stem}.pdf')
    fig.savefig(OUT / f'{stem}.png', dpi=600)
    plt.close(fig)
    print(f'   -> {stem}.pdf / .png')


def res(*parts):
    p = ARCHIVE / 'results'
    for q in parts:
        p = p / q
    if not p.exists():
        raise SystemExit(f'missing archive file: {p}\n'
                         f'use --archive to point at the deposit root')
    return p


def dump(df, name):
    DATA.mkdir(parents=True, exist_ok=True)
    df.to_csv(DATA / name, index=False)


# =============================================================== Figs 1 & 2
def _liouville_evolve(U, eta, alpha, N, tmax, nsteps, Om=1.0, kerr='n2'):
    """Direct Liouvillian propagation; kerr = 'n2' or 'a2a2'."""
    a = np.zeros((N, N))
    for i in range(N - 1):
        a[i, i + 1] = np.sqrt(i + 1)
    ad = a.T
    nop = ad @ a
    Hk = U * (nop @ nop) if kerr == 'n2' else U * (ad @ ad @ a @ a)
    H = Om * nop + Hk + (eta * Om / 4.0) * (ad @ ad + a @ a)
    kap = 2.0 * alpha * Om
    I = np.eye(N)
    L = (-1j * (np.kron(I, H) - np.kron(H.T, I))
         + kap * (np.kron(a.conj(), a)
                  - 0.5 * np.kron(I, nop) - 0.5 * np.kron(nop.T, I)))
    P = expm(L * (tmax / nsteps))
    v = np.zeros(N * N, complex); v[0] = 1.0
    nv = np.arange(N, dtype=float)
    ns = np.empty(nsteps + 1); ns[0] = 0.0
    for k in range(nsteps):
        v = P @ v
        ns[k + 1] = np.real(np.diag(v.reshape(N, N, order='F'))) @ nv
    d = np.real(np.diag(v.reshape(N, N, order='F')))
    return np.linspace(0, tmax, nsteps + 1), ns, d


def fig1():
    """Long-term dynamics and final Fock distribution, two damping levels."""
    print('Fig. 1  (U n^2, N=40, Om t = 0..100)')
    t, n_hi, d_hi = _liouville_evolve(0.1, 1.2, 0.15, 40, 100.0, 3000)
    _, n_lo, d_lo = _liouville_evolve(0.1, 1.2, 0.001, 40, 100.0, 3000)
    print(f'   alpha=1e-3: max<n> = {n_lo.max():.4f}   (manuscript 0.2909)')
    dump(pd.DataFrame({'Omega_t': t, 'mean_n_alpha_0p15': n_hi,
                       'mean_n_alpha_1em3': n_lo}), 'figure1_dynamics.csv')
    dump(pd.DataFrame({'fock_level': np.arange(len(d_hi)),
                       'P_alpha_0p15': d_hi, 'P_alpha_1em3': d_lo}),
         'figure1_final_fock.csv')

    fig, ax = plt.subplots(1, 2, figsize=(COL2, 2.35))
    ax[0].plot(t, n_lo, '-', color=BLUE, label=r'$\alpha=10^{-3}$')
    ax[0].plot(t, n_hi, '--', color=RED, lw=0.95, label=r'$\alpha=0.15$')
    ax[0].set_xlabel(r'normalized time $\Omega t$')
    ax[0].set_ylabel(r'mean occupation $\langle n\rangle$')
    ax[0].set_xlim(0, 100); ax[0].set_ylim(0, 0.33)
    place_legend(ax[0], 1, headroom=1.45); minor(ax[0])

    lv = np.arange(8)
    ax[1].bar(lv - 0.19, d_lo[:8], 0.38, color=BLUE, label=r'$\alpha=10^{-3}$')
    ax[1].bar(lv + 0.19, d_hi[:8], 0.38, color=RED, hatch='///',
              edgecolor='white', linewidth=0.0, label=r'$\alpha=0.15$')
    ax[1].set_xlabel(r'Fock level $n$'); ax[1].set_ylabel('probability')
    ax[1].set_xlim(-0.6, 7.6); ax[1].set_ylim(0, 1.0); ax[1].set_xticks(lv)
    place_legend(ax[1], 2, headroom=1.22)
    ax[1].yaxis.set_minor_locator(AutoMinorLocator(2))
    fig.subplots_adjust(wspace=0.30)
    panels(ax, 'ab')
    save(fig, 'Fig1_long_term_dynamics')


def fig2():
    """100 drive cycles of T = 2 pi at low damping."""
    print('Fig. 2  (U n^2, N=45, 100 cycles of T = 2pi)')
    T = 2 * np.pi
    t, n, d = _liouville_evolve(0.1, 1.2, 0.001, 45, 100 * T, 4000)
    print(f'   final <n> = {n[-1]:.4f}   P0+P1 = {d[0]+d[1]:.5f}   '
          f'P(n>=10) = {d[10:].sum():.2e}   (manuscript 0.157 / 0.9539 / 7.3e-8)')
    dump(pd.DataFrame({'cycle': t / T, 'mean_n': n}), 'figure2_dynamics.csv')
    dump(pd.DataFrame({'fock_level': np.arange(len(d)), 'probability': d}),
         'figure2_final_fock.csv')

    fig, ax = plt.subplots(1, 2, figsize=(COL2, 2.35))
    ax[0].plot(t / T, n, '-', color=BLUE, lw=0.5)
    ax[0].axhline(n[-1], ls=':', lw=0.7, color=GREY)
    place_text(ax[0], rf'final $\langle n\rangle={n[-1]:.3f}$',
               [(0.97, 0.96, 'top', 'right'), (0.97, 0.80, 'top', 'right'),
                (0.50, 0.96, 'top', 'center'), (0.03, 0.96, 'top', 'left'),
                (0.97, 0.62, 'top', 'right'), (0.03, 0.62, 'top', 'left')],
               fontsize=6.5, color=GREY)
    ax[0].set_xlabel(r'drive cycles $t/T$')
    ax[0].set_ylabel(r'mean occupation $\langle n\rangle$')
    ax[0].set_xlim(0, 100); ax[0].set_ylim(0, 0.33)
    minor(ax[0])

    ax[1].bar(np.arange(15), d[:15], 0.62, color=BLUE)
    ax[1].set_xlabel(r'Fock level $n$'); ax[1].set_ylabel('probability')
    ax[1].set_xlim(-0.6, 14.6); ax[1].set_ylim(0, 1.0)
    place_text(ax[1], rf'$P_0+P_1={d[0]+d[1]:.4f}$' + '\n'
               + rf'$P(n\geq 10)={d[10:].sum():.1e}$',
               [(0.97, 0.90, 'top', 'right'), (0.55, 0.90, 'top', 'left'),
                (0.97, 0.60, 'top', 'right')], fontsize=7)
    ax[1].yaxis.set_minor_locator(AutoMinorLocator(2))
    fig.subplots_adjust(wspace=0.30)
    panels(ax, 'ab')
    save(fig, 'Fig2_100_cycles')


# ==================================================================== Fig 3
def fig3():
    """1000 drive cycles of T = pi under the full Lindblad equation."""
    from qutip import destroy, basis, mesolve
    print('Fig. 3  (U a^d2 a^2, N=35, 1000 cycles of T = pi)  ~1 min')
    Om, U, eta, alpha, N = 1.0, 0.1, 1.2, 1e-3, 35
    kap, TC, ncyc, pts = 2 * alpha * Om, np.pi / Om, 1000, 20
    a = destroy(N); ad = a.dag()
    H = Om * ad * a + U * ad * ad * a * a + (eta * Om / 4.0) * (ad * ad + a * a)
    t = np.linspace(0, ncyc * TC, ncyc * pts + 1)
    r = mesolve(H, basis(N, 0), t, c_ops=[np.sqrt(kap) * a], e_ops=[ad * a],
                options={'atol': 1e-9, 'rtol': 1e-7, 'nsteps': 300000,
                         'store_final_state': True, 'progress_bar': ''})
    n = np.real(r.expect[0]); p = np.real(np.diag(r.final_state.full()))
    print(f'   max <n> = {n.max():.4f}   P0+P1 = {p[0]+p[1]:.5f}   '
          f'P(n>=10) = {p[10:].sum():.2e}   (manuscript 0.349 / 0.9517 / 7.7e-8)')

    w = pts
    pk = np.array([n[i:i + w].max() for i in range(0, len(n) - 1, w)])
    mn = np.array([n[i:i + w].mean() for i in range(0, len(n) - 1, w)])
    xc = np.arange(len(pk)) + 0.5
    dump(pd.DataFrame({'cycle': xc, 'per_cycle_max': pk,
                       'per_cycle_mean': mn}), 'figure3_envelope.csv')
    dump(pd.DataFrame({'fock_level': np.arange(len(p)), 'probability': p}),
         'figure3_final_fock.csv')

    fig, ax = plt.subplots(1, 2, figsize=(COL2, 2.35))
    ax[0].plot(t / TC, n, '-', color=BLUE, lw=0.25, alpha=0.5)
    ax[0].plot(xc, pk, '-', color=RED, lw=1.1, label='per-cycle maximum')
    ax[0].plot(xc, mn, '--', color=ORANGE, lw=1.1, label='per-cycle mean')
    ax[0].set_xlabel(r'drive cycles $t/T$')
    ax[0].set_ylabel(r'mean occupation $\langle n\rangle$')
    ax[0].set_xlim(0, ncyc); ax[0].set_ylim(0, 0.38)
    place_legend(ax[0], 1, headroom=1.45); minor(ax[0])

    ax[1].bar(np.arange(8), p[:8], 0.62, color=BLUE)
    ax[1].set_xlabel(r'Fock level $n$'); ax[1].set_ylabel('probability')
    ax[1].set_xlim(-0.6, 7.6); ax[1].set_ylim(0, 1.0)
    place_text(ax[1], rf'$P_0+P_1={p[0]+p[1]:.4f}$' + '\n'
               + rf'$P(n\geq 10)={p[10:].sum():.1e}$',
               [(0.97, 0.90, 'top', 'right'), (0.55, 0.90, 'top', 'left'),
                (0.97, 0.60, 'top', 'right')], fontsize=7)
    ax[1].yaxis.set_minor_locator(AutoMinorLocator(2))
    fig.subplots_adjust(wspace=0.30)
    panels(ax, 'ab')
    save(fig, 'Fig3_1000_cycles')


# ==================================================================== Fig 4
def fig4():
    """Confined occupancy versus the nonlinear coefficient (archived scan)."""
    print('Fig. 4  (archive: U_scan_quantum.csv)')
    # the archived U_scan_quantum.csv was generated with the legacy U n^2 term;
    # this scan is the same sweep recomputed in the canonical (U Om/2) a^d2 a^2
    # convention used by the protocol audit and the phase-statistics runs
    src = DATA / 'figure4_U_scan_canonical.csv'
    if not src.exists():
        raise SystemExit('missing %s (run rescan_U.py)' % src)
    d = pd.read_csv(src).sort_values('U')
    fig, ax = plt.subplots(1, 2, figsize=(COL2, 2.35))

    ax[0].plot(d.U, d.max_n, 'o-', color=BLUE, label=r'$\max_t\,\langle n\rangle$')
    ax[0].plot(d.U, d.final_n, 's--', color=ORANGE, mfc='white',
               label=r'late-time $\langle n\rangle$')
    ax[0].set_xlabel(r'nonlinear coefficient $U$')
    ax[0].set_ylabel('mode occupation')
    ax[0].set_xlim(-0.02, 0.82)
    place_legend(ax[0], 1, headroom=1.62); minor(ax[0])

    ax[1].plot(d.U, d.P01, 'o-', color=GREEN, label=r'$P_0+P_1$')
    ax[1].set_xlabel(r'nonlinear coefficient $U$'); ax[1].set_ylabel(r'$P_0+P_1$')
    ax[1].set_xlim(-0.02, 0.82); minor(ax[1])
    axr = ax[1].twinx()
    axr.semilogy(d.U, d.P_n_ge_2.clip(lower=1e-12), '^:', color=RED,
                 mfc='white', label=r'$P(n\geq 2)$')
    axr.set_ylabel(r'$P(n\geq 2)$', color=RED)
    axr.tick_params(axis='y', colors=RED, direction='in')
    axr.spines['right'].set_color(RED)
    place_legend(ax[1], 1, extra=(axr,), headroom=1.62)
    fig.subplots_adjust(wspace=0.42)
    panels(ax, 'ab')
    save(fig, 'Fig4_U_scan')


# ==================================================================== Fig 5
def fig5():
    """Bogoliubov-Lindblad bridge (archived dynamics)."""
    print('Fig. 5  (archive: bogoliubov_lindblad_bridge.csv)')
    d = pd.read_csv(res('bogoliubov_lindblad_bridge.csv'))
    mB = np.hypot(d.Re_m_Bogoliubov, d.Im_m_Bogoliubov)
    mL = np.hypot(d.Re_m_Lindblad, d.Im_m_Lindblad)
    fig, ax = plt.subplots(1, 3, figsize=(COL2, 2.55))

    ax[0].plot(d.time, d.n_Bogoliubov, '-', color=ORANGE,
               label=r'$|v(t)|^2$ (reduced)')
    ax[0].plot(d.time, d.n_Lindblad, '-', color=BLUE, lw=0.9,
               label=r'$\langle n\rangle$ (Lindblad)')
    ax[0].axhline(1.0, color=GREY, ls=':', lw=0.7)
    ax[0].set_ylabel('occupation')

    ax[1].plot(d.time, mB, '-', color=ORANGE, label=r'$|u^{*}v|$')
    ax[1].plot(d.time, mL, '-', color=BLUE, lw=0.9,
               label=r'$|\langle\hat a\hat a\rangle|$')
    ax[1].set_ylabel('pair amplitude')

    ax[2].plot(d.time, d.P0, '-', color=GREEN, label=r'$P_0$')
    ax[2].plot(d.time, d.P1, '-', color=PURPLE, label=r'$P_1$')
    ax[2].plot(d.time, d.P_n_ge_2, '-', color=RED, label=r'$P(n\geq 2)$')
    ax[2].set_ylabel('Fock populations'); ax[2].set_ylim(-0.03, 1.03)

    for k, a_ in enumerate(ax):
        a_.set_xlabel(r'normalized time $\Omega t$')
        place_legend(a_, 1, headroom=1.60)
        minor(a_)
    place_text(ax[0], r'$\langle n\rangle=1$ (not $P_1=1$)',
               [(0.97, 0.55, 'top', 'right'), (0.97, 0.40, 'top', 'right'),
                (0.03, 0.55, 'top', 'left'), (0.50, 0.28, 'top', 'center'),
                (0.97, 0.16, 'top', 'right')],
               fontsize=6, color=GREY)
    fig.subplots_adjust(wspace=0.52)
    panels(ax, 'abc')
    save(fig, 'Fig5_bridge')


# ==================================================================== Fig 6
def fig6():
    """Stationary transfer of the pump phase (archived five-phase scan)."""
    print('Fig. 6  (archive: five_phase_pair_control_*.csv)')
    s = pd.read_csv(res('five_phase_pair_control_summary.csv'))
    fit = pd.read_csv(res('five_phase_pair_control_fit.csv'))
    fv = dict(zip(fit['quantity'], fit['value'].astype(float)))
    slope, icpt, r2 = fv['slope'], fv['intercept_rad'], fv['r_squared']

    fig, ax = plt.subplots(1, 2, figsize=(COL2, 2.35))
    # the archived pair phase is wrapped into (-pi, pi]; the archived fit was
    # made on the unwrapped branch, so unwrap before plotting (two points at
    # phi_d = 3pi/4 and pi differ from the fit by exactly +2pi)
    phase = np.unwrap(s.mean_pair_phase_rad.to_numpy())
    xs = np.linspace(s.phi_d_rad.min(), s.phi_d_rad.max(), 100)
    ax[0].plot(xs, icpt + slope * xs, '-', color=GREY, lw=0.9,
               label=f'fit: slope $=${slope:.5f}')
    ax[0].plot(s.phi_d_rad, phase, 'o', color=BLUE, label='Lindblad')
    ax[0].set_ylabel(r'stationary pair phase $\bar\Phi_{\mathrm{pair}}$ (rad)')
    place_legend(ax[0], 1, headroom=1.45)
    place_text(ax[0], rf'$R^2={r2:.7f}$',
               [(0.04, 0.14, 'bottom', 'left'), (0.96, 0.90, 'top', 'right'),
                (0.04, 0.90, 'top', 'left')], fontsize=7)

    ax[1].plot(s.phi_d_rad, s.mean_n, 'o-', color=BLUE,
               label=r'$\langle n\rangle$')
    ax[1].plot(s.phi_d_rad, s.mean_abs_aa, 's--', color=ORANGE, mfc='white',
               label=r'$|\langle\hat a\hat a\rangle|$')
    ax[1].set_ylabel('late-time mean value'); ax[1].set_ylim(1.05, 1.28)
    axr = ax[1].twinx()
    axr.plot(s.phi_d_rad, np.degrees(s.phase_circular_std_rad), '^:',
             color=RED, mfc='white', label=r'$\sigma$')
    axr.set_ylabel(r'circular std $\sigma$ (deg)', color=RED)
    axr.tick_params(axis='y', colors=RED, direction='in')
    axr.spines['right'].set_color(RED); axr.set_ylim(12.5, 13.6)
    ax[1].set_ylim(1.05, 1.40)
    place_legend(ax[1], 1, extra=(axr,))

    for a_ in ax:
        a_.set_xlabel(r'pump phase $\varphi_{\mathrm{d}}$ (rad)')
        a_.set_xticks([0, np.pi / 4, np.pi / 2, 3 * np.pi / 4, np.pi])
        a_.set_xticklabels(['0', r'$\pi/4$', r'$\pi/2$', r'$3\pi/4$', r'$\pi$'])
        minor(a_)
    fig.subplots_adjust(wspace=0.45)
    panels(ax, 'ab')
    save(fig, 'Fig6_pair_phase_transfer')


# ============================================== semiclassical model, 7-9 ===
OM0 = 50e9 * 2 * np.pi


def _sc_trajectories(U_list, eta, dt, t_end, v0, alpha=0.0, sample=100):
    U = np.asarray(U_list, float)
    u = np.ones_like(U, complex); v = np.full_like(U, v0, complex)
    ts, vs = [], []
    for i in range(int(t_end / dt)):
        t = i * dt
        G = eta * OM0 * np.sin(2 * OM0 * t)
        vsq = np.abs(v) ** 2
        dU = U * OM0 * vsq
        du = (-1j * (OM0 + dU) * u - 1j * G * np.conj(v) - alpha * OM0 * u) * dt
        dv = (-1j * (OM0 + dU) * v - 1j * G * np.conj(u) - alpha * OM0 * v) * dt
        u, v = u + du, v + dv
        if i % sample == 0:
            ts.append(t); vs.append(vsq.copy())
    return np.array(ts), np.array(vs)


def _sc_late_mean(U_list, eta, dt, t_end, t_from, v0):
    U = np.asarray(U_list, float)
    u = np.ones_like(U, complex); v = np.full_like(U, v0, complex)
    acc = np.zeros_like(U, float); cnt = 0
    for i in range(int(t_end / dt)):
        t = i * dt
        G = eta * OM0 * np.sin(2 * OM0 * t)
        vsq = np.abs(v) ** 2
        dU = U * OM0 * vsq
        u, v = (u + (-1j * (OM0 + dU) * u - 1j * G * np.conj(v)) * dt,
                v + (-1j * (OM0 + dU) * v - 1j * G * np.conj(u)) * dt)
        if t > t_from:
            acc += vsq; cnt += 1
    return acc / max(cnt, 1)


def _sc_lifetime(U_grid, eta, dt, t_limit, v0, alpha, thresh=50.0):
    U = np.asarray(U_grid, float)
    u = np.ones_like(U, complex); v = np.full_like(U, v0, complex)
    life = np.full_like(U, t_limit, float); alive = np.ones_like(U, bool)
    for i in range(int(t_limit / dt)):
        t = i * dt
        vsq = np.abs(v) ** 2
        blown = alive & (vsq > thresh)
        if blown.any():
            life[blown] = t; alive[blown] = False
            if not alive.any():
                break
        G = eta * OM0 * np.sin(2 * OM0 * t)
        dU = U * OM0 * vsq
        dv = (-1j * (OM0 + dU) * v - 1j * G * np.conj(u) - alpha * OM0 * v) * dt
        du = (-1j * (OM0 + dU) * u - 1j * G * np.conj(v) - alpha * OM0 * u) * dt
        v = np.where(alive, v + dv, v); u = np.where(alive, u + du, u)
    return life


def fig7():
    """Stabilization of the parametric growth by the nonlinearity."""
    print('Fig. 7  (semiclassical, notebook cell 51)  ~2 s')
    U7 = [0.4, 5e-2, 1e-5, 1e-6, 1e-7, 1e-8, 0.0]
    t, v = _sc_trajectories(U7, 1.2, 5e-15, 0.5e-9, 0.05)
    late = v[len(v) // 2:].mean(axis=0)
    for U, m in zip(U7, late):
        print(f'   U = {U:<8g} late mean |v|^2 = {m:.3e}')
    print('   manuscript: saturation at 1e4-1e8 for U = 1e-8..1e-5, '
          'divergence at U = 0')
    df = pd.DataFrame(v, columns=[f'U_{u:g}' for u in U7])
    df.insert(0, 't_ns', t * 1e9); dump(df, 'figure7_trajectories.csv')

    lab = [r'$U=0.4$', r'$U=0.05$', r'$U=10^{-5}$', r'$U=10^{-6}$',
           r'$U=10^{-7}$', r'$U=10^{-8}$', r'$U=0$']
    cols = [BLUE, ORANGE, GREEN, PURPLE, RED, BROWN, 'k']
    styl = ['-', '-', '--', '--', '-.', '-.', '-']
    # seven curves cannot be legended without covering data, so the six
    # saturated curves are labelled in a column to the right of the data,
    # each at the level of its own plateau
    fig, ax = plt.subplots(figsize=(COL1 * 1.42, 2.7))
    for k in range(len(U7)):
        ax.semilogy(t * 1e9, np.maximum(v[:, k], 1e-3), styl[k], color=cols[k],
                    lw=1.6 if U7[k] == 0 else 1.0)
    ax.axhline(1.0, color=GREY, ls=':', lw=0.8)
    ax.set_xlabel('time (ns)'); ax.set_ylabel(r'occupancy $|v|^{2}$')
    ax.set_xlim(0, 0.635); ax.set_ylim(1e-2, 1e12)
    ax.yaxis.set_major_locator(LogLocator(base=10.0, numticks=8))
    ax.set_xticks([0.0, 0.1, 0.2, 0.3, 0.4, 0.5])

    for k in range(len(U7)):
        if U7[k] == 0:
            continue
        y = max(late[k], 1e-2)
        t_ = ax.text(0.515, y, lab[k], color=cols[k], fontsize=6.5,
                     va='center', ha='left')
        t_._direct_label = True

    # U = 0 leaves the frame early, so it is labelled on its own curve
    kdiv = U7.index(0.0)
    top = ax.get_ylim()[1]
    xcross = t[int(np.argmax(v[:, kdiv] > top))] * 1e9
    t_ = ax.text(xcross + 0.014, top / 4.0, lab[kdiv], color='k', fontsize=6.5,
                 va='center', ha='left', fontweight='bold')
    t_._direct_label = True

    # the dashed guide is at |v|^2 = 1; on this log axis that is at 2/14 of the
    # height, so the label sits just underneath it at the right-hand end
    place_text(ax, r'$|v|^2=1$',
               [(0.97, 0.112, 'top', 'right'), (0.80, 0.112, 'top', 'right'),
                (0.97, 0.06, 'top', 'right'), (0.02, 0.132, 'top', 'left')],
               fontsize=6.5, color=GREY)
    ax.xaxis.set_minor_locator(AutoMinorLocator(2))
    save(fig, 'Fig7_stabilization_vs_U')


def fig8():
    """Wide-range semiclassical phase map, with the balance estimate."""
    print('Fig. 8  (semiclassical, notebook cell 56)  ~1 min')
    U8 = np.logspace(-6, np.log10(10.0), 40)
    etas = [0.01, 0.1, 0.5, 1.0, 1.2, 1.5]
    R = []
    for eta in etas:
        t0 = time.time()
        R.append(_sc_late_mean(U8, eta, 1e-15, 0.8e-9, 0.5e-9, 0.01))
        print(f'   eta = {eta:<5g} {time.time()-t0:.0f} s')
    R = np.array(R)
    d = pd.DataFrame({'U': U8})
    for k, eta in enumerate(etas):
        d[f'mean_v2_eta_{eta:g}'] = R[k]
    dump(d, 'figure8_phase_map.csv')

    mk = ['o', 's', '^', 'v', 'D', 'x']
    cl = [GREY, PURPLE, GREEN, ORANGE, BLUE, RED]
    fig, ax = plt.subplots(figsize=(COL1 * 1.35, 2.6))
    for k, eta in enumerate(etas):
        ax.loglog(U8, R[k], mk[k] + '-', color=cl[k], mfc='none', mew=0.7,
                  label=rf'$\eta={eta}$')
    ax.plot(U8, 1.2 / (4 * U8), ':', color='k', lw=0.9,
            label=r'$\eta/4U$ ($\eta=1.2$)')
    ax.axhline(1.0, color=GREY, ls='--', lw=0.7)
    ax.set_xlabel(r'nonlinear coefficient $U$')
    ax.set_ylabel(r'late-time $\langle |v|^{2}\rangle$')
    ax.set_ylim(1e-4, 1e7)
    place_legend(ax, 4, headroom=1.22)
    save(fig, 'Fig8_semiclassical_phase_map')


def fig9():
    """Bounded-evolution time over 150 cycles versus U, several eta."""
    print('Fig. 9  (semiclassical, notebook cell 88)  ~30 s')
    Ug = np.linspace(0.0, 0.5, 100)
    etas = [1.4, 1.6, 1.8, 2.0, 3.0, 5.0]
    L = []
    for eta in etas:
        li = _sc_lifetime(Ug, eta, 10e-15, 3e-9, 0.1, 0.01)
        L.append(li)
        surv = li >= 3e-9
        uc = f'{Ug[np.argmax(surv)]:.4f}' if surv.any() else 'none'
        print(f'   eta = {eta:<4g} U_crit = {uc}')
    L = np.array(L)
    d = pd.DataFrame({'U': Ug})
    for k, eta in enumerate(etas):
        d[f'lifetime_ns_eta_{eta:g}'] = L[k] * 1e9
    dump(d, 'figure9_lifetime_map.csv')

    cl = [BLUE, GREEN, ORANGE, RED, PURPLE, 'k']
    st = ['-', '--', '-.', ':', '-', '--']
    fig, ax = plt.subplots(figsize=(COL1 * 1.35, 2.6))
    for k, eta in enumerate(etas):
        ax.plot(Ug, L[k] * 1e9, st[k], color=cl[k], lw=1.2,
                label=rf'$\eta={eta}$')
    ax.axhline(2.0, color=GREY, ls=':', lw=0.8)
    place_text(ax, '100 cycles',
               [(0.97, 0.66, 'bottom', 'right'), (0.03, 0.66, 'bottom', 'left'),
                (0.50, 0.66, 'bottom', 'center'), (0.97, 0.74, 'bottom', 'right'),
                (0.62, 0.24, 'bottom', 'left'), (0.30, 0.10, 'bottom', 'left')],
               fontsize=6.5, color=GREY)
    ax.set_xlabel(r'nonlinear regulator $U$')
    ax.set_ylabel('bounded-evolution time (ns)')
    ax.set_xlim(0, 0.5); ax.set_ylim(0, 3.2)
    place_legend(ax, 4, headroom=1.22)
    minor(ax)
    save(fig, 'Fig9_stability_map')


# =================================================================== Fig 10
def fig10():
    """Finite-temperature frequency scan at 310 K, canonical Kerr convention.

    Recomputed for this work in the (U Om/2) a^d2 a^2 convention used by the
    protocol audit, the phase-statistics campaign and Fig. 4, so that Table 3
    no longer mixes normalizations.  Basis size chosen per point from the
    occupancy actually reached and verified by a repeat at 1.2 N; every point
    converged.
    """
    print('Fig. 10 (recomputed scan, canonical convention)')
    src = DATA / 'figure10_frequency_scan_canonical.csv'
    if not src.exists():
        raise SystemExit('missing %s' % src)
    d = pd.read_csv(src).sort_values('frequency_THz')
    f = d.frequency_THz
    fig, ax = plt.subplots(2, 2, figsize=(COL2, 4.3))

    ax[0, 0].loglog(f, d.mean_n, 'o-', color=BLUE)
    ax[0, 0].set_ylabel(r'late-time $\langle n\rangle$')

    ax[0, 1].semilogx(f, d.P0_plus_P1, 'o-', color=BLUE)
    ax[0, 1].axhline(d.P0_plus_P1.iloc[-3:].mean(), color=GREY, ls=':', lw=0.7)
    ax[0, 1].set_ylabel(r'$P_0+P_1$')

    ax[1, 0].loglog(f, d.P_n_ge_2, '^-', color=RED)
    ax[1, 0].set_ylabel(r'$P(n\geq 2)$')

    ax[1, 1].semilogx(f, d.abs_aa, 'd-', color=GREEN,
                      label=r'$|\langle\hat a\hat a\rangle|$')
    ax[1, 1].semilogx(f, d.normalized_pair, 'v--', color=PURPLE, mfc='white',
                      label=r'$|\langle\hat a\hat a\rangle|/(2\langle n\rangle+1)$')
    ax[1, 1].set_ylabel('pair correlation')
    ax[1, 1].set_ylim(0, 0.78)

    for a_ in ax[1, :]:
        a_.set_xlabel(r'drive frequency $\Omega/2\pi$ (THz)')
    for a_ in ax.ravel():
        a_.xaxis.set_minor_locator(LogLocator(base=10.0, subs='auto',
                                              numticks=20))
        a_.axvline(6.0, color=GREY, ls='-.', lw=0.6, zorder=0)
    fig.subplots_adjust(wspace=0.40, hspace=0.34)
    place_legend(ax[1, 1], 1)
    panels(ax.ravel(), 'abcd')
    save(fig, 'Fig10_frequency_scan')


# =================================================================== Fig 11
def fig11():
    """Compute window versus Gilbert damping (analytic, notebook cell 18).

    tau_relax / tau_switch = 1/alpha to leading order, i.e. the magnetic
    quality factor.  This is an order-of-magnitude scaling statement, not a
    simulation result.
    """
    print('Fig. 11 (analytic, notebook cell 18)')
    alphas = np.logspace(-1, -4, 100)
    cycles = 1.0 / alphas
    dump(pd.DataFrame({'alpha': alphas, 'compute_window_cycles': cycles}),
         'figure11_compute_window.csv')

    fig, ax = plt.subplots(figsize=(COL1 * 1.35, 2.5))
    ax.loglog(alphas, cycles, '-', color=GREEN, lw=1.3)
    ax.plot(0.15, 1 / 0.15, 'o', color=RED,
            label=r'Co:YIG today ($\alpha\approx0.15$)')
    ax.plot(1e-3, 1e3, 's', color=BLUE, mfc='white',
            label=r'target ($\alpha=10^{-3}$)')
    ax.axhline(100, color=GREY, ls='--', lw=0.8, label='100 cycles')
    ax.invert_xaxis()
    ax.set_xlabel(r'Gilbert damping $\alpha$')
    ax.set_ylabel(r'compute window $\tau_{\mathrm{relax}}/\tau_{\mathrm{switch}}$')
    place_legend(ax, 2, headroom=1.22)
    save(fig, 'Fig11_compute_window')


# ============================================================ Supplement S2
def figS2():
    """Drive-protocol audit: static effective versus resonant pair drive."""
    print('Fig. S2 (archive: protocol_audit_full_dynamics.csv)')
    d = pd.read_csv(res('protocol_audit_full_dynamics.csv'))
    fig, ax = plt.subplots(1, 2, figsize=(COL2, 2.6))
    ax[0].plot(d.time, d.static_mean_n, '-', color=BLUE,
               label='static effective drive')
    ax[0].plot(d.time, d.resonant_mean_n, '-', color=ORANGE, lw=0.9,
               label='resonant modulation')
    ax[0].set_ylabel(r'$\langle n\rangle$'); place_legend(ax[0], 1, headroom=1.55)

    ax[1].plot(d.time, d.static_parity, '-', color=BLUE,
               label='static effective drive')
    ax[1].plot(d.time, d.resonant_parity, '-', color=ORANGE, lw=0.9,
               label='resonant modulation')
    ax[1].set_ylabel(r'parity $\langle(-1)^{\hat n}\rangle$')
    ax[1].set_ylim(-0.05, 1.60); place_legend(ax[1], 1)

    for a_ in ax:
        a_.set_xlabel(r'normalized time $\Omega t$'); minor(a_)
    fig.subplots_adjust(wspace=0.32)
    panels(ax, 'ab')
    save(fig, 'FigS2_protocol_audit')


# ============================================================ Supplement S1
def figS1():
    """Damped coupled-mode norm diagnostic, |u|^2 - |v|^2 = exp(-2 alpha Om t)."""
    print('Fig. S1 (archive: protocol_audit_full_dynamics.csv)')
    d = pd.read_csv(res('protocol_audit_full_dynamics.csv'))
    alpha = 0.01
    ideal = np.exp(-2 * alpha * d.time)

    fig, ax = plt.subplots(figsize=(COL1 * 1.42, 2.5))
    ax.semilogy(d.time, d.bogoliubov_corrected_norm, '-', color=BLUE, lw=1.3,
                label=r'numerical $|u|^{2}-|v|^{2}$')
    ax.semilogy(d.time, ideal, '--', color=RED, lw=1.0,
                label=r'$e^{-2\alpha\Omega t}$')
    ax.set_xlabel(r'normalized time $\Omega t$')
    ax.set_ylabel(r'coupled-mode norm')
    ax.set_xlim(0, d.time.max())
    place_legend(ax, 1, headroom=1.25)
    err = np.abs(d.bogoliubov_corrected_norm - ideal).max()
    place_text(ax, rf'max deviation $= {err:.1e}$',
               [(0.03, 0.20, 'bottom', 'left'), (0.03, 0.35, 'bottom', 'left'),
                (0.55, 0.20, 'bottom', 'left')], fontsize=6.5, color=GREY)
    ax.xaxis.set_minor_locator(AutoMinorLocator(2))
    save(fig, 'FigS1_norm_diagnostic')


# ============================================================ Supplement S3
def figS3():
    """Complex-plane step response of the anomalous pair mode."""
    print('Fig. S3 (archive: five_phase_pair_control_dynamics.csv)')
    d = pd.read_csv(res('five_phase_pair_control_dynamics.csv'))
    keys = [c[:-7] for c in d.columns if c.endswith('_mean_n')]
    labs = [r'$\varphi_{\mathrm{step}}=0$', r'$\pi/4$', r'$\pi/2$',
            r'$3\pi/4$', r'$\pi$']
    cl = [BLUE, ORANGE, GREEN, PURPLE, RED]
    st = ['-', '--', '-.', ':', '-']

    fig, ax = plt.subplots(1, 2, figsize=(COL2 * 0.78, 2.5))
    for k, key in enumerate(keys):
        amp = d[key + '_abs_aa'].to_numpy()
        ph = d[key + '_pair_phase_rotating'].to_numpy()
        z = amp * np.exp(1j * ph)
        ax[0].plot(z.real, z.imag, st[k], color=cl[k], lw=0.9, label=labs[k])
        ax[1].plot(d.time, amp, st[k], color=cl[k], lw=0.9, label=labs[k])
    ax[0].set_xlabel(r'Re $z(t)$'); ax[0].set_ylabel(r'Im $z(t)$')

    ax[1].set_xlabel(r'normalized time $\Omega t$')
    ax[1].set_ylabel(r'$|\langle\hat a\hat a\rangle|$')
    ax[1].set_xlim(0, d.time.max())
    for a_ in ax:
        place_legend(a_, 1, headroom=1.30); minor(a_)
    fig.subplots_adjust(wspace=0.40)
    panels(ax, 'ab')
    save(fig, 'FigS3_step_response')


# ============================================================ Supplement S4
def figS4():
    """Finite-temperature frequency scan at 310 K: the two U values compared."""
    print('Fig. S4 (archive: finite_temperature_frequency_scan_310K_combined.csv)')
    d = pd.read_csv(res('finite_temperature_310K_frequency_scan',
                        'finite_temperature_frequency_scan_310K_combined.csv'))
    f = d.frequency_THz
    fig, ax = plt.subplots(1, 2, figsize=(COL2 * 0.85, 2.5))

    ax[0].loglog(f, d['mean_n_U_0.10'], 'o-', color=BLUE, label=r'$U=0.10$')
    ax[0].loglog(f, d['mean_n_U_0.55'], 's--', color=ORANGE, mfc='white',
                 label=r'$U=0.55$')
    ax[0].set_ylabel(r'late-time $\langle n\rangle$')

    ax[1].semilogx(f, d['P0_plus_P1_U_0.10'], 'o-', color=BLUE, label=r'$U=0.10$')
    ax[1].semilogx(f, d['P0_plus_P1_U_0.55'], 's--', color=ORANGE, mfc='white',
                   label=r'$U=0.55$')
    ax[1].set_ylabel(r'$P_0+P_1$')

    for a_ in ax:
        a_.set_xlabel(r'drive frequency $\Omega/2\pi$ (THz)')
        a_.axvline(6.0, color=GREY, ls='-.', lw=0.6, zorder=0)
        a_.xaxis.set_minor_locator(LogLocator(base=10.0, subs='auto',
                                              numticks=20))
    for a_ in ax:
        place_legend(a_, 1, headroom=1.25)
    fig.subplots_adjust(wspace=0.36)
    panels(ax, 'ab')
    save(fig, 'FigS4_frequency_scan_U_compare')


# =================================================================== driver
REGISTRY = {'1': fig1, '2': fig2, '3': fig3, '4': fig4, '5': fig5, '6': fig6,
            '7': fig7, '8': fig8, '9': fig9, '10': fig10, '11': fig11,
            'S1': figS1, 'S2': figS2, 'S3': figS3, 'S4': figS4}


def main(argv):
    global ARCHIVE
    args = list(argv)
    if '--archive' in args:
        i = args.index('--archive')
        ARCHIVE = Path(args[i + 1]); del args[i:i + 2]
    wanted = [a for a in args if a in REGISTRY] or list(REGISTRY)

    mpl.rcParams.update(STYLE)
    OUT.mkdir(exist_ok=True); DATA.mkdir(exist_ok=True)
    t0 = time.time()
    for key in wanted:
        try:
            REGISTRY[key]()
        except SystemExit as e:
            print(f'   SKIPPED Fig. {key}: {e}')
        except ImportError as e:
            print(f'   SKIPPED Fig. {key}: {e}')
    print(f'\nall done in {time.time()-t0:.0f} s -> {OUT.resolve()}')


if __name__ == '__main__':
    main(sys.argv[1:])
