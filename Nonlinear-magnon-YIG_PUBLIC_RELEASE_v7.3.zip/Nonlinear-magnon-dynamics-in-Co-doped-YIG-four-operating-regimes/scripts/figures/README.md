# Figures for "Nonlinear magnon dynamics in Co-doped YIG: four operating regimes"

Everything needed to regenerate every figure of the manuscript and of the
Supplement from one script, plus the numbers behind each panel.

## Contents

    make_all_figures.py     regenerates all 16 figures (11 main + S1-S4)
    audit_fig.py            checks that no legend, panel label or annotation
                            overlaps plotted data; run it after any edit
    Fig*.pdf                vector, for submission
    Fig*.png                600 dpi, for inspection
    data/*.csv              the numbers behind every recomputed panel

## Usage

    python make_all_figures.py                       # everything
    python make_all_figures.py 4 6 10                # selected figures
    python make_all_figures.py --archive PATH        # point at the deposit

`--archive` must contain `results/...` from the public archive; it is needed
only for Figs 4, 5, 6, 10, S1, S2 and S4, which read the deposited CSV files.
Figs 1-3, 7-9, 11 and S3 are computed from scratch and need no input.

Requirements: numpy, scipy, pandas, matplotlib; qutip>=5 only for Fig. 3.
Full run takes roughly 4 minutes; Fig. 3 and Fig. 8 dominate.

## Self-check

The script prints the key numbers next to the values quoted in the manuscript,
so a silent drift is visible immediately:

    Fig. 1   alpha=1e-3: max<n> = 0.2909            (manuscript 0.2909)
    Fig. 2   final <n> = 0.1565  P0+P1 = 0.95388    (manuscript 0.157 / 0.9539)
    Fig. 3   max <n> = 0.3493   P0+P1 = 0.95171     (manuscript 0.349 / 0.9517)
    Fig. 7   U = 1e-08 -> 9.075e+07 ... U = 0 -> 1.841e+80
    Fig. 9   eta = 1.4  U_crit = 0.0404

`audit_fig.py` rasterises each figure and reports any collision:

    python audit_fig.py 1 2 4 5 6 7 9 10 11 S1 S2 S3 S4

## Style

APS (PRM/PRB) house style: column widths 3.375 / 6.9 in, serif text at
8/7 pt, ticks inward on all four sides, legends inside the frame without a
box, panel labels inside the frame at the top left, colour-blind-safe Wong
palette with every curve also coded by line style, TrueType fonts embedded.

## Provenance and conventions -- read before quoting any number

    Fig. 1,2   H = Om n + U n^2 + (eta Om/4)(a^d2 + a^2)        Liouvillian
               Fig. 1: N=40, Om t in [0,100], alpha = 0.15 and 1e-3
               Fig. 2: N=45, 100 cycles of T = 2 pi, alpha = 1e-3
    Fig. 3     H = Om n + U a^d2 a^2 + (eta Om/4)(a^d2 + a^2)   QuTiP mesolve
               N=35, 1000 cycles of T = pi, alpha = 1e-3
    Fig. 4,5,6,10, S1, S2, S4   archived CSV, canonical (U Om/2) a^d2 a^2
    Fig. 7,8,9 semiclassical coupled-mode model, notebook cells 51/56/88
    Fig. 11    analytic, notebook cell 18
    Fig. S3    archived five-phase step-response dynamics

THREE Kerr conventions appear above: U n^2 (Figs 1-2), U a^d2 a^2 (Fig. 3) and
(U Om/2) a^d2 a^2 (Fig. 4 onwards).  Since a^d2 a^2 = n(n-1), the same symbol U
means a different physical anharmonicity in each, and the values are not
interchangeable without an explicit normalization conversion.  Likewise "one
cycle" is T = 2 pi in Fig. 2 and T = pi in Fig. 3.

The semiclassical model of Figs 7-9 is

    G(t)    = eta * Om0 * sin(2 Om0 t)
    dU      = U * Om0 * |v|^2
    du/dt   = -i (Om0 + dU) u - i G conj(v)   [- alpha Om0 u]
    dv/dt   = -i (Om0 + dU) v - i G conj(u)   [- alpha Om0 v]

integrated with forward Euler, u(0)=1; the damping terms in brackets appear
only in Fig. 9.  This pair does not preserve |u|^2 - |v|^2, so it is not a
canonical Bogoliubov transformation; it is kept because it is the model that
produced the published figures.
