"""Raster audit: looks for ink underneath legends, panel labels and annotations."""
import matplotlib; matplotlib.use('Agg')
import importlib.util, sys, numpy as np
spec=importlib.util.spec_from_file_location('mk','make_all_figures.py')
mk=importlib.util.module_from_spec(spec); sys.modules['mk']=mk; spec.loader.exec_module(mk)
mk.ARCHIVE=mk.Path('ARCH'); matplotlib.rcParams.update(mk.STYLE)
rep=[]; orig=mk.save
def chk(fig,stem):
    fig.canvas.draw(); r=fig.canvas.get_renderer()
    H=np.asarray(fig.canvas.buffer_rgba()).shape[0]
    bad=[]
    for i,ax in enumerate(fig.axes):
        leg=ax.get_legend()
        if leg is not None:
            ink,org=mk._ink_mask(ax)
            if not mk._region_is_clean(ink,org,leg.get_window_extent(r),H):
                bad.append(f'legend#{i}')
        for t in ax.texts:
            if getattr(t,'_direct_label',False): continue   # deliberate direct label
            if not t.get_text().strip(): continue           # empty (annotate arrow)
            ink,org=mk._ink_mask(ax, hide_legend=False)
            if not mk._region_is_clean(ink,org,t.get_window_extent(r),H,pad=3):
                bad.append('text#%d:%r'%(i,t.get_text()[:18]))
    rep.append((stem,bad)); orig(fig,stem)
mk.save=chk
for k in sys.argv[1:]: mk.REGISTRY[k]()
print()
ok=True
for s,b in rep:
    if b: ok=False
    print('%-32s %s'%(s, 'clean' if not b else 'COLLISION: '+', '.join(b)))
print('\nALL CLEAN' if ok else '\nISSUES REMAIN')
