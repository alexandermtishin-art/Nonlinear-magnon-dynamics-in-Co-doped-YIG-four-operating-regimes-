"""
=============================================================================
FINITE-TEMPERATURE LINDLAD STRESS TEST FOR THE MAGNON KERR MODEL
=============================================================================

This script is based directly on the uploaded 1000-cycle Figure 3 code.

It compares:
    1) T = 0 K
    2) T = 310 K

while keeping the Hamiltonian and all normalized model parameters unchanged:

    H = Omega*n + U*a.dag()**2*a**2
        + (eta*Omega/4)*(a.dag()**2 + a**2)

    kappa = 2*alpha*Omega

Finite-temperature collapse operators:

    L_down = sqrt[kappa*(n_th + 1)] * a
    L_up   = sqrt[kappa*n_th]       * a.dag()

where

    n_th = 1 / (exp(hbar*omega_phys/(kB*T)) - 1)

The default run starts from vacuum in both cases. This is the cleanest test of
how quickly a 310 K bath destroys the zero-temperature low-Fock regime.

IMPORTANT
---------
At 50 GHz and 310 K, n_th is approximately 129. Therefore N=35 is NOT an
adequate finite-temperature basis. The default is N=140. Run the optional
convergence check at N=100, 120, 140 before interpreting the result.

The script saves:
    finite_temperature_summary.json
    finite_temperature_timeseries.csv
    finite_temperature_final_fock.csv
    Figure_finite_temperature_comparison.png
    Figure_finite_temperature_comparison.pdf

Designed for QuTiP 5.3.
=============================================================================
"""

import json
import time
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from qutip import destroy, basis, mesolve, qeye


# ============================================================================
# PHYSICAL CONSTANTS
# ============================================================================

HBAR = 1.054571817e-34       # J s
KB   = 1.380649e-23         # J/K


# ============================================================================
# MODEL PARAMETERS — IDENTICAL TO THE UPLOADED FIGURE-3 SCRIPT
# ============================================================================

OMEGA = 1.0
U     = 0.1
ETA   = 1.2
ALPHA = 1.0e-3

KAPPA = 2.0 * ALPHA * OMEGA

# One cycle in the uploaded script:
TCYC = np.pi / OMEGA

# Physical frequency used only to calculate thermal bath occupation.
FREQ_HZ = 50.0e9

TEMPERATURES_K = [0.0, 310.0]

# Start with 50 cycles. Increase only after this run is understood.
NCYC = 50
PTS_PER_CYCLE = 10

# Finite-temperature basis. N=35 is invalid at n_th ~ 129.
N_MAIN = 140

# Optional convergence check. This can be computationally expensive.
CHECK_CONVERGENCE = True
CONVERGENCE_BASES = [100, 120, 140]
CONVERGENCE_CYCLES = 20

OUTPUT_DIR = Path("finite_temperature_lindblad_results")


# ============================================================================
# NUMERICAL OPTIONS
# ============================================================================

SOLVER_OPTIONS = {
    "atol": 1.0e-9,
    "rtol": 1.0e-7,
    "nsteps": 500000,
    "method": "bdf",
    "store_states": False,
    "store_final_state": True,
    "progress_bar": "text",
}


# ============================================================================
# HELPERS
# ============================================================================

def thermal_occupation(freq_hz: float, temperature_k: float) -> float:
    """Bose-Einstein occupation of a bath mode at physical frequency freq_hz."""
    if temperature_k <= 0.0:
        return 0.0

    x = HBAR * 2.0 * np.pi * freq_hz / (KB * temperature_k)
    return 1.0 / np.expm1(x)


def build_operators(N: int):
    """Construct Hamiltonian and observables."""
    a = destroy(N)
    ad = a.dag()
    n_op = ad * a

    # Exactly the Hamiltonian convention in the uploaded Figure-3 code.
    H = (
        OMEGA * n_op
        + U * ad * ad * a * a
        + (ETA * OMEGA / 4.0) * (ad * ad + a * a)
    )

    p0 = basis(N, 0) * basis(N, 0).dag()
    p1 = basis(N, 1) * basis(N, 1).dag()
    p01 = p0 + p1

    aa = a * a

    return a, ad, n_op, H, p01, aa


def collapse_operators(a, ad, temperature_k: float):
    """Finite-temperature amplitude damping and thermal injection."""
    nth = thermal_occupation(FREQ_HZ, temperature_k)

    c_ops = [
        np.sqrt(KAPPA * (nth + 1.0)) * a,
    ]

    if nth > 0.0:
        c_ops.append(np.sqrt(KAPPA * nth) * ad)

    return c_ops, nth


def run_case(N: int, temperature_k: float, ncyc: int):
    """Run one Lindblad trajectory from vacuum."""
    a, ad, n_op, H, p01_op, aa_op = build_operators(N)
    c_ops, nth = collapse_operators(a, ad, temperature_k)

    psi0 = basis(N, 0)

    tlist = np.linspace(
        0.0,
        ncyc * TCYC,
        ncyc * PTS_PER_CYCLE + 1,
    )

    t0 = time.time()

    result = mesolve(
        H,
        psi0,
        tlist,
        c_ops=c_ops,
        e_ops=[n_op, p01_op, aa_op],
        options=SOLVER_OPTIONS,
    )

    runtime = time.time() - t0

    mean_n = np.real(np.asarray(result.expect[0]))
    p01 = np.real(np.asarray(result.expect[1]))
    pair = np.asarray(result.expect[2], dtype=complex)

    pair_abs = np.abs(pair)
    pair_phase = np.angle(pair)

    # Phase is meaningless when pair amplitude is numerically zero.
    pair_phase[pair_abs < 1.0e-12] = np.nan

    final_state = result.final_state
    pops = np.real(np.diag(final_state.full()))
    pops = np.maximum(pops, 0.0)
    pops = pops / pops.sum()

    top10 = pops[-10:].sum() if N >= 10 else pops[-1]

    summary = {
        "N": int(N),
        "temperature_K": float(temperature_k),
        "thermal_occupation_nth": float(nth),
        "cycles": int(ncyc),
        "runtime_s": float(runtime),
        "max_mean_n": float(np.max(mean_n)),
        "final_mean_n": float(mean_n[-1]),
        "min_P0_plus_P1": float(np.min(p01)),
        "final_P0_plus_P1": float(p01[-1]),
        "final_P_n_ge_2": float(1.0 - p01[-1]),
        "final_pair_abs": float(pair_abs[-1]),
        "final_pair_phase_rad": (
            None if np.isnan(pair_phase[-1]) else float(pair_phase[-1])
        ),
        "final_population_top_10_levels": float(top10),
        "final_population_highest_level": float(pops[-1]),
    }

    return {
        "temperature_K": temperature_k,
        "nth": nth,
        "t": tlist,
        "cycles_axis": tlist / TCYC,
        "mean_n": mean_n,
        "p01": p01,
        "pair_abs": pair_abs,
        "pair_phase": pair_phase,
        "pops": pops,
        "summary": summary,
    }


def convergence_check():
    """
    Short finite-temperature basis check.

    Interpretation:
    convergence is acceptable only if:
      - final <n> changes little with N,
      - final P0+P1 changes little with N,
      - population in the highest levels is negligible.
    """
    print("\n" + "=" * 79)
    print(f"CONVERGENCE CHECK AT T=310 K FOR {CONVERGENCE_CYCLES} CYCLES")
    print("=" * 79)

    rows = []

    for N in CONVERGENCE_BASES:
        result = run_case(N, 310.0, CONVERGENCE_CYCLES)
        s = result["summary"]
        rows.append(s)

        print(
            f"N={N:3d} | "
            f"nth={s['thermal_occupation_nth']:.3f} | "
            f"max<n>={s['max_mean_n']:.6f} | "
            f"final<n>={s['final_mean_n']:.6f} | "
            f"final P01={s['final_P0_plus_P1']:.6f} | "
            f"top10={s['final_population_top_10_levels']:.3e} | "
            f"top1={s['final_population_highest_level']:.3e} | "
            f"time={s['runtime_s']:.1f}s"
        )

    return rows


def save_results(results, convergence_rows):
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    # --------------------------- JSON summary
    summary_payload = {
        "model": {
            "Omega": OMEGA,
            "U": U,
            "eta": ETA,
            "alpha": ALPHA,
            "kappa": KAPPA,
            "frequency_Hz": FREQ_HZ,
            "cycles": NCYC,
            "points_per_cycle": PTS_PER_CYCLE,
            "N_main": N_MAIN,
            "initial_state": "vacuum",
            "Hamiltonian_convention":
                "H = Omega*n + U*a†²a² + (eta*Omega/4)(a†²+a²)",
        },
        "convergence_check": convergence_rows,
        "runs": [r["summary"] for r in results],
    }

    with open(
        OUTPUT_DIR / "finite_temperature_summary.json",
        "w",
        encoding="utf-8",
    ) as f:
        json.dump(summary_payload, f, indent=2, ensure_ascii=False)

    # --------------------------- Time-series CSV
    columns = [results[0]["cycles_axis"]]
    header = ["cycle"]

    for r in results:
        tag = f"T_{int(r['temperature_K'])}K"
        columns.extend([
            r["mean_n"],
            r["p01"],
            r["pair_abs"],
            r["pair_phase"],
        ])
        header.extend([
            f"mean_n_{tag}",
            f"P0_plus_P1_{tag}",
            f"pair_abs_{tag}",
            f"pair_phase_rad_{tag}",
        ])

    np.savetxt(
        OUTPUT_DIR / "finite_temperature_timeseries.csv",
        np.column_stack(columns),
        delimiter=",",
        header=",".join(header),
        comments="",
    )

    # --------------------------- Final Fock CSV
    fock_columns = [np.arange(N_MAIN)]
    fock_header = ["fock_level"]

    for r in results:
        tag = f"T_{int(r['temperature_K'])}K"
        fock_columns.append(r["pops"])
        fock_header.append(f"probability_{tag}")

    np.savetxt(
        OUTPUT_DIR / "finite_temperature_final_fock.csv",
        np.column_stack(fock_columns),
        delimiter=",",
        header=",".join(fock_header),
        comments="",
    )


def make_figure(results):
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    labels = {
        0.0: "T = 0 K",
        310.0: "T = 310 K",
    }

    fig, ax = plt.subplots(2, 2, figsize=(13.5, 9.0))

    # <n>
    for r in results:
        ax[0, 0].plot(
            r["cycles_axis"],
            r["mean_n"],
            linewidth=1.4,
            label=labels[r["temperature_K"]],
        )
    ax[0, 0].set_xlabel("Number of cycles $t/T$")
    ax[0, 0].set_ylabel(r"Mean occupancy $\langle n\rangle$")
    ax[0, 0].set_title("Mean occupation")
    ax[0, 0].legend(frameon=False)

    # P0 + P1
    for r in results:
        ax[0, 1].plot(
            r["cycles_axis"],
            r["p01"],
            linewidth=1.4,
            label=labels[r["temperature_K"]],
        )
    ax[0, 1].set_xlabel("Number of cycles $t/T$")
    ax[0, 1].set_ylabel(r"$P_0+P_1$")
    ax[0, 1].set_ylim(-0.02, 1.02)
    ax[0, 1].set_title("Low-Fock weight")
    ax[0, 1].legend(frameon=False)

    # Pair amplitude
    for r in results:
        ax[1, 0].plot(
            r["cycles_axis"],
            r["pair_abs"],
            linewidth=1.4,
            label=labels[r["temperature_K"]],
        )
    ax[1, 0].set_xlabel("Number of cycles $t/T$")
    ax[1, 0].set_ylabel(r"$|\langle aa\rangle|$")
    ax[1, 0].set_title("Anomalous pair amplitude")
    ax[1, 0].legend(frameon=False)

    # Final Fock distribution
    max_level_to_plot = min(60, N_MAIN)
    levels = np.arange(max_level_to_plot)
    width = 0.42

    for j, r in enumerate(results):
        shift = (j - 0.5) * width
        ax[1, 1].bar(
            levels + shift,
            r["pops"][:max_level_to_plot],
            width=width,
            alpha=0.75,
            label=labels[r["temperature_K"]],
        )

    ax[1, 1].set_xlabel("Fock level $n$")
    ax[1, 1].set_ylabel("Final probability")
    ax[1, 1].set_title(f"Final Fock distribution after {NCYC} cycles")
    ax[1, 1].legend(frameon=False)

    fig.suptitle(
        (
            "Finite-temperature Lindblad stress test\n"
            f"$U={U}$, $\\eta={ETA}$, $\\alpha={ALPHA}$, "
            f"$f={FREQ_HZ/1e9:.0f}$ GHz, $N={N_MAIN}$"
        ),
        fontsize=13,
    )

    plt.tight_layout(rect=[0.0, 0.0, 1.0, 0.95])

    fig.savefig(
        OUTPUT_DIR / "Figure_finite_temperature_comparison.png",
        dpi=200,
    )
    fig.savefig(
        OUTPUT_DIR / "Figure_finite_temperature_comparison.pdf",
    )

    plt.close(fig)


# ============================================================================
# MAIN
# ============================================================================

def main():
    print("=" * 79)
    print("FINITE-TEMPERATURE LINDBLAD STRESS TEST")
    print("=" * 79)

    print(f"Physical frequency: {FREQ_HZ / 1e9:.1f} GHz")
    print(f"Temperature: 310 K")
    print(
        "Thermal bath occupation at 310 K: "
        f"{thermal_occupation(FREQ_HZ, 310.0):.6f}"
    )
    print(f"Main Fock basis: N={N_MAIN}")
    print(f"Duration: {NCYC} cycles")
    print()

    convergence_rows = []

    if CHECK_CONVERGENCE:
        convergence_rows = convergence_check()

    results = []

    for temperature_k in TEMPERATURES_K:
        print("\n" + "=" * 79)
        print(f"MAIN RUN: T={temperature_k:.0f} K, N={N_MAIN}, {NCYC} cycles")
        print("=" * 79)

        result = run_case(N_MAIN, temperature_k, NCYC)
        results.append(result)

        print(json.dumps(result["summary"], indent=2))

    save_results(results, convergence_rows)
    make_figure(results)

    print("\n" + "=" * 79)
    print("SAVED FILES")
    print("=" * 79)
    print(OUTPUT_DIR / "finite_temperature_summary.json")
    print(OUTPUT_DIR / "finite_temperature_timeseries.csv")
    print(OUTPUT_DIR / "finite_temperature_final_fock.csv")
    print(OUTPUT_DIR / "Figure_finite_temperature_comparison.png")
    print(OUTPUT_DIR / "Figure_finite_temperature_comparison.pdf")

    print("\nInterpretation warning:")
    print(
        "Do not trust the 310 K result unless the convergence check shows "
        "negligible population near the basis cutoff and stable observables "
        "when N is increased."
    )


if __name__ == "__main__":
    main()
