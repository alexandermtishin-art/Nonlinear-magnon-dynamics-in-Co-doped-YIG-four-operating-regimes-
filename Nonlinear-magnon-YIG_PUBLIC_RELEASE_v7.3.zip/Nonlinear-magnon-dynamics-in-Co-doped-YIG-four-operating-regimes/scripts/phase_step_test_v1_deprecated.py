"""
=============================================================================
 PAIR-PHASE STEP-RESPONSE TEST
=============================================================================
 Purpose
 -------
 The five-phase scan measured Phi_pair = phi_0 - phi_d with slope -0.99984.
 For a strictly periodic drive that relation follows from time-translation
 symmetry (shifting phi_d is the same as shifting the time origin), so it is
 a sharpness/consistency check, not a demonstration of dynamical control.

 This test breaks that symmetry: phi_d is held at 0, then STEPPED at
 Omega*t = T_STEP.  The protocol is no longer periodic, so the transient is
 genuine dynamics.  We extract:
     - the response time tau_resp of the rotating-frame pair phase,
     - the sign convention of the phase transfer,
     - any overshoot,
     - whether the mean occupation <n> is disturbed by the step.

 Model (same as the matched resonant bridge run)
 -----------------------------------------------
     H(t) = Omega a^dag a
          + (U*Omega/2) a^dag^2 a^2
          + (G(t)/2) (a^dag^2 + a^2)
     G(t) = eta*Omega*sin(2*Omega*t + phi_d(t))
     Lindblad collapse operator sqrt(kappa) a,  kappa = 2*alpha*Omega

 Implementation note
 -------------------
 The step is a discontinuity in H(t).  An adaptive solver can integrate
 straight across it and miss it, so the run is SPLIT into two mesolve calls:
 segment 1 with phi_d = 0, segment 2 started from the final state of
 segment 1 with phi_d = phi_step and the time origin kept absolute.
=============================================================================
"""

import numpy as np
import matplotlib.pyplot as plt
from qutip import destroy, basis, mesolve

# ----------------------------------------------------------------- parameters
OMEGA = 1.0
U     = 0.55
ETA   = 1.2
ALPHA = 0.01
KAPPA = 2.0 * ALPHA * OMEGA
N     = 50                      # Fock truncation (same as the five-phase run)

T_TOTAL = 200.0                 # total normalized time Omega*t
T_STEP  = 100.0                 # time of the phase step
PTS_PER_CYCLE = 200             # output points per DRIVE cycle (2*Omega)
                                # -> resolves the ~0.22 rad phase ripple

PHI_STEPS = [0.0, np.pi / 4, np.pi / 2, np.pi]   # phi_d applied after the step
                                                 # 0.0 is the null control

DRIVE_PERIOD = np.pi / OMEGA    # period of sin(2*Omega*t)

# ----------------------------------------------------------------- operators
a  = destroy(N)
ad = a.dag()
n_op   = ad * a
pair   = a * a                                  # <aa>, anomalous correlator
H0     = OMEGA * n_op + 0.5 * U * OMEGA * ad * ad * a * a
H_pair = 0.5 * (ad * ad + a * a)                # multiplies G(t)
c_ops  = [np.sqrt(KAPPA) * a]
e_ops  = [n_op, pair]

rho0 = basis(N, 0) * basis(N, 0).dag()


def drive_coeff(phi_d):
    """Return G(t) with a fixed drive phase phi_d."""
    def _f(t, **kwargs):
        return ETA * OMEGA * np.sin(2.0 * OMEGA * t + phi_d)
    return _f


def run_segment(state, t_grid, phi_d):
    """Integrate one segment at constant phi_d; return result and final state."""
    H = [H0, [H_pair, drive_coeff(phi_d)]]
    res = mesolve(H, state, t_grid, c_ops=c_ops, e_ops=e_ops,
                  options={"atol": 1e-10, "rtol": 1e-8,
                           "nsteps": 200000, "store_final_state": True})
    return res, res.final_state


def make_grid(t0, t1):
    npts = int(round((t1 - t0) / DRIVE_PERIOD * PTS_PER_CYCLE)) + 1
    return np.linspace(t0, t1, npts)


def cycle_average(t, y, period):
    """Boxcar average over one drive period; returns the smoothed signal."""
    dt = t[1] - t[0]
    w  = max(int(round(period / dt)), 1)
    if w % 2 == 0:
        w += 1
    kern = np.ones(w) / w
    pad  = w // 2
    ypad = np.concatenate([np.full(pad, y[0]), y, np.full(pad, y[-1])])
    return np.convolve(ypad, kern, mode="valid")


def wrap_pi(x):
    return (x + np.pi) % (2.0 * np.pi) - np.pi


# ----------------------------------------------------------------- main loop
grid1 = make_grid(0.0, T_STEP)
res1, state_at_step = run_segment(rho0, grid1, 0.0)

print("=" * 78)
print("PAIR-PHASE STEP-RESPONSE TEST")
print("=" * 78)
print(f"Omega={OMEGA}  U={U}  eta={ETA}  alpha={ALPHA}  kappa={KAPPA}  N={N}")
print(f"T_total={T_TOTAL}  T_step={T_STEP}  pts/drive-cycle={PTS_PER_CYCLE}")
print(f"damping time 1/(alpha*Omega) = {1.0/(ALPHA*OMEGA):.1f}")
print("=" * 78)

rows = []
traces = {}

for phi_step in PHI_STEPS:
    grid2 = make_grid(T_STEP, T_TOTAL)
    res2, _ = run_segment(state_at_step, grid2, phi_step)

    # stitch (drop the duplicated boundary point of segment 2)
    t   = np.concatenate([grid1, grid2[1:]])
    nn  = np.concatenate([np.real(res1.expect[0]), np.real(res2.expect[0])[1:]])
    aa  = np.concatenate([res1.expect[1], res2.expect[1][1:]])

    # rotating-frame pair phase: arg<aa> + 2*Omega*t, unwrapped
    phi_raw  = np.unwrap(np.angle(aa))
    phi_rot  = phi_raw + 2.0 * OMEGA * t
    phi_sm   = cycle_average(t, phi_rot, DRIVE_PERIOD)
    n_sm     = cycle_average(t, nn, DRIVE_PERIOD)

    settled = t > 0.5 * T_STEP        # skip the initial build-up from vacuum
    print(f"   min |<aa>| after settling = {np.min(np.abs(aa[settled])):.4f}"
          "   (the phase is ill-defined if this approaches 0)")

    # levels: last 20% of each segment
    pre  = (t > 0.6 * T_STEP) & (t < T_STEP)
    post = (t > T_TOTAL - 0.2 * (T_TOTAL - T_STEP))
    lvl_pre,  lvl_post  = phi_sm[pre].mean(), phi_sm[post].mean()
    n_pre,    n_post    = n_sm[pre].mean(),   n_sm[post].mean()
    d_phi = wrap_pi(lvl_post - lvl_pre)

    # exponential fit of the approach, on the post-step segment
    m = t >= T_STEP
    tt, yy = t[m] - T_STEP, phi_sm[m]
    dev = yy - lvl_post
    tau = np.nan
    if abs(d_phi) > 0.05:
        try:
            from scipy.optimize import curve_fit
            p0 = [lvl_post, dev[0] if dev[0] != 0 else 1e-3, 10.0]
            popt, _ = curve_fit(lambda x, c, A, T: c + A * np.exp(-x / T),
                                tt, yy, p0=p0, maxfev=40000)
            tau = abs(popt[2])
        except Exception as e:                                    # noqa
            print("   fit failed:", e)
    # overshoot relative to the total step
    if abs(d_phi) > 0.05:                     # only meaningful for a real step
        overshoot = (np.max(np.abs(yy - lvl_pre)) - abs(d_phi)) / abs(d_phi)
    else:
        overshoot = np.nan

    # phase sharpness in the post-step steady state (circular statistics)
    resid = phi_rot[post] - phi_sm[post]
    R = np.abs(np.mean(np.exp(1j * resid)))
    circ_std = np.sqrt(-2.0 * np.log(R)) if R > 0 else np.nan

    ratio = (-d_phi / phi_step) if phi_step > 1e-9 else np.nan
    rows.append((phi_step, lvl_pre, lvl_post, d_phi, ratio,
                 tau, overshoot, n_pre, n_post, R, circ_std))
    traces[phi_step] = (t, phi_sm, n_sm)

    print(f"\nphi_step = {phi_step/np.pi:.2f} pi")
    print(f"   Phi_pair  pre = {lvl_pre:+.6f} rad   post = {lvl_post:+.6f} rad")
    print(f"   delta Phi     = {d_phi:+.6f} rad  ({d_phi/np.pi:+.4f} pi)")
    if phi_step > 1e-9:
        print(f"   ratio -dPhi/phi_step = {-d_phi/phi_step:+.5f}")
    else:
        print("   (null control: dPhi and tau should be ~0 / undefined)")
    print(f"   tau_resp      = {tau:.3f}  (normalized Omega*t units;"
          f" one drive cycle = {DRIVE_PERIOD:.3f}, 1/(alpha*Omega) = "
          f"{1.0/(ALPHA*OMEGA):.1f})")
    print(f"   overshoot     = {overshoot:+.4f}")
    print(f"   <n>  pre = {n_pre:.6f}   post = {n_post:.6f}   "
          f"change = {100*(n_post-n_pre)/n_pre:+.3f} %")
    print(f"   post-step phase resultant R = {R:.4f}, circular std = "
          f"{circ_std:.4f} rad ({np.degrees(circ_std):.1f} deg)")

# ----------------------------------------------------------------- summary
print("\n" + "=" * 78)
print("SUMMARY")
print("=" * 78)
hdr = ("phi_step/pi  dPhi/pi   -dPhi/phi_d   tau_resp   overshoot   "
       "d<n> [%]   R      circ_std")
print(hdr)
for (ps, lp, lo, dp, ratio, tau, ov, npre, npost, R, cs) in rows:
    print(f"{ps/np.pi:9.2f}  {dp/np.pi:+8.4f}  {ratio:11.5f}  {tau:9.3f}  "
          f"{ov:+9.4f}  {100*(npost-npre)/npre:+8.3f}  {R:.4f}  {cs:.4f}")

print("\nInterpretation guide:")
print("  tau_resp << 1/(alpha*Omega)=%.0f  -> phase follows the drive fast;"
      % (1.0/(ALPHA*OMEGA)))
print("                                      collective-mode phase control"
      " is dynamically supported.")
print("  tau_resp ~  1/(alpha*Omega)      -> the phase is reset by damping,"
      " not by the drive;")
print("                                      the 'phase encoding' claim must"
      " be weakened accordingly.")
print("  null control (phi_step=0) must give dPhi ~ 0 and no transient;"
      " if not, the")
print("  extraction pipeline itself is producing the response.")

# ----------------------------------------------------------------- figure
fig, ax = plt.subplots(2, 1, figsize=(11, 8), sharex=True)
for phi_step in PHI_STEPS:
    t, phi_sm, n_sm = traces[phi_step]
    lab = rf"$\phi_d = {phi_step/np.pi:.2f}\pi$"
    ax[0].plot(t, phi_sm, lw=1.4, label=lab)
    ax[1].plot(t, n_sm, lw=1.4, label=lab)
ax[0].axvline(T_STEP, color="k", ls=":", lw=1)
ax[1].axvline(T_STEP, color="k", ls=":", lw=1)
ax[0].set_ylabel(r"cycle-averaged $\Phi_{\rm pair}=\arg\langle aa\rangle+2\Omega t$"
                 "\n[rad]")
ax[1].set_ylabel(r"cycle-averaged $\langle n\rangle$")
ax[1].set_xlabel(r"normalized time $\Omega t$")
ax[0].set_title("Step response of the rotating-frame pair phase "
                r"(step applied at $\Omega t=%.0f$)" % T_STEP)
ax[0].legend(ncol=2, fontsize=9)
ax[0].grid(alpha=.3); ax[1].grid(alpha=.3)
plt.tight_layout()
plt.savefig("pair_phase_step_response.png", dpi=150)
plt.show()
