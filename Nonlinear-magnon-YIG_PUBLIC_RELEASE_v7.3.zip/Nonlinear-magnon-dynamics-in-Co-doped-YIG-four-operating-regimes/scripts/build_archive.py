"""
=============================================================================
 ARCHIVE BUILDER  --  magnonic protocol project
=============================================================================
 Paste into one Colab cell and run.  It will:

   1. scan the directories listed in SOURCE_DIRS (plus /content and Drive)
   2. optionally RE-RUN the archived scripts so that results/*.csv are
      actually regenerated rather than only referenced      <- RUN_SCRIPTS
   3. sort everything into scripts/ results/ figures/ docs/ notebooks/
   4. de-duplicate by content hash (same file found twice is stored once)
   5. write MANIFEST.txt, SHA256SUMS.txt and requirements.txt
   6. write PROVENANCE.md: which manuscript figure has a generating script
      and which does not  -- this is the part an editor actually checks
   7. verify the checksums, zip, and offer the zip for download

 Nothing is deleted or modified outside BUILD_DIR.
=============================================================================
"""

import hashlib
import os
import re
import shutil
import subprocess
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

# ------------------------------------------------------------------ config
PROJECT   = "magnonic_protocol_archive"
BUILD_DIR = Path("/content/_archive_build")
STAMP     = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M")
ZIP_PATH  = Path(f"/content/{PROJECT}_{STAMP}.zip")

# Where to look.  Add your own paths; missing ones are skipped silently.
SOURCE_DIRS = [
    Path("/content"),
    Path("/content/drive/MyDrive"),          # only if Drive is mounted
    Path(f"/content/{PROJECT}"),
]

RUN_SCRIPTS   = False    # True -> execute the archived scripts to rebuild results/
SCRIPT_TIMEOUT = 3600    # seconds per script
MAX_FILE_MB   = 60       # skip anything larger, report it instead

SKIP_DIRS  = {"__pycache__", ".ipynb_checkpoints", ".git", ".config",
              "sample_data", "_archive_build", "drive/.shortcut-targets-by-id"}
SKIP_NAMES = {".DS_Store", "Thumbs.db"}

# extension -> destination folder
ROUTE = {
    ".py": "scripts", ".sh": "scripts",
    ".csv": "results", ".txt": "results", ".json": "results", ".npz": "results",
    ".png": "figures", ".pdf": "figures", ".svg": "figures",
    ".jpg": "figures", ".jpeg": "figures",
    ".docx": "docs", ".md": "docs", ".bib": "docs", ".tex": "docs",
    ".cff": "docs", ".yml": "docs", ".yaml": "docs", ".toml": "docs",
    ".ipynb": "notebooks",
}

# extensionless files kept at the archive root
KEEP_AT_ROOT = {"LICENSE", "CITATION", "NOTICE", "AUTHORS", ".gitignore"}

# Which manuscript figure is produced by which script.  Keep this table in
# step with the manuscript; it is what PROVENANCE.md is built from.
FIGURE_SOURCES = {
    "Figure 1":  "legacy_regen_fig12.py",
    "Figure 2":  "legacy_regen_fig12.py",
    "Figure 3":  None,          # legacy U-scan, different Kerr normalization
    "Figure 4":  "protocol_audit.py + make_final_figures.py",
    "Figure 5":  "five_phase_control.py + make_final_figures.py",
    "Figure 6":  None,          # compute window vs damping (semiclassical)
    "Figure 7":  None,          # |v|^2 time evolution (semiclassical)
    "Figure 8":  None,          # universal phase map (semiclassical)
    "Figure 9":  None,          # 150-cycle stress test (semiclassical)
    "Figure S1": None,          # damped norm diagnostic
    "Figure S2": "protocol_audit.py",
    "Figure S3": "phase_step_test_v2.py",
}

REQUIREMENTS = """numpy>=1.26
scipy>=1.11
pandas>=2.0
matplotlib>=3.8
qutip>=5.3,<5.5
python-docx>=1.1
"""

# ------------------------------------------------------------------ helpers
def sha256(path: Path, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(chunk), b""):
            h.update(block)
    return h.hexdigest()


def skipped(path: Path) -> bool:
    if path.name in SKIP_NAMES or path.name.startswith("~$"):
        return True
    return any(part in SKIP_DIRS for part in path.parts)


def collect():
    """Return {dest_relpath: source_path}, de-duplicated by content hash."""
    found, by_hash, oversize, unrouted = {}, {}, [], []
    seen_roots = []
    for root in SOURCE_DIRS:
        if not root.exists() or any(root == r or root in r.parents for r in seen_roots):
            continue
        seen_roots.append(root)
        for src in sorted(root.rglob("*")):
            if not src.is_file() or skipped(src):
                continue
            ext = src.suffix.lower()
            if ext not in ROUTE and src.name not in KEEP_AT_ROOT:
                unrouted.append(src)
                continue
            mb = src.stat().st_size / 1e6
            if mb > MAX_FILE_MB:
                oversize.append((src, mb))
                continue
            digest = sha256(src)
            if digest in by_hash:
                continue
            by_hash[digest] = src
            # keep the sub-path below the archive folder if the file already
            # lives inside a project tree, otherwise route by extension
            parts = src.parts
            if src.name in KEEP_AT_ROOT:
                dest = Path(src.name)
            elif PROJECT in parts:
                rel = Path(*parts[parts.index(PROJECT) + 1:])
                if len(rel.parts) == 1:                 # root-level file, keep it there
                    dest = rel
                elif rel.parts[0] in {"scripts", "results", "figures",
                                      "docs", "notebooks", "legacy"}:
                    dest = rel
                else:
                    dest = Path(ROUTE[ext]) / src.name
            else:
                dest = Path(ROUTE[ext]) / src.name
            i, base = 1, dest
            while str(dest) in found:
                dest = base.with_name(f"{base.stem}__{i}{base.suffix}")
                i += 1
            found[str(dest)] = src
    return found, oversize, unrouted


def run_scripts(script_dir: Path):
    """Execute each archived script so results/ is regenerated, not just cited."""
    log = []
    for script in sorted(script_dir.glob("*.py")):
        if "deprecated" in script.name:
            log.append((script.name, "skipped (deprecated)", 0.0))
            continue
        t0 = datetime.now()
        try:
            r = subprocess.run([sys.executable, script.name],
                               cwd=script.parent, capture_output=True,
                               text=True, timeout=SCRIPT_TIMEOUT)
            status = "ok" if r.returncode == 0 else f"FAILED rc={r.returncode}"
            if r.returncode != 0:
                status += " | " + (r.stderr.strip().splitlines() or ["?"])[-1][:160]
        except subprocess.TimeoutExpired:
            status = f"TIMEOUT after {SCRIPT_TIMEOUT}s"
        dt = (datetime.now() - t0).total_seconds()
        log.append((script.name, status, dt))
        print(f"   {script.name:38s} {status:24s} {dt:7.1f}s")
    return log


def write_provenance(build: Path, run_log):
    have = {p.name for p in (build / "scripts").glob("*.py")} \
        if (build / "scripts").exists() else set()
    lines = [f"# Provenance report\n",
             f"Generated {datetime.now(timezone.utc).isoformat(timespec='seconds')}\n",
             "\n## Figure -> generating script\n",
             "| Figure | Script | In archive |",
             "|---|---|---|"]
    missing = []
    for fig, srcs in FIGURE_SOURCES.items():
        if srcs is None:
            lines.append(f"| {fig} | (none recorded) | **NO** |")
            missing.append(fig)
        else:
            names = [s.strip() for s in srcs.split("+")]
            ok = all(n in have for n in names)
            lines.append(f"| {fig} | `{srcs}` | {'yes' if ok else '**NO**'} |")
            if not ok:
                missing.append(fig)
    lines.append("")
    if missing:
        lines.append("## Figures without a generating script in this archive\n")
        lines.append(", ".join(missing) + "\n")
        lines.append("Any numerical claim attached to these figures should either be "
                     "labelled in the manuscript as coming from a legacy calculation "
                     "that is not reproducibly archived, or be regenerated with an "
                     "archived script before submission.\n")
    else:
        lines.append("Every listed figure has a generating script in this archive.\n")

    res = build / "results"
    csvs = sorted(p.relative_to(build) for p in res.rglob("*.csv")) if res.exists() else []
    lines.append("\n## Result files present\n")
    lines.extend([f"- `{c}`" for c in csvs] or ["- (none)"])
    if not csvs:
        lines.append("\n**Warning:** no CSV outputs are archived. Numerical values "
                     "quoted in the Supplementary Information are then not "
                     "independently checkable. Re-run with RUN_SCRIPTS = True.\n")

    if run_log:
        lines.append("\n## Script execution log (this build)\n")
        lines.append("| Script | Status | Seconds |")
        lines.append("|---|---|---|")
        lines.extend([f"| `{n}` | {s} | {t:.1f} |" for n, s, t in run_log])

    (build / "PROVENANCE.md").write_text("\n".join(lines), encoding="utf-8")
    return missing


# ------------------------------------------------------------------ build
print("=" * 74)
print(f"ARCHIVE BUILDER  ->  {ZIP_PATH.name}")
print("=" * 74)

if BUILD_DIR.exists():
    shutil.rmtree(BUILD_DIR)
build = BUILD_DIR / PROJECT
build.mkdir(parents=True)

print("\n[1/6] scanning ...")
files, oversize, unrouted = collect()
for dest, src in files.items():
    target = build / dest
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, target)
by_folder = {}
for dest in files:
    by_folder.setdefault(Path(dest).parts[0], []).append(dest)
for folder in sorted(by_folder):
    print(f"   {folder:12s} {len(by_folder[folder]):4d} files")
if oversize:
    print("   skipped (too large):")
    for p, mb in oversize:
        print(f"      {mb:7.1f} MB  {p}")
if unrouted:
    exts = sorted({p.suffix.lower() for p in unrouted if p.suffix})
    print(f"   ignored extensions: {', '.join(exts) if exts else '(none)'}")

run_log = []
if RUN_SCRIPTS and (build / "scripts").exists():
    print("\n[2/6] re-running archived scripts ...")
    run_log = run_scripts(build / "scripts")
    # pick up anything the scripts just wrote
    for src in sorted((build / "scripts").rglob("*")):
        if src.is_file() and src.suffix.lower() in {".csv", ".png", ".pdf", ".txt"}:
            dest = build / ("results" if src.suffix.lower() in {".csv", ".txt"}
                            else "figures") / src.name
            dest.parent.mkdir(parents=True, exist_ok=True)
            if not dest.exists():
                shutil.move(str(src), dest)
else:
    print("\n[2/6] script execution skipped (RUN_SCRIPTS = False)")

print("\n[3/6] writing requirements / manifest / checksums ...")
(build / "requirements.txt").write_text(REQUIREMENTS, encoding="utf-8")

all_files = sorted(p for p in build.rglob("*") if p.is_file())
manifest = "\n".join(str(p.relative_to(build)) for p in all_files)
(build / "MANIFEST.txt").write_text(manifest + "\n", encoding="utf-8")

sums = []
for p in sorted(x for x in build.rglob("*") if x.is_file()
                and x.name not in {"SHA256SUMS.txt"}):
    sums.append(f"{sha256(p)}  {p.relative_to(build)}")
(build / "SHA256SUMS.txt").write_text("\n".join(sums) + "\n", encoding="utf-8")
print(f"   {len(sums)} files checksummed")

print("\n[4/6] provenance report ...")
missing = write_provenance(build, run_log)
if missing:
    print("   figures WITHOUT a generating script:", ", ".join(missing))
else:
    print("   every listed figure has a generating script")

print("\n[5/6] verifying checksums ...")
bad = []
for line in (build / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines():
    digest, rel = line.split("  ", 1)
    p = build / rel
    if not p.exists() or sha256(p) != digest:
        bad.append(rel)
print("   OK" if not bad else f"   MISMATCH: {bad}")

print("\n[6/6] zipping ...")
with zipfile.ZipFile(ZIP_PATH, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
    for p in sorted(x for x in BUILD_DIR.rglob("*") if x.is_file()):
        zf.write(p, p.relative_to(BUILD_DIR))
size_mb = ZIP_PATH.stat().st_size / 1e6
print(f"   {ZIP_PATH}  ({size_mb:.1f} MB, {len(sums)} files)")

# ------------------------------------------------------------------ deliver
try:
    from google.colab import files as colab_files          # type: ignore
    colab_files.download(str(ZIP_PATH))
    print("\ndownload started")
except Exception:
    print("\n(not in Colab, or download blocked -- the zip is at the path above)")

# Optional: also drop a copy in Drive if it is mounted
drive_out = Path("/content/drive/MyDrive/magnonic_archives")
if drive_out.parent.exists():
    drive_out.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ZIP_PATH, drive_out / ZIP_PATH.name)
    print(f"copy saved to {drive_out / ZIP_PATH.name}")
