# Provenance report

Generated 2026-07-24T15:28:29+00:00


## Figure -> generating script

| Figure | Script | In archive |
|---|---|---|
| Figure 1 | `legacy_regen_fig12.py` | yes |
| Figure 2 | `legacy_regen_fig12.py` | yes |
| Figure 3 | (none recorded) | **NO** |
| Figure 4 | `protocol_audit.py + make_final_figures.py` | yes |
| Figure 5 | `five_phase_control.py + make_final_figures.py` | yes |
| Figure 6 | (none recorded) | **NO** |
| Figure 7 | (none recorded) | **NO** |
| Figure 8 | (none recorded) | **NO** |
| Figure 9 | (none recorded) | **NO** |
| Figure S1 | (none recorded) | **NO** |
| Figure S2 | `protocol_audit.py` | yes |
| Figure S3 | `phase_step_test_v2.py` | yes |

## Figures without a generating script in this archive

Figure 3, Figure 6, Figure 7, Figure 8, Figure 9, Figure S1

Any numerical claim attached to these figures should either be labelled in the manuscript as coming from a legacy calculation that is not reproducibly archived, or be regenerated with an archived script before submission.


## Result files present

- `results/U_scan_quantum.csv`
- `results/anomalous_correlator_convention_audit.csv`
- `results/anomalous_correlator_reported_audit.csv`
- `results/bogoliubov_lindblad_bridge.csv`
- `results/five_phase_pair_control_dynamics.csv`
- `results/five_phase_pair_control_fit.csv`
- `results/five_phase_pair_control_summary.csv`
- `results/protocol_audit_full_dynamics.csv`
- `results/protocol_audit_reported_summary.csv`
- `results/protocol_audit_summary.csv`
- `results/quantum_U_eta_scan_partial_27_points.csv`
- `results/single_magnon_U_eta_scan_qutip5.csv`