# Spin content fixes the Kerr nonlinearity of a magnon mode

Reproducibility archive for *Spin content fixes the Kerr nonlinearity of a
magnon mode: the necessary criterion alpha N_eff < omega_a/Omega for nonlinear
magnon confinement in Co-doped YIG* (A. M. Tishin).  Documents in `docs/` are
revision v6.1 (2026-08-15).

**Repository name.** The directory and repository name
`Nonlinear-magnon-dynamics-in-Co-doped-YIG-four-operating-regimes` is retained
from earlier releases so that URLs cited in the deposited manuscript and in
previous releases keep resolving. It no longer matches the manuscript title.

## Release v6 — 2026-08-15 (current)

Read `CHANGELOG.md` first. Three things changed and they affect every
microscopic number in the archive:

1. `N_eff` is the net macrospin `M_s V/(g mu_B)`, not `S * N_ion` and not the
   formula-unit count. For the 20 x 20 x 10 nm cell `N_eff = 3.0e4` and
   `U = 6.6e-5`.
2. The parametric threshold is `eta > 2 alpha`, not `eta > 4 alpha`. The
   saturation bound `eta < 4U` is unchanged.
3. Runs in the `(U Omega/2) a^d2 a^2` normalization are labelled `U_audit` and
   convert as `U = U_audit/2` into the manuscript convention of Eq. (4).

Current manuscript and Supplementary Information: `docs/`. The version
submitted to Physical Review Materials in August 2026 is under
`legacy/manuscript_PRM_2026-08/` and must not be used for current numbers.
Quoted sigma and BER values, the microscopic values and the criterion numbers
are collected in `CURRENT_NUMERICAL_RESULTS.md`.


## Public release v3 — 2026-08-01

This release replaces the manuscript, Supplementary Information, all main and
supplementary figures, the final corrected notebook, and the pair-phase dataset
used for the current numerical values.

Canonical pair-phase results are under:

`results/pair_phase_std_low_damping_final/`

The older alpha=0.01 package is retained only under `legacy/` and must not be
used for the current manuscript.

See `CURRENT_NUMERICAL_RESULTS.md` for the exact quoted sigma and BER values.

Reproducibility archive for the manuscript and its numerical audits (July 2026).

## Release v4 — 2026-08-03: convention fix, feasibility analysis

Three things changed in this release, and they matter for how the numbers
should be read.

**The frequency scan was recomputed in the canonical Kerr convention.** The
archived scan used `H_Kerr = U a^d2 a^2`, whereas the protocol audit, the
five-phase runs and the phase-statistics campaign all use
`H_Kerr = (U Omega/2) a^d2 a^2`. For Omega = 1 the first is twice the
anharmonicity of the second, so Table 3 of the manuscript was mixing two
normalizations. The 17-point recomputation is in
`results/canonical_convention/`; every point converged, with the basis size
chosen from the occupancy actually reached and verified by a repeat at 1.2 N.
Chief consequences: at 6 THz `P0+P1` is 0.9254 rather than 0.9593, `<n>` is
0.2452 rather than 0.1643, and `|<aa>|` is not flat across the scan but varies
by 37% with a minimum near 2 THz.

**The realizability of U was tested rather than assumed.** A normal-mode
analysis of the linearised Landau-Lifshitz equation for the 20 x 20 x 10 nm
cell (`scripts/micromagnetics/`) finds no localised mode: the least extended of
the 25 lowest occupies a quarter of the cell, giving N_eff ~ 7.7e3 and
U ~ 2.6e-4, against the U = 0.05-0.55 used in the Lindblad calculations. The
exchange cost of confining a mode to 4-40 units of net spin is computed in
`mode_bound.py`; such a mode would be 0.8-1.7 nm across, at or below the YIG
unit cell, and would sit at 5-22 THz.  (These values are the v6 recomputation;
see the release note below.)

**The single-mode assumption was checked mode by mode.** `scripts/multimode/`
counts the modes above parametric threshold, integrates them together with
cross-Kerr coupling, and then solves the full multimode Lindblad equation. On
the 50 GHz carrier one mode is above threshold and the inverse participation
ratio is 1.0; at 6 THz there are 589 and the ratio is 53. The quantum
calculation reaches M = 8 co-driven modes and shows what that costs: the
two-level population is untouched, rising from 0.925 to 0.972, but the pair
correlation that carries the phase falls from 0.393 to 0.128, following
`M^-1.31` to within 4 %. The mechanism is cross-Kerr detuning rather than
leakage, since a spatially uniform pump transfers no quanta between modes.

`scripts/canonical_convention/phase_vs_U.py` establishes the one result that
does not depend on U: repeating the five-phase protocol at U = 0.55, 0.10 and
0.02 leaves the pair-phase transfer coefficient at -1.00000 with
R^2 = 0.999999 throughout, while the occupancy rises from 1.2 to 30 magnons.

### New scripts

- `scripts/micromagnetics/micromagnetic_modes.py` — eigenmodes of the linearised
  Landau-Lifshitz equation on a 2 nm mesh, exchange + uniaxial anisotropy +
  dipolar, free boundaries; reports participation ratio and N_eff per mode.
  Validated against the analytic standing-wave spectrum to 0.5%.
- `scripts/micromagnetics/mode_bound.py` — exchange frequency of a mode confined
  to a given volume, and the U it would produce.
- `scripts/multimode/multimode_stability.py` — linear parametric growth rate
  across the confined spectrum; counts modes above threshold.
- `scripts/multimode/multimode_meanfield.py` — mean-field integration of all
  modes in the gain band with self- and cross-Kerr coupling.
- `scripts/multimode/colab_multimode_regime3.py` — the full multimode Lindblad
  calculation in the excitation-number-restricted basis, reaching M = 8 via
  quantum trajectories; resumable and mirrored to Drive.
- `scripts/canonical_convention/rescan_U.py` — the Fig. 4 U scan, recomputed in
  the canonical convention.
- `scripts/canonical_convention/colab_frequency_scan_canonical.py` — the 310 K
  frequency scan; resumable, checkpointed per drive cycle, mirrors to Drive and
  survives a lost mount.
- `scripts/canonical_convention/phase_vs_U.py` — dependence of the pair-phase
  transfer on U.
- `scripts/figures/audit_numbers.py` — cross-check of every number that appears
  in more than one place in the manuscript and the Supplement.

### New data

- `results/canonical_convention/frequency_scan_canonical.csv` — the 17 accepted
  points, with basis size, truncation diagnostic and convergence flag.
- `results/canonical_convention/frequency_scan_all_attempts.csv` — every run,
  including the ones rejected for truncation, so the convergence history is
  visible.
- `results/canonical_convention/figure4_U_scan_canonical.csv` — the U scan.
- `results/multimode_quantum/multimode_regime3.csv` — the M = 1…8 quantum
  results with basis size, method, statistical error and runtime per case.

### A caution that has not gone away

Three Kerr conventions appear across this archive: `U n^2` in the legacy
Fig. 1-2 scripts, `U a^d2 a^2` in the archived frequency scan, and
`(U Omega/2) a^d2 a^2` in everything current. Since `a^d2 a^2 = n(n-1)`, the
same symbol U means a different physical anharmonicity in each, and values must
not be carried between them without an explicit conversion. The figure
generator records which convention each figure uses.

## Why this archive exists

During revision, calculations that had been labelled by the same nominal parameters `(U, eta, alpha)` were found to use different Hamiltonian conventions and different pair-drive protocols. This repository keeps the original notebooks, the corrected audit scripts, the figures available at the time of packaging, and a revised Supplementary Information document so that every numerical statement can be traced to an explicit model.

## Model conventions used by the new audit scripts

The matched Lindblad calculations use

```text
H0 = Omega a†a + (U Omega / 2) a†² a²
kappa = 2 alpha Omega
```

Two pair-drive implementations are compared:

```text
Static effective pair coupling:
Hdrive = (eta Omega / 4) (a†² + a²)

Explicit resonant modulation:
Hdrive(t) = [eta Omega sin(2 Omega t) / 2] (a†² + a²)
```

These are not interchangeable. In addition, legacy Figure 3 calculations may use a different Kerr normalization, such as `U n²`; the numerical value called `U` must not be transferred between conventions without conversion.

## Main scripts

- `scripts/protocol_audit.py` — static-versus-resonant Lindblad comparison, Bogoliubov–Lindblad bridge, parity audit, anomalous-correlator convention audit.
- `scripts/five_phase_control.py` — tests transfer of the external pump phase to the rotating-frame pair phase `arg<aa> + 2 Omega t`.
- `scripts/partial_u_eta_scan.py` — exploratory checkpointed `(U, eta)` scan. It is not a search for deterministic `|1>` preparation.
- `scripts/finite_temperature_frequency_scan_to_10THz.py` — complete 310 K static-effective-drive scan for U = 0.10 and U = 0.55 from 50 GHz to 10 THz.
- `scripts/frequency_scan_runs_21_to_38_colab.py` and `scripts/frequency_scan_runs_26_to_38_colab.py` — checkpointed Colab continuation scripts used to complete the U = 0.55 scan.
- `scripts/legacy_regen_fig12.py` — legacy figure-regeneration helper retained without scientific reinterpretation.

## Legacy material

The notebooks in `notebooks/legacy/` are retained as historical records. Their outputs should not be mixed with the corrected scripts unless the exact Hamiltonian, drive, damping convention, integration interval, and observable definitions have been matched.

## Reproducing the protocol audit

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python scripts/protocol_audit.py
```

Outputs are written to `results/protocol_audit/`.

For the five-phase test:

```bash
python scripts/five_phase_control.py
```

Outputs are written to `results/five_phase_control/`.

## Interpretation rules

1. `|v|²` and `Tr[rho a†a]` are mean occupations; neither is the probability `P1` of exactly one quantum.
2. The pair Hamiltonian preserves number parity in the unitary sector. Odd populations arise through the single-quantum loss channel.
3. The correct reduced-model convention found in the audit is closest to `u conj(v)` for comparison with `<aa>`.
4. Agreement of late-time average occupation does not imply agreement of instantaneous trajectories or higher quantum moments.
5. The 22–24 aJ value is obtained by scaling the reported absorbed-energy density to the assumed cell volume; it is not derived from the normalized occupation model.

## Included figures

- `image_527.png` — legacy 100-cycle occupation and Fock distribution.
- `image_528.png` — legacy long-time dynamics and final Fock distribution.
- `image_529.png` — legacy regulator scan.
- `image_531.png` — damped coupled-mode norm diagnostic.
- `image_532.png` — protocol audit: static versus resonant mean occupation.

The manuscript bridge figure should be regenerated by `scripts/protocol_audit.py` as `matched_bogoliubov_lindblad_occupation.png`.

## Repository status

This archive records a revision-stage calculation set. It is not a claim that every legacy result is mutually compatible. The final Supplementary Information in `docs/Supplementary_Information_PRM_final.docx` explicitly labels established equations, approximation steps, protocol-dependent results, projections, and the completed 310 K frequency scan.

## Phase-control and step-response additions

The stationary five-phase calculation gives nearly ideal transfer of the external pump phase to the rotating-frame pair phase,

```text
Phi_pair = -1.5589 - 0.99984 phi_d
R^2 = 0.9999993
```

with late-time mean occupation varying only from 1.2133 to 1.2252 and mean pair amplitude from 1.1035 to 1.1309.

A genuine dynamical step test is provided by `scripts/phase_step_test_v2.py`. It splits the propagation at the Hamiltonian discontinuity and analyzes the rotating-frame complex correlator

```text
z(t) = <aa>(t) exp(2 i Omega t)
```

rather than unwrapping the phase through amplitude zeros. The steady phase transfer remains nearly one-to-one. Small/moderate steps retain finite pair amplitude, whereas pi/2 and pi steps transiently drive the pair amplitude close to zero and cannot be described as phase-only switching. The fitted response times are approximately 14.5-26.1 normalized time units, below the damping time 100.

## Publication figures

- `figures/Figure_4_Bogoliubov_Lindblad.png` - matched resonant occupation bridge.
- `figures/Figure_5_Pair_Phase_Control.png` - stationary phase-transfer and amplitude-robustness figure.
- `figures/Figure_S5_Pair_Phase_Step_Response.png` - complex-plane dynamical step-response audit.

Regenerate Figures 4 and 5 from CSV data with:

```bash
python scripts/make_final_figures.py --input-dir results --output-dir final_figures
```

The CSV paths can also be supplied by placing the generated files in the current directory and omitting `--input-dir`.

## Finite-temperature 310 K frequency scan

The public archive now includes the completed U=0.55 scan through 10 THz, plus a verified 6-10 THz subset and a combined plotting table. See `results/finite_temperature_310K_frequency_scan/`. The scan uses the static effective pair-drive Hamiltonian and must be distinguished from the explicitly resonant phase-control protocol.

Before quoting numerical values, read `ARCHIVE_AUDIT.md`.
