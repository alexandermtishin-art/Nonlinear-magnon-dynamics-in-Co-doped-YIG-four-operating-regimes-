# Changelog

## 2026-09-17 — rebuilt reproducibility release

- Corrected the Regime-IV segmented protocol so the resonant-pump phase is continuous in absolute trajectory time across checkpoints.
- Corrected final Fock probabilities to use `|psi|^2`.
- Removed the superseded Regime-IV segmented script and its old summary result from the public package.
- Added revision audit scripts for the linear QLE cross-check, transition-resolved dissipator sensitivity, and reset-and-read phase basis convergence.
- Replaced stale document snapshots with the release-ready Supplementary Information.
- Added a public-release text gate and regenerated the file manifest and SHA256 checksums.
