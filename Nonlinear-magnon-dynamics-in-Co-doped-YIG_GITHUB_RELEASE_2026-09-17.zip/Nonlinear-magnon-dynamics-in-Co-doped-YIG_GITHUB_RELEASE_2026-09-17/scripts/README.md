# Scripts

The top-level scripts reproduce the original model figures and parameter scans. Subdirectories collect specialized checks.

- `protocol_correction/` — corrected finite-temperature thermal-start protocols. Use `regime_IV_corrected_protocol_v8.py` for Regime IV.
- `review_checks/` — revision-specific numerical audits.
- `canonical_convention/` — canonical-convention frequency and parameter scans.
- `figures/` — figure assembly and audit utilities.
- `micromagnetics/` — mode-spacing estimates.
- `multimode/` — multimode Regime-III checks.

The superseded Regime-IV v6 segmented script is intentionally not included.
