#!/usr/bin/env python3
"""Audit the archived reset-and-read phase basis-convergence results."""
from pathlib import Path
import pandas as pd

ROOT=Path(__file__).resolve().parents[2]
CSV=ROOT/'results'/'pair_phase_std_low_damping_final'/'results_pair_phase_std.csv'
df=pd.read_csv(CSV)
keep=df[df['regime'].isin(['II','IV'])][['regime','N','sigma_deg','population_top_10_levels_max','delta_sigma_deg_vs_previous_N']]
print(keep.to_string(index=False))

# Hard gates corresponding to the values quoted in the revision.
ii=keep[keep.regime=='II'].sort_values('N')
iv=keep[keep.regime=='IV'].sort_values('N')
assert list(ii.N)==[80,120]
assert list(iv.N)==[160,200,240]
assert abs(ii.iloc[-1].sigma_deg-29.947978404870696)<1e-9
assert abs(iv.iloc[-1].sigma_deg-40.70503642614931)<1e-9
assert abs(iv.iloc[-1].delta_sigma_deg_vs_previous_N-0.007179165327379167)<1e-12
print('\nPASS: archived phase convergence values match the revision.')
