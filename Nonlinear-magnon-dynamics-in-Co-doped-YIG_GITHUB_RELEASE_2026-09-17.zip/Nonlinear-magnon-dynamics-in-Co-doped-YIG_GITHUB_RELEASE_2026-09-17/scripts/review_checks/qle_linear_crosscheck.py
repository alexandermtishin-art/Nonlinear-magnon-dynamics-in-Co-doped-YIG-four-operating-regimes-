#!/usr/bin/env python3
"""Linear quantum-Langevin second-moment cross-check used in the revision.

Protocol-matched equations (normalized Omega=1):
  g(t) = eta*Omega/2 * sin(2*Omega*t + phi)
  dn/dt = -kappa*n + kappa*n_th - 4*g(t)*Im(m)
  dm/dt = -(kappa + 2j*Omega)*m - 2j*g(t)*(2*n+1)

At eta=1.2 and alpha=1e-3, eta/(2*alpha)=600, so the linear
U=0 problem lies far above the parametric threshold and is unbounded.
This script integrates the equations only to demonstrate that growth; it
is not a substitute for the nonlinear Kerr calculation.
"""
import argparse
import numpy as np
from scipy.integrate import solve_ivp

OMEGA = 1.0
ETA = 1.2
ALPHA = 1.0e-3
KAPPA = 2.0 * ALPHA * OMEGA


def rhs(t, y, n_th, phi):
    n, mr, mi = y
    m = mr + 1j * mi
    g = 0.5 * ETA * OMEGA * np.sin(2.0 * OMEGA * t + phi)
    dn = -KAPPA*n + KAPPA*n_th - 4.0*g*np.imag(m)
    dm = -(KAPPA + 2j*OMEGA)*m - 2j*g*(2.0*n + 1.0)
    return [float(np.real(dn)), float(np.real(dm)), float(np.imag(dm))]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--n-th', type=float, default=1.2166)
    ap.add_argument('--phi', type=float, default=0.0)
    ap.add_argument('--tmax', type=float, default=50.0)
    ap.add_argument('--growth-stop', type=float, default=1e8)
    args = ap.parse_args()

    def event(t, y):
        return args.growth_stop - abs(y[0])
    event.terminal = True
    event.direction = -1

    sol = solve_ivp(lambda t,y: rhs(t,y,args.n_th,args.phi),
                    (0.0,args.tmax), [args.n_th,0.0,0.0],
                    rtol=1e-9, atol=1e-11, max_step=0.02,
                    events=event)
    print(f"eta/(2 alpha) = {ETA/(2*ALPHA):.1f}")
    print(f"integration_end_t = {sol.t[-1]:.6g}")
    print(f"n_end = {sol.y[0,-1]:.8g}")
    print(f"|m|_end = {np.hypot(sol.y[1,-1], sol.y[2,-1]):.8g}")
    print("linear_U0_bounded =", bool(np.isfinite(sol.y[0,-1]) and abs(sol.y[0,-1]) < args.growth_stop and sol.t[-1] >= args.tmax))

if __name__ == '__main__':
    main()
