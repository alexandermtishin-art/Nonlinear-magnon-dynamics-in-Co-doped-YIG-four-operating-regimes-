"""Regenerate Figure S1: damped coupled-mode norm diagnostic.

The previous version plotted `bogoliubov_corrected_norm` -- the hyperbolic norm
already divided by exp(-2 alpha Omega t) -- against exp(-2 alpha Omega t)
itself, so the two curves could not agree and the reported deviation was 8.6e-1.
The quantity the text refers to is `bogoliubov_hyperbolic_norm` = |u|^2 - |v|^2,
which follows the analytic decay to 2.4e-9.  Panel (b) shows that residual.
"""
import numpy as np, pandas as pd, matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import AutoMinorLocator

COL2 = 6.9
BLUE, ORANGE, GREY = '#0072B2', '#E69F00', '#666666'   # Okabe-Ito
mpl.rcParams.update({
    'font.family': 'serif', 'font.serif': ['DejaVu Serif'], 'font.size': 8,
    'axes.labelsize': 8, 'axes.titlesize': 8, 'legend.fontsize': 7,
    'xtick.labelsize': 7, 'ytick.labelsize': 7, 'axes.linewidth': 0.6,
    'xtick.direction': 'in', 'ytick.direction': 'in',
    'xtick.top': True, 'ytick.right': True, 'legend.frameon': False,
    'lines.linewidth': 1.2, 'savefig.bbox': 'tight', 'savefig.pad_inches': 0.02,
})

d = pd.read_csv('protocol_audit_full_dynamics.csv')
alpha = 0.01
t = d.time.values
norm = d.bogoliubov_hyperbolic_norm.values          # |u|^2 - |v|^2
ideal = np.exp(-2 * alpha * t)
resid = np.abs(norm - ideal)
err = resid.max()

fig, ax = plt.subplots(1, 2, figsize=(COL2 * 0.82, 2.5))

ax[0].semilogy(t, norm, '-', color=BLUE, lw=1.4, label=r'numerical $|u|^{2}-|v|^{2}$')
ax[0].semilogy(t, ideal, '--', color=ORANGE, lw=1.0, dashes=(5, 3),
               label=r'$e^{-2\alpha\Omega t}$')
ax[0].set_xlabel(r'normalized time $\Omega t$')
ax[0].set_ylabel('coupled-mode norm')
ax[0].set_xlim(0, t.max())
ax[0].legend(loc='lower left')
ax[0].xaxis.set_minor_locator(AutoMinorLocator(2))
ax[0].text(0.03, 0.955, '(a)', transform=ax[0].transAxes, va='top', ha='left', fontsize=8)

ax[1].semilogy(t, np.maximum(resid, 1e-16), '-', color=BLUE, lw=1.2)
ax[1].axhline(err, ls=':', lw=0.8, color=GREY)
ax[1].set_xlabel(r'normalized time $\Omega t$')
ax[1].set_ylabel(r'$\left|\,|u|^{2}-|v|^{2}-e^{-2\alpha\Omega t}\right|$')
ax[1].set_xlim(0, t.max())
ax[1].set_ylim(1e-13, 1e-7)
ax[1].xaxis.set_minor_locator(AutoMinorLocator(2))
ax[1].text(0.03, 0.955, '(b)', transform=ax[1].transAxes, va='top', ha='left', fontsize=8)
ax[1].text(0.97, 0.06, rf'max $= {err:.1e}$', transform=ax[1].transAxes,
           ha='right', va='bottom', fontsize=7, color=GREY)

fig.tight_layout()
fig.savefig('figs/FigS1_norm_diagnostic.pdf')
fig.savefig('figs/FigS1_norm_diagnostic.png', dpi=600)
print(f'final norm  = {norm[-1]:.10f}   analytic = {ideal[-1]:.10f}')
print(f'max |deviation| = {err:.3e}')
