"""
=============================================================================
CORRECTED-PROTOCOL RECOMPUTATION OF TABLE 2 (Regimes I-IV), FOR COLAB
v4 -- LIVE PROGRESS + FOCUSED COMPUTE FOR THE LONG REGIMES
=============================================================================
Two changes from v3, both about making a long (many-hour) run practical and
verifiable rather than about the physics, which is unchanged:

1. LIVE PROGRESS. mcsolve's built-in progress bar (options={"progress_bar":
   "text"}) turns out to work fine together with options={"map": "parallel"}
   -- it prints a percentage/run-time/ETA line as each trajectory in the
   current batch finishes, not just once the whole batch is done. On a
   batch that takes 25-30 minutes, this means you see a new line every few
   minutes instead of sitting in front of a cell with no output. This does
   not change any number, only what you see while it runs.

2. FOCUSED COMPUTE. Only phi_d = 0 is needed for the P0+P1/mechanism
   question (Regime II's pair-phase sigma = 29.9 deg is already archived
   and independently reproduced for Regimes I and III, and the paper's own
   time-translation argument says the late-time occupation should not
   depend on phi_d for a periodic drive) -- so PHASES_TO_RUN below is set
   to [0.0] only for the large-N regimes (II, IV). This is a 5x reduction
   in total compute for the same statistical precision on P0+P1. Regimes I
   and III (already fully verified) are unaffected -- they still use exact
   mesolve and don't consume the long compute budget at all.

BATCH_SIZE is also lowered to 2 (from 4) for Regimes II/IV: each checkpoint
then lands roughly twice as often, so a Colab disconnect loses less work,
and you get a batch-completion line roughly every 12-16 minutes on top of
the live per-trajectory progress within each batch.

REALISTIC TARGET FOR REGIME II
--------------------------------
The first 8 trajectories (2 batches of 4) at kappa*t=3 gave P0+P1 = 0.0119
and 0.0795 -- a factor of 6.7x apart, current combined estimate
P0+P1 = 0.046 with a huge relative uncertainty. Standard error scales as
1/sqrt(n_traj), so to shrink the ~50% relative error on the current 8-
trajectory estimate down to roughly +/-20% needs on the order of 50-60
total trajectories. At the observed ~1770s per batch of 4 (measured
wall-clock; parallelization across 2 cores gave less benefit than hoped,
likely process-pool overhead), 56 trajectories is about 14 batches ~=
6.9 hours -- within your stated 10-15 hour budget, with checkpoints (and
now live progress) throughout. Set TOTAL_TRAJ = 56 below and just let it
run; raise it further later if the spread is still too wide.

REGIME IV
----------
N ~ 550 (vs. 220 for Regime II) will cost substantially more per
trajectory -- expect this to need a separate, longer session. Start it
only after Regime II has a stable answer, with a small TOTAL_TRAJ (e.g. 6)
first just to measure the actual per-trajectory time on your machine
before committing to a long run.

HOW TO RUN
-----------
1. !pip install qutip -q      (separate cell, already done)
2. Set REGIME = "II", make sure TOTAL_TRAJ = 56 (or your chosen target).
3. Run this cell and leave it. You should see progress-bar lines within
   a few minutes, and a batch-completion line roughly every 12-16 minutes.
   If you see NEITHER for more than ~20 minutes, something is actually
   stuck (rare, but possible) -- interrupt and re-run; already-finished
   batches are reloaded from checkpoints, so you lose at most one
   in-progress batch.
4. When done (or when you want to check progress so far), the printed
   running P0+P1 and cross-batch spread after phi_d=0.0000 is the number
   to report; re-run with a higher TOTAL_TRAJ any time to tighten it.
=============================================================================
"""

import json
import os
import time
from pathlib import Path

import numpy as np
from qutip import destroy, thermal_dm, mesolve, mcsolve, basis

# ---------------------------------------------------------------------------
# CONFIG -- edit these
# ---------------------------------------------------------------------------
REGIME = "II"                                    # "I", "II", "III", or "IV"
CHECKPOINT_DIR = Path("checkpoints_regime_recompute_v4")
TOTAL_TRAJ = 56           # target total trajectories for phi_d=0 (raise and re-run to add more)
BATCH_SIZE = 2            # trajectories requested per mcsolve call
MESOLVE_N_CUTOFF = 100    # N <= this: exact mesolve (Regimes I, III); N > this: mcsolve (II, IV)

# Phases to compute. Regimes I and III (exact, cheap) still get all five,
# reproducing the archived sigma independently. Regimes II and IV (expensive,
# trajectory-based) compute only phi_d=0, which is enough for P0+P1; sigma
# for these two is taken from the already-archived five-phase campaign.
FULL_PHASES = [0.0, np.pi / 4, np.pi / 2, 3 * np.pi / 4, np.pi]
FOCUSED_PHASES = [0.0]

print(f"CPU cores visible to this process: {os.cpu_count()}")

# ---------------------------------------------------------------------------
# PHYSICAL CONSTANTS AND MODEL (unchanged from v2/v3)
# ---------------------------------------------------------------------------
HBAR = 1.054571817e-34
KB = 1.380649e-23

OMEGA = 1.0
U_AUDIT = 0.55
ETA = 1.2
ALPHA = 1.0e-3
KAPPA = 2.0 * ALPHA * OMEGA

KAPPA_T_TARGET = 3.0
TMAX = KAPPA_T_TARGET / KAPPA

REGIME_TABLE = {
    "I":   dict(freq_hz=50e9,  T_K=4.0,   N=25),
    "II":  dict(freq_hz=50e9,  T_K=77.0,  N=220),
    "III": dict(freq_hz=6e12,  T_K=310.0, N=25),
    "IV":  dict(freq_hz=50e9,  T_K=310.0, N=550),
}

MESOLVE_OPTS = {
    "method": "adams", "nsteps": 1_000_000, "atol": 1e-8, "rtol": 1e-6,
    "progress_bar": False, "store_final_state": True,
}
MCSOLVE_OPTS = {
    "nsteps": 500_000, "atol": 1e-7, "rtol": 1e-5,
    "progress_bar": "text",   # <-- live per-trajectory feedback, new in v4
    "store_final_state": True,
    "map": "parallel" if os.cpu_count() and os.cpu_count() > 1 else "serial",
}


def thermal_occupation(freq_hz: float, T_K: float) -> float:
    if T_K <= 0.0:
        return 0.0
    x = HBAR * 2.0 * np.pi * freq_hz / (KB * T_K)
    return 1.0 / np.expm1(x)


def thermal_tail(n_th: float, N: int) -> float:
    if n_th <= 0:
        return 0.0
    return (n_th / (1.0 + n_th)) ** N


class PairCoeff:
    """Picklable callable (needed for options={'map': 'parallel'})."""
    def __init__(self, phi_d: float):
        self.phi_d = phi_d

    def __call__(self, t, args=None):
        return 0.5 * ETA * OMEGA * np.sin(2.0 * OMEGA * t + self.phi_d)


def build_operators(N: int):
    a = destroy(N)
    ad = a.dag()
    n_op = ad * a
    H0 = OMEGA * n_op + 0.5 * U_AUDIT * OMEGA * ad * ad * a * a
    pair = ad * ad + a * a
    return a, ad, n_op, H0, pair


def collapse_operators(a, ad, n_th: float):
    c_ops = [np.sqrt(KAPPA * (n_th + 1.0)) * a]
    if n_th > 0.0:
        c_ops.append(np.sqrt(KAPPA * n_th) * ad)
    return c_ops


def sample_thermal_fock(N: int, n_th: float, rng) -> int:
    x = n_th / (1.0 + n_th) if n_th > 0 else 0.0
    probs = (1.0 - x) * x ** np.arange(N)
    probs = probs / probs.sum()
    return int(rng.choice(N, p=probs))


# --------------------------- exact path (small N) --------------------------

def run_exact(N: int, n_th: float, phi_d: float, tmax: float):
    a, ad, n_op, H0, pair = build_operators(N)
    c_ops = collapse_operators(a, ad, n_th)
    rho0 = thermal_dm(N, n_th)
    tlist = np.linspace(0.0, tmax, max(50, int(tmax * 2)))
    t0 = time.time()
    result = mesolve([H0, [pair, PairCoeff(phi_d)]], rho0, tlist,
                      c_ops=c_ops, e_ops=[n_op, a * a], options=MESOLVE_OPTS)
    runtime = time.time() - t0
    pops = np.real(np.diag(result.final_state.full()))
    pops = np.maximum(pops, 0.0); pops /= pops.sum()
    mean_n = np.real(np.asarray(result.expect[0]))
    return {
        "P0": float(pops[0]), "P1": float(pops[1]),
        "P0_plus_P1": float(pops[0] + pops[1]),
        "mean_n_late": float(mean_n[len(mean_n) * 2 // 3:].mean()),
        "n_traj": 1, "method": "mesolve", "runtime_s": runtime,
    }


# ---------------------- batched, natively-averaged mcsolve -----------------

def run_one_batch(N: int, n_th: float, phi_d: float, tmax: float,
                   n_traj: int, seed: int):
    a, ad, n_op, H0, pair = build_operators(N)
    c_ops = collapse_operators(a, ad, n_th)
    tlist = np.linspace(0.0, tmax, max(30, int(tmax / 25)))
    rng = np.random.default_rng(seed)
    n0 = sample_thermal_fock(N, n_th, rng)
    t0 = time.time()
    result = mcsolve([H0, [pair, PairCoeff(phi_d)]], basis(N, n0), tlist,
                      c_ops=c_ops, e_ops=[n_op, a * a], ntraj=n_traj,
                      seeds=seed, options=MCSOLVE_OPTS)
    runtime = time.time() - t0

    avg_final = result.average_final_state
    pops = np.real(np.diag(avg_final.full()))
    pops = np.maximum(pops, 0.0)
    s = pops.sum()
    if s > 0:
        pops /= s
    mean_n = np.real(np.asarray(result.average_expect[0]))

    return {
        "n0_sampled": n0, "n_traj": n_traj, "runtime_s": runtime,
        "P0": float(pops[0]), "P1": float(pops[1]),
        "P0_plus_P1": float(pops[0] + pops[1]),
        "mean_n_late": float(mean_n[len(mean_n) * 2 // 3:].mean()),
    }


def run_trajectories_for_phase(N: int, n_th: float, phi_d: float, tmax: float,
                                total_traj: int, batch_size: int, tag: str):
    CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)
    batches = []
    n_have = 0
    batch_idx = 0
    t_start = time.time()
    while n_have < total_traj:
        batch_path = CHECKPOINT_DIR / f"{tag}_batch{batch_idx}.json"
        if batch_path.exists():
            with open(batch_path) as f:
                b = json.load(f)
            print(f"  [{tag}] batch {batch_idx} ({b['n_traj']} traj): loaded from checkpoint")
        else:
            this_size = min(batch_size, total_traj - n_have)
            print(f"  [{tag}] batch {batch_idx}: starting {this_size} "
                  f"traj (elapsed so far {time.time()-t_start:.0f}s) ...")
            b = run_one_batch(N, n_th, phi_d, tmax, this_size,
                               seed=abs(hash((tag, batch_idx))) % (2**31))
            with open(batch_path, "w") as f:
                json.dump(b, f)
            print(f"  [{tag}] batch {batch_idx} ({this_size} traj) done in "
                  f"{b['runtime_s']:.1f}s -> P0+P1={b['P0_plus_P1']:.4f}, "
                  f"<n>_late={b['mean_n_late']:.3f}")
        batches.append(b)
        n_have += b["n_traj"]
        batch_idx += 1

        # running combined estimate after every batch, so you can decide
        # to stop early if it has already stabilized
        w = np.array([bb["n_traj"] for bb in batches], dtype=float)
        p0_run = np.average([bb["P0"] for bb in batches], weights=w)
        p1_run = np.average([bb["P1"] for bb in batches], weights=w)
        p01_per_batch = np.array([bb["P0_plus_P1"] for bb in batches])
        spread = p01_per_batch.std() if len(batches) > 1 else float("nan")
        print(f"  [{tag}] running total: {int(w.sum())} traj, "
              f"P0+P1={p0_run+p1_run:.4f}, cross-batch spread={spread:.4f}, "
              f"elapsed {time.time()-t_start:.0f}s")

    w = np.array([b["n_traj"] for b in batches], dtype=float)
    p0 = np.average([b["P0"] for b in batches], weights=w)
    p1 = np.average([b["P1"] for b in batches], weights=w)
    mean_n = np.average([b["mean_n_late"] for b in batches], weights=w)
    p01_per_batch = np.array([b["P0_plus_P1"] for b in batches])

    return {
        "n_traj_total": int(w.sum()),
        "P0": float(p0), "P1": float(p1), "P0_plus_P1": float(p0 + p1),
        "mean_n_late": float(mean_n),
        "cross_batch_spread_P0_plus_P1": float(p01_per_batch.std()) if len(batches) > 1 else None,
        "method": "mcsolve",
    }


def main():
    cfg = REGIME_TABLE[REGIME]
    n_th = thermal_occupation(cfg["freq_hz"], cfg["T_K"])
    N = cfg["N"]
    tail = thermal_tail(n_th, N)
    use_mcsolve = N > MESOLVE_N_CUTOFF
    phases = FOCUSED_PHASES if use_mcsolve else FULL_PHASES

    print("=" * 79)
    print(f"REGIME {REGIME}: T={cfg['T_K']} K, f={cfg['freq_hz']/1e9:.3g} GHz, "
          f"n_th={n_th:.4f}, N={N}")
    print(f"thermal-only tail bound P(n>=N) = {tail:.2e}")
    print(f"Method: {'mcsolve, batches of ' + str(BATCH_SIZE) + f', target {TOTAL_TRAJ} traj, phi_d=0 only' if use_mcsolve else 'exact mesolve, all 5 phases'}")
    print(f"tmax = {TMAX:.1f} (normalized units), target kappa*tmax = {KAPPA_T_TARGET}")
    if use_mcsolve:
        print("NOTE: for Regimes II/IV only phi_d=0 is computed here (see docstring); "
              "sigma is taken from the already-archived five-phase campaign.")
    print("=" * 79)

    results = {}
    for i, phi_d in enumerate(phases):
        tag = f"regime{REGIME}_phi{i}"
        print(f"\n--- phi_d = {phi_d:.4f} rad ---")
        if use_mcsolve:
            results[i] = run_trajectories_for_phase(N, n_th, phi_d, TMAX,
                                                      TOTAL_TRAJ, BATCH_SIZE, tag)
        else:
            results[i] = run_exact(N, n_th, phi_d, TMAX)
        r = results[i]
        print(f"  -> P0={r['P0']:.4f} P1={r['P1']:.4f} P0+P1={r['P0_plus_P1']:.4f}"
              + (f"  (cross-batch spread={r['cross_batch_spread_P0_plus_P1']:.4f})"
                 if r.get("cross_batch_spread_P0_plus_P1") is not None else ""))

    with open(CHECKPOINT_DIR / f"regime{REGIME}_summary.json", "w") as f:
        json.dump({"regime": REGIME, "n_th": n_th, "N": N,
                    "thermal_tail_bound": tail,
                    "method": "mcsolve" if use_mcsolve else "mesolve",
                    "results_by_phase_index": results, "phases_rad": phases}, f, indent=2)
    print(f"\nSaved: {CHECKPOINT_DIR / f'regime{REGIME}_summary.json'}")
    print("\nRaise TOTAL_TRAJ and re-run this same cell to add more trajectories "
          "-- existing batches are reused, only new ones are computed.")


if __name__ == "__main__":
    main()
