"""
=============================================================================
CORRECTED-PROTOCOL RECOMPUTATION -- REGIME IV, v8 (PHYSICS-FIXED SEGMENTATION)
IMPORTANT v8 CORRECTIONS:
- v7 restarted the phase of the time-dependent resonant pump at t=0 in every
  checkpoint segment. v8 evaluates the pump at absolute trajectory time.
- v7 formed final Fock probabilities as real(psi)^2. v8 uses |psi|^2.
- v8 does NOT reuse v7 checkpoint/state/batch files.
- Steady-state Regime-IV sigma is OPTIONAL. The manuscript now reports the
  N=240 value only as a separately converged reset-transient diagnostic, so
  the default v8 run is a corrected P0+P1 revalidation (COMPUTE_SIGMA=False).
  Turn COMPUTE_SIGMA=True only if a thermal-start steady-state sigma is desired.
=============================================================================
NOW ALSO COMPUTES sigma (pair-phase circular std) AT N=550, ANSWERING
REFEREE M2 FOR REGIME IV (the archived sigma=40.7 deg used N=240, which
the manuscript already flags as failing the thermal-tail convergence test
at n_th=128.7: 15.7% of the equilibrium weight is omitted). This script
reuses the exact same trajectories already needed for P0+P1, adding no
extra compute beyond what v6 already required -- it was simply not
extracting sigma from them.
=============================================================================
Builds on v6 (segmented, resumable execution -- see that file's history
for the disconnect-survival and solver-tolerance-fallback rationale,
unchanged here). NEW in v7:

- Each segment's samples now carry their absolute (trajectory-start-
  relative) time, correctly offset even through the recursive segment-
  halving fallback.
- Each trajectory's full <n>(t) and <aa>(t) = pair_re(t) + i*pair_im(t)
  series (not just their late-time means) are kept in batch{i}.json.
- After all trajectories for a phase are done, compute_sigma_deg()
  ensemble-averages <aa>(t) across trajectories at each common time
  sample, forms the pair-phase Phi_pair(t) = arg(<aa>(t)) + 2*Omega*t
  (Omega=1 here), and returns the circular standard deviation of
  Phi_pair over the late-time window (last third of the run) -- exactly
  the same quantity, computed the same way, as the sigma already
  reported in Table 2 for Regimes I-III. This makes the new sigma
  directly comparable to the archived N=240 value for Regime IV.

IMPORTANT -- DO NOT REUSE v7 OR EARLIER CHECKPOINTS. batch{i}.json files
written by v5/v6 do not contain the t/pair_re/pair_im series this version
needs. If you point CHECKPOINT_DIR at a folder with old-format
batch{i}.json files, this script will still compute P0+P1 from them (via
"loaded from checkpoint"), but sigma_deg will come back as None with an
explanatory message, since the required series simply is not there to
recompute after the fact. To get sigma, either delete old batch{i}.json
files and let this script recompute those trajectories from scratch, or
point CHECKPOINT_DIR at a new folder.

Previous history (v6, unchanged): each trajectory is run in SEGMENTS of
kappa*t = SEGMENT_KAPPA_T (default 0.1, i.e. 30 segments to cover the
full kappa*t=3 target). After every segment, the exact quantum state is
checkpointed to Drive, so a disconnect loses at most one segment (~1-2
minutes at this N), not a
whole trajectory.

HOW THE STATE IS CHECKPOINTED
-------------------------------
mcsolve's final_state for ntraj=1 is returned as a density matrix (a rank-1
projector |psi><psi|, not a ket), even though the trajectory is a pure
state. To resume the SAME trajectory, this script extracts the pure state
via eigendecomposition (the eigenvector with eigenvalue ~1 -- verified
locally to reproduce the original density matrix exactly to numerical
precision) and saves that ket. Resuming from this ket and running mcsolve
onward is statistically identical to having continued the original
trajectory without interruption: a Markovian quantum trajectory's future
evolution depends only on its current state, not on the history/random
seed that produced it, so restarting with fresh randomness from the
correct state is unbiased.

Per-trajectory files under CHECKPOINT_DIR:
  {tag}_traj{i}_state.qu       -- current ket (qutip qsave format)
  {tag}_traj{i}_progress.json  -- segments done, accumulated e_ops arrays
Once a trajectory's last segment finishes, its result is folded into the
same batch{i}.json format used by v4/v5, so the outer batch-averaging
logic (running P0+P1, cross-batch spread, etc.) is unchanged.

EVERYTHING ELSE (protocol, thermal Fock sampling, native trajectory
averaging across batches, live progress bar) is unchanged from v5 --
see that file's docstring for the full method writeup.

HOW TO RUN
-----------
1. !pip install qutip -q
2. Mount Drive; make sure /content/drive/MyDrive/regime4_checkpoints exists.
3. Run this cell. You should now see progress roughly every 1-2 minutes
   (one segment), not once per 65 minutes. If a disconnect happens, just
   redo steps 1-2 and re-run this cell -- it resumes from the last
   completed SEGMENT, not the last completed trajectory.
4. Existing v5 batch{i}.json files (already-completed trajectories, if any)
   are reused as-is; this script only changes how NEW trajectories are
   computed.
=============================================================================
"""

import json
import os
import time
from pathlib import Path

import numpy as np
from qutip import destroy, thermal_dm, mesolve, mcsolve, basis, qsave, qload

# ---------------------------------------------------------------------------
# CONFIG -- edit these
# ---------------------------------------------------------------------------
REGIME = "IV"
CHECKPOINT_DIR = Path("/content/drive/MyDrive/regime4_checkpoints_v8_absphase")  # NEW folder --
                          # deliberately different from v6's regime4_checkpoints,
                          # since old batch{i}.json files there lack the
                          # t/pair_re/pair_im series this version needs for sigma
TOTAL_TRAJ = 8
COMPUTE_SIGMA = False  # default: only revalidate P0+P1; see module note
PHASE_SAMPLES_PER_PUMP = 8
SEGMENT_KAPPA_T = 0.1     # lowered from 0.5 after testing: kappa*t=0.5 (tmax=250)
                          # triggered QuTiP's "could not find the collapse time"
                          # error at N=550 for some states; kappa*t=0.1 (tmax=50)
                          # was verified to succeed on the same state/seed that
                          # failed at 0.5. This also means checkpoints land
                          # roughly every ~80s of compute, not every ~12 min.
MIN_SEGMENT_KAPPA_T = 0.01  # floor for the auto-retry-with-shorter-segment
                            # fallback below, in case 0.1 itself occasionally fails
MESOLVE_N_CUTOFF = 100

print(f"CPU cores visible to this process: {os.cpu_count()}")

# ---------------------------------------------------------------------------
# PHYSICAL CONSTANTS AND MODEL (unchanged from v4/v5)
# ---------------------------------------------------------------------------
HBAR = 1.054571817e-34
KB = 1.380649e-23

OMEGA = 1.0
U_AUDIT = 0.55
ETA = 1.2
ALPHA = 1.0e-3
KAPPA = 2.0 * ALPHA * OMEGA

KAPPA_T_TARGET = 3.0
TMAX = KAPPA_T_TARGET / KAPPA
SEGMENT_TIME = SEGMENT_KAPPA_T / KAPPA   # normalized time per segment

REGIME_TABLE = {
    "I":   dict(freq_hz=50e9,  T_K=4.0,   N=25),
    "II":  dict(freq_hz=50e9,  T_K=77.0,  N=220),
    "III": dict(freq_hz=6e12,  T_K=310.0, N=25),
    "IV":  dict(freq_hz=50e9,  T_K=310.0, N=550),
}

MESOLVE_OPTS = {
    "method": "adams", "nsteps": 1_000_000, "atol": 1e-8, "rtol": 1e-6,
    "progress_bar": False, "store_final_state": True,
}
MCSOLVE_OPTS = {
    "nsteps": 500_000, "atol": 1e-7, "rtol": 1e-5,
    "progress_bar": "text",
    "store_final_state": True,
    "map": "serial",
    # Collapse-time (quantum jump) root-finding options. QuTiP's default
    # norm_steps is small and can run out of bisection iterations at large
    # N before it brackets the jump time tightly enough, raising "Could not
    # find the collapse time within desired tolerance" -- this was hit at
    # N=550 even after halving the segment length repeatedly, which points
    # to a tolerance problem, not a step-size problem. Loosened here per the
    # error message's own suggestion.
    "norm_steps": 200,
    "norm_tol": 1e-3,
    "norm_t_tol": 1e-6,
}
# Used once, only if a segment still fails even with the options above --
# substantially more permissive, at the cost of jump-time precision.
MCSOLVE_OPTS_FALLBACK = dict(MCSOLVE_OPTS)
MCSOLVE_OPTS_FALLBACK.update({"norm_steps": 2000, "norm_tol": 1e-2, "norm_t_tol": 1e-4})


def thermal_occupation(freq_hz: float, T_K: float) -> float:
    if T_K <= 0.0:
        return 0.0
    x = HBAR * 2.0 * np.pi * freq_hz / (KB * T_K)
    return 1.0 / np.expm1(x)


def thermal_tail(n_th: float, N: int) -> float:
    if n_th <= 0:
        return 0.0
    return (n_th / (1.0 + n_th)) ** N


class PairCoeff:
    def __init__(self, phi_d: float, t_origin: float = 0.0):
        self.phi_d = phi_d
        self.t_origin = float(t_origin)

    def __call__(self, t, args=None):
        # CRITICAL: t supplied by mcsolve is local to the current segment.
        # The physical resonant pump must remain continuous across checkpoints.
        t_abs = t + self.t_origin
        return 0.5 * ETA * OMEGA * np.sin(2.0 * OMEGA * t_abs + self.phi_d)


def build_operators(N: int):
    a = destroy(N)
    ad = a.dag()
    n_op = ad * a
    H0 = OMEGA * n_op + 0.5 * U_AUDIT * OMEGA * ad * ad * a * a
    pair = ad * ad + a * a
    return a, ad, n_op, H0, pair


def collapse_operators(a, ad, n_th: float):
    c_ops = [np.sqrt(KAPPA * (n_th + 1.0)) * a]
    if n_th > 0.0:
        c_ops.append(np.sqrt(KAPPA * n_th) * ad)
    return c_ops


def sample_thermal_fock(N: int, n_th: float, rng) -> int:
    x = n_th / (1.0 + n_th) if n_th > 0 else 0.0
    probs = (1.0 - x) * x ** np.arange(N)
    probs = probs / probs.sum()
    return int(rng.choice(N, p=probs))


def solve_segment_robust(H0, pair, phi_d, psi, c_ops, n_op, a, seg_time, seed,
                          depth=0, t_offset=0.0):
    """
    Run mcsolve for one segment of length seg_time starting from psi.
    QuTiP's stochastic collapse-time bisection occasionally fails to
    converge ("Could not find the collapse time within desired tolerance")
    on long single calls at large N; this was verified locally to be tied
    to segment length, not to the specific state or random seed (the same
    state/seed that failed at kappa*t=0.5 succeeded at kappa*t=0.1). As a
    safety net beyond the lowered default segment length, if a segment
    still fails, this recursively retries it as two half-length segments
    (down to MIN_SEGMENT_KAPPA_T), which costs a little overhead only on
    the rare segment that needs it, rather than failing the whole run.
    t_offset is the absolute (trajectory-start-relative) time at the start
    of this segment. It is used BOTH to keep the resonant pump phase continuous
    across segments and to return absolute sample times for phase analysis.
    Returns (mean_n_values, pair_re_values, pair_im_values, t_values, final_ket).
    """
    if COMPUTE_SIGMA:
        pump_period = np.pi / OMEGA
        dt_out = pump_period / PHASE_SAMPLES_PER_PUMP
        n_pts = max(3, int(np.ceil(seg_time / dt_out)) + 1)
        e_ops = [n_op, a * a]
    else:
        # Final P0+P1 is obtained from the final ket; a light output grid is
        # sufficient for the auxiliary late-time <n> estimate.
        n_pts = max(5, int(seg_time / 25))
        e_ops = [n_op]
    tlist = np.linspace(0.0, seg_time, n_pts)

    def _try(options):
        result = mcsolve([H0, [pair, PairCoeff(phi_d, t_origin=t_offset)]], psi, tlist,
                          c_ops=c_ops, e_ops=e_ops, ntraj=1,
                          seeds=int(seed), options=options)
        psi_next = extract_ket(result.final_state, psi.shape[0])
        mean_n = np.real(np.asarray(result.expect[0])).tolist()
        if COMPUTE_SIGMA:
            pair_c = np.asarray(result.expect[1], dtype=complex)
            pair_re = pair_c.real.tolist()
            pair_im = pair_c.imag.tolist()
        else:
            pair_re = []
            pair_im = []
        t_vals = (tlist + t_offset).tolist()
        return mean_n, pair_re, pair_im, t_vals, psi_next

    try:
        return _try(MCSOLVE_OPTS)
    except RuntimeError as e:
        if "collapse time" not in str(e):
            raise
        # Tier 1: same segment length, much more permissive jump-time
        # tolerance. This alone resolved the failure in local testing.
        try:
            print(f"    [retry] segment of kappa*t={seg_time*KAPPA:.3f} hit the "
                  f"collapse-time tolerance; retrying same length with "
                  f"looser norm tolerance")
            return _try(MCSOLVE_OPTS_FALLBACK)
        except RuntimeError as e2:
            if "collapse time" not in str(e2):
                raise
            # Tier 2: still failing -- fall back to halving the segment,
            # which at least changes the numerics enough to sometimes help,
            # even though tolerance (not segment length) was the root cause.
            half_kappa_t = (seg_time * KAPPA) / 2.0
            if half_kappa_t < MIN_SEGMENT_KAPPA_T:
                raise
            print(f"    [retry] looser tolerance still failed; retrying as "
                  f"two halves of kappa*t={half_kappa_t:.3f} each")
            mn1, pr1, pi1, t1, psi_mid = solve_segment_robust(
                H0, pair, phi_d, psi, c_ops, n_op, a, seg_time / 2.0, seed * 2,
                depth + 1, t_offset=t_offset)
            mn2, pr2, pi2, t2, psi_final = solve_segment_robust(
                H0, pair, phi_d, psi_mid, c_ops, n_op, a, seg_time / 2.0, seed * 2 + 1,
                depth + 1, t_offset=t_offset + seg_time / 2.0)
            return mn1 + mn2, pr1 + pr2, pi1 + pi2, t1 + t2, psi_final


def extract_ket(final_state, N: int):
    """Return a normalized ket from mcsolve's final state.
    QuTiP versions may return either a ket directly or a rank-1 projector."""
    if getattr(final_state, "isket", False):
        return final_state.unit()
    if getattr(final_state, "isoper", False):
        evals, ekets = final_state.eigenstates(eigvals=1, sort="high")
        return ekets[0].unit()
    raise TypeError(f"Unsupported mcsolve final_state type: {getattr(final_state, 'type', type(final_state))}")


# --------------------------- exact path (small N, unchanged) ---------------

def run_exact(N: int, n_th: float, phi_d: float, tmax: float):
    a, ad, n_op, H0, pair = build_operators(N)
    c_ops = collapse_operators(a, ad, n_th)
    rho0 = thermal_dm(N, n_th)
    tlist = np.linspace(0.0, tmax, max(50, int(tmax * 2)))
    t0 = time.time()
    result = mesolve([H0, [pair, PairCoeff(phi_d, t_origin=0.0)]], rho0, tlist,
                      c_ops=c_ops, e_ops=[n_op, a * a], options=MESOLVE_OPTS)
    runtime = time.time() - t0
    pops = np.real(np.diag(result.final_state.full()))
    pops = np.maximum(pops, 0.0); pops /= pops.sum()
    mean_n = np.real(np.asarray(result.expect[0]))
    return {
        "P0": float(pops[0]), "P1": float(pops[1]),
        "P0_plus_P1": float(pops[0] + pops[1]),
        "mean_n_late": float(mean_n[len(mean_n) * 2 // 3:].mean()),
        "n_traj": 1, "method": "mesolve", "runtime_s": runtime,
    }


# ---------------------- segmented single-trajectory mcsolve ----------------

def run_one_trajectory_segmented(N: int, n_th: float, phi_d: float,
                                  tmax_total: float, traj_tag: str, seed: int):
    """
    Run ONE trajectory in SEGMENT_TIME-sized chunks, checkpointing the exact
    quantum state (as a ket) and the accumulated e_ops history after every
    segment. Safe to interrupt and resume at segment granularity.
    """
    CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)
    state_path = CHECKPOINT_DIR / f"{traj_tag}_state"
    progress_path = CHECKPOINT_DIR / f"{traj_tag}_progress.json"

    a, ad, n_op, H0, pair = build_operators(N)
    c_ops = collapse_operators(a, ad, n_th)
    n_segments = int(np.ceil(tmax_total / SEGMENT_TIME))

    state_file = Path(str(state_path) + ".qu")
    if progress_path.exists() and state_file.exists():
        with open(progress_path) as f:
            progress = json.load(f)
        psi = qload(str(state_path))
        segs_done = progress["segs_done"]
        print(f"  [{traj_tag}] resuming from segment {segs_done}/{n_segments}")
    else:
        rng = np.random.default_rng(seed)
        n0 = sample_thermal_fock(N, n_th, rng)
        psi = basis(N, n0)
        progress = {"segs_done": 0, "n0": n0, "mean_n": [], "pair_re": [], "pair_im": [], "t": []}
        segs_done = 0

    t_traj_start = time.time()
    for seg in range(segs_done, n_segments):
        this_len = min(SEGMENT_TIME, tmax_total - seg * SEGMENT_TIME)
        seg_t_offset = seg * SEGMENT_TIME

        t0 = time.time()
        mean_n_seg, pair_re_seg, pair_im_seg, t_seg, psi = solve_segment_robust(
            H0, pair, phi_d, psi, c_ops, n_op, a, this_len, int(seed + seg),
            t_offset=seg_t_offset)
        seg_runtime = time.time() - t0

        progress["mean_n"].extend(mean_n_seg)
        progress["pair_re"].extend(pair_re_seg)
        progress["pair_im"].extend(pair_im_seg)
        progress["t"].extend(t_seg)
        progress["segs_done"] = seg + 1

        qsave(psi, str(state_path))
        with open(progress_path, "w") as f:
            json.dump(progress, f)

        print(f"  [{traj_tag}] segment {seg+1}/{n_segments} done in "
              f"{seg_runtime:.1f}s (kappa*t so far = {(seg+1)*SEGMENT_KAPPA_T:.2f}, "
              f"traj elapsed {time.time()-t_traj_start:.0f}s)")

    mean_n_full = np.array(progress["mean_n"])
    mean_n_late = mean_n_full[len(mean_n_full) * 2 // 3:]

    final_probs = np.abs(psi.full().ravel()) ** 2
    final_probs = np.maximum(final_probs, 0.0)
    s = final_probs.sum()
    if s > 0:
        final_probs /= s

    out = {
        "n0_sampled": progress["n0"], "n_traj": 1,
        "P0": float(final_probs[0]), "P1": float(final_probs[1]),
        "P0_plus_P1": float(final_probs[0] + final_probs[1]),
        "mean_n_late": float(mean_n_late.mean()),
        # Full time series, needed to compute the ensemble-averaged pair-phase
        # circular standard deviation (sigma) across trajectories -- this is
        # the addition that lets sigma be independently checked at N=550,
        # reusing the same trajectories computed for P0+P1 rather than
        # requiring a separate campaign (Referee M2 follow-up).
        "t": progress["t"], "pair_re": progress["pair_re"], "pair_im": progress["pair_im"],
    }

    try:
        state_file.unlink(missing_ok=True)
        progress_path.unlink(missing_ok=True)
    except Exception:
        pass

    return out


def _unique_sorted_series(t, z):
    """Sort one trajectory's samples and average duplicate time stamps."""
    t = np.asarray(t, dtype=float)
    z = np.asarray(z, dtype=complex)
    order = np.argsort(t)
    t = t[order]
    z = z[order]
    uniq, inv = np.unique(t, return_inverse=True)
    if len(uniq) == len(t):
        return t, z
    acc = np.zeros(len(uniq), dtype=complex)
    cnt = np.zeros(len(uniq), dtype=float)
    np.add.at(acc, inv, z)
    np.add.at(cnt, inv, 1.0)
    return uniq, acc / cnt


def compute_sigma_deg(batches, tmax_total):
    """
    Ensemble-average <aa>(t) after interpolating every trajectory onto one
    common ABSOLUTE-time grid. This remains valid if recursive retry splitting
    created different native output grids in different trajectories.
    """
    if not COMPUTE_SIGMA:
        return None
    if any(("t" not in b or "pair_re" not in b or "pair_im" not in b) for b in batches):
        return None
    if any(len(b["pair_re"]) == 0 for b in batches):
        return None

    pump_period = np.pi / OMEGA
    dt = pump_period / PHASE_SAMPLES_PER_PUMP
    common_t = np.arange(0.0, tmax_total + 0.5 * dt, dt)

    interp_pairs = []
    for b in batches:
        t = np.asarray(b["t"], dtype=float)
        z = np.asarray(b["pair_re"], dtype=float) + 1j * np.asarray(b["pair_im"], dtype=float)
        t, z = _unique_sorted_series(t, z)
        re_i = np.interp(common_t, t, z.real)
        im_i = np.interp(common_t, t, z.imag)
        interp_pairs.append(re_i + 1j * im_i)

    ens_pair = np.mean(np.asarray(interp_pairs), axis=0)
    phi_pair = np.angle(ens_pair) + 2.0 * OMEGA * common_t
    late_mask = common_t >= (tmax_total * 2.0 / 3.0)
    theta = phi_pair[late_mask]
    if len(theta) < 2:
        return None
    R = np.abs(np.mean(np.exp(1j * theta)))
    R = np.clip(R, 1e-15, 1.0 - 1e-12)
    return float(np.degrees(np.sqrt(-2.0 * np.log(R))))

def run_trajectories_for_phase(N: int, n_th: float, phi_d: float, tmax: float,
                                total_traj: int, tag: str):
    CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)
    batches = []
    for i in range(total_traj):
        batch_path = CHECKPOINT_DIR / f"{tag}_batch{i}.json"
        if batch_path.exists():
            with open(batch_path) as f:
                b = json.load(f)
            print(f"  [{tag}] trajectory {i} (1 traj): loaded from checkpoint")
        else:
            traj_tag = f"{tag}_traj{i}"
            b = run_one_trajectory_segmented(
                N, n_th, phi_d, tmax, traj_tag,
                seed=abs(hash((tag, i))) % (2**31),
            )
            with open(batch_path, "w") as f:
                json.dump(b, f)
            print(f"  [{tag}] trajectory {i} done -> P0+P1={b['P0_plus_P1']:.4f}, "
                  f"<n>_late={b['mean_n_late']:.3f}")
        batches.append(b)

        w = np.array([bb["n_traj"] for bb in batches], dtype=float)
        p0_run = np.average([bb["P0"] for bb in batches], weights=w)
        p1_run = np.average([bb["P1"] for bb in batches], weights=w)
        p01_per = np.array([bb["P0_plus_P1"] for bb in batches])
        spread = p01_per.std() if len(batches) > 1 else float("nan")
        print(f"  [{tag}] running total: {int(w.sum())} traj, "
              f"P0+P1={p0_run+p1_run:.4f}, cross-batch spread={spread:.4f}")

    w = np.array([b["n_traj"] for b in batches], dtype=float)
    p0 = np.average([b["P0"] for b in batches], weights=w)
    p1 = np.average([b["P1"] for b in batches], weights=w)
    mean_n = np.average([b["mean_n_late"] for b in batches], weights=w)
    p01_per = np.array([b["P0_plus_P1"] for b in batches])
    sigma_deg = compute_sigma_deg(batches, tmax)
    if sigma_deg is not None:
        print(f"  [{tag}] sigma (circular std, ensemble over {int(w.sum())} "
              f"trajectories) = {sigma_deg:.2f} deg")
    else:
        print(f"  [{tag}] sigma could not be computed -- one or more "
              f"batch{{i}}.json files predate the t/pair_re/pair_im fields "
              f"(delete them and re-run to include sigma)")

    return {
        "n_traj_total": int(w.sum()),
        "P0": float(p0), "P1": float(p1), "P0_plus_P1": float(p0 + p1),
        "mean_n_late": float(mean_n),
        "cross_batch_spread_P0_plus_P1": float(p01_per.std()) if len(batches) > 1 else None,
        "sigma_deg": sigma_deg,
        "method": "mcsolve-segmented",
    }


def main():
    cfg = REGIME_TABLE[REGIME]
    n_th = thermal_occupation(cfg["freq_hz"], cfg["T_K"])
    N = cfg["N"]
    tail = thermal_tail(n_th, N)
    use_mcsolve = N > MESOLVE_N_CUTOFF

    n_segments = int(np.ceil(TMAX / SEGMENT_TIME))
    print("=" * 79)
    print(f"REGIME {REGIME}: T={cfg['T_K']} K, f={cfg['freq_hz']/1e9:.3g} GHz, "
          f"n_th={n_th:.4f}, N={N}")
    print(f"thermal-only tail bound P(n>=N) = {tail:.2e}")
    print(f"COMPUTE_SIGMA = {COMPUTE_SIGMA}")
    print(f"Method: {'segmented mcsolve (' + str(n_segments) + ' segments/trajectory), target ' + str(TOTAL_TRAJ) + ' traj, phi_d=0 only' if use_mcsolve else 'exact mesolve, all 5 phases'}")
    print(f"tmax = {TMAX:.1f} (normalized units), target kappa*tmax = {KAPPA_T_TARGET}, "
          f"segment kappa*t = {SEGMENT_KAPPA_T}")
    print("=" * 79)

    tag = f"regime{REGIME}_phi0"
    print(f"\n--- phi_d = 0.0000 rad ---")
    if use_mcsolve:
        result = run_trajectories_for_phase(N, n_th, 0.0, TMAX, TOTAL_TRAJ, tag)
    else:
        result = run_exact(N, n_th, 0.0, TMAX)

    print(f"  -> P0={result['P0']:.4f} P1={result['P1']:.4f} "
          f"P0+P1={result['P0_plus_P1']:.4f}"
          + (f"  (cross-batch spread={result['cross_batch_spread_P0_plus_P1']:.4f})"
             if result.get("cross_batch_spread_P0_plus_P1") is not None else "")
          + (f"  sigma={result['sigma_deg']:.2f} deg"
             if result.get("sigma_deg") is not None else ""))

    with open(CHECKPOINT_DIR / f"regime{REGIME}_summary.json", "w") as f:
        json.dump({"regime": REGIME, "n_th": n_th, "N": N,
                    "thermal_tail_bound": tail, "result": result}, f, indent=2)
    print(f"\nSaved: {CHECKPOINT_DIR / f'regime{REGIME}_summary.json'}")


if __name__ == "__main__":
    main()