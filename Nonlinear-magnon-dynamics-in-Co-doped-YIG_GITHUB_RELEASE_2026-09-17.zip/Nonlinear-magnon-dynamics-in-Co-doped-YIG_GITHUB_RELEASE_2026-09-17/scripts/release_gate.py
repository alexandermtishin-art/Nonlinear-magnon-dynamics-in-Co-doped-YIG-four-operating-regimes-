#!/usr/bin/env python3
"""Public-release text gate.

Scans public-facing markdown/text files for workflow-status language that
must not appear in a release. Scientific uses of words inside Python code
are intentionally not scanned here.
"""
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
BANNED=[
    'pending','ongoing','in progress','re-verification','will be inserted',
    'deferred until','calculation is running','calculation is in progress'
]
EXTS={'.md','.txt','.cff'}
ALLOW={'MANIFEST.txt','SHA256SUMS.txt'}
hits=[]
for p in ROOT.rglob('*'):
    if not p.is_file() or p.suffix.lower() not in EXTS or p.name in ALLOW:
        continue
    text=p.read_text(encoding='utf-8',errors='ignore').lower()
    for term in BANNED:
        if term in text:
            hits.append((p.relative_to(ROOT),term))
if hits:
    for p,t in hits: print(f'FAIL {p}: {t}')
    sys.exit(1)
print('PASS: no workflow-status language in public-facing text files.')
