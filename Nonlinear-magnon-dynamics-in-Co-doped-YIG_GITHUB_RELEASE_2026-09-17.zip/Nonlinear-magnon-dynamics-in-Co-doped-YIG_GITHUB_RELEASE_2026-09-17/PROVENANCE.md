# Provenance

This release was rebuilt from the earlier public reproducibility archive after the revision audit of the finite-temperature protocols.

The retained figure scripts, figure data, finite-temperature frequency-scan outputs, micromagnetic estimates, multimode calculations, and canonical-convention scans come from the earlier archive and are preserved byte-for-byte unless listed below.

Changes in this rebuilt release:

- replaced the old segmented Regime-IV production script with `scripts/protocol_correction/regime_IV_corrected_protocol_v8.py`;
- removed the old Regime-IV summary JSON associated with the superseded segmented implementation;
- added `scripts/review_checks/qle_linear_crosscheck.py`;
- added `scripts/review_checks/transition_resolved_dissipator.py`;
- added `scripts/review_checks/phase_basis_convergence_audit.py`;
- added the release-text gate `scripts/release_gate.py`;
- replaced old manuscript/supplement snapshots with the release-ready Supplementary Information only.

The Colab work notebook is not part of the public release because it contains obsolete intermediate script branches. The public repository uses standalone scripts as the reproducibility source of record.
