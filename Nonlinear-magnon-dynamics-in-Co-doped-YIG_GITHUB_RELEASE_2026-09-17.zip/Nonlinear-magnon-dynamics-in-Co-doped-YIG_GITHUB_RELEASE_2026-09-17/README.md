# Nonlinear magnon dynamics in Co-doped YIG — reproducibility package

This repository contains the scripts, numerical outputs, figure data, and Supplementary Information supporting the manuscript **“Operating regimes and materials limits of nonlinear magnon dynamics in Co-doped YIG.”**

## Scope

The package separates three numerical roles that are easy to confuse:

1. **Normalized-model dynamics and figures** — the original single-mode calculations and figure-generation scripts.
2. **Finite-temperature operating-regime checks** — thermal Lindblad and quantum-trajectory calculations, including the corrected thermal-start protocol.
3. **Revision audits** — basis-convergence, linear-QLE, and transition-resolved dissipator checks used to delimit the claims.

The physical conclusion supported by the package is deliberately narrower than a generic device claim: realistic uniform Co:YIG Kerr is too small for the Fock-confinement mechanism explored in the normalized model, while the pair-phase response is the part of the model that remains robust under the materials constraint.

## Directory map

- `scripts/` — production and audit scripts.
- `scripts/protocol_correction/regime_recompute_thermal_protocol_v4.py` — corrected thermal-start campaign used for Regime II and the small-basis reference cases.
- `scripts/protocol_correction/regime_IV_corrected_protocol_v8.py` — corrected large-basis Regime-IV trajectory protocol. It propagates the resonant pump in absolute trajectory time across checkpoint segments and computes final Fock probabilities as `|psi|^2`.
- `scripts/review_checks/` — revision-specific cross-checks: linear QLE, transition-resolved dissipator, and phase-basis convergence.
- `results/` — archived numerical outputs used for figures and quantitative checks.
- `figures/` — publication and supplementary figures in PNG/PDF.
- `docs/Supplementary_Information_release_ready.docx` — Supplementary Information.

## Regime-IV protocol note

The release contains the corrected **v8** Regime-IV script. Older segmented Regime-IV code and its old summary JSON are intentionally excluded because two implementation errors were identified in that earlier branch: checkpoint segments restarted the resonant-pump phase, and final Fock probabilities were formed incorrectly from `real(psi)^2` rather than `|psi|^2`.

The room-temperature 50-GHz phase statistic (`sigma ≈ 40.7 deg`) is a separate reset-and-read transient calculation with its own basis-convergence audit; it is not a thermal steady-state phase-error rate.

## Reproducing the main numerical checks

Create a Python environment from `requirements.txt`, then run individual scripts from the repository root. Examples:

```bash
python scripts/review_checks/phase_basis_convergence_audit.py
python scripts/review_checks/qle_linear_crosscheck.py --n-th 1.2166
python scripts/review_checks/transition_resolved_dissipator.py
```

The Regime-IV v8 trajectory calculation is designed for long, resumable execution (for example in Colab with persistent storage). Use a fresh checkpoint directory when reproducing it.

## Conventions

The archive preserves the Kerr conventions used by the corresponding calculations. In the revision/audit scripts the convention is

`H_Kerr = (U_audit * Omega / 2) a^dagger^2 a^2`,

and the resonant effective pair-pump coefficient is

`G(t) = (eta * Omega / 2) sin(2 Omega t + phi)`.

See the Supplementary Information for the relation between these effective-model coefficients and the generic quadratic-anisotropy decomposition.

## Release integrity

Run

```bash
python scripts/release_gate.py
sha256sum -c SHA256SUMS.txt
```

before publishing or archiving a release.

## Citation and license

See `CITATION.cff` and `LICENSE`.
