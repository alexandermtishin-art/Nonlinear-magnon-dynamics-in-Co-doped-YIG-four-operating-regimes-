# Current numerical results used in the manuscript

Canonical protocol: resonant time-dependent pair drive; `U=0.55`, `eta=1.2`, `alpha=0.001`, `kappa=0.002`; Kerr convention `(U Omega/2) a†²a²`.

| Regime | Basis N | sigma (deg) | two-sided Gaussian-equivalent BER | status |
|---|---:|---:|---:|---|
| Regime I (4 K, 50 GHz) | 80 | 22.439862 | 6.053390e-05 | no convergence warning from current checks |
| Regime II (77 K, 50 GHz) | 120 | 29.947978 | 2.653965e-03 | no convergence warning from current checks |
| Regime III (310 K, 6 THz) | 80 | 26.140693 | 5.754951e-04 | no convergence warning from current checks |
| Regime IV (310 K, 50 GHz) | 240 | 40.705036 | 2.703386e-02 | basis truncation warning: max top10 > 1e-6 |

Important: the Regime IV value is numerically stable in sigma (N=200 to 240 changes by 0.00718 deg), but the archived diagnostic still flags the top-ten-level population at N=240 as above 1e-6. Quote the sigma with this basis-tail qualification in the reproducibility record.
