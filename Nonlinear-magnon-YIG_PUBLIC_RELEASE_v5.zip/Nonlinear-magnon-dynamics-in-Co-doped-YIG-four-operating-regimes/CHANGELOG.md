# Changelog

## 2026-08-03 public-release v5

- Added the full multimode Lindblad calculation for Regime III, which replaces
  the mean-field estimate of v4. It is solved in the excitation-number-restricted
  basis with the modes at their true level spacing, and reaches M = 8 via quantum
  trajectories. Script in `scripts/multimode/`, results in
  `results/multimode_quantum/`.
- Two controls pass: the M = 1 case reproduces the frequency scan of Fig. 10 to
  five digits, and at M = 4 the master equation and 400 trajectories agree to 1 %.
- Result: co-driven neighbours leave the two-level population intact (0.925 ->
  0.972) but suppress the pair correlation, |<aa>| falling from 0.393 to 0.128 at
  M = 8 and following M^-1.31 to within 4 %. The mechanism is cross-Kerr detuning,
  not leakage: a spatially uniform pump transfers no quanta between modes.
- Section 3 of the manuscript updated accordingly. The statement that a full
  multimode treatment "is required" has been replaced by what that treatment
  shows; the extrapolation to 589 modes is marked as an indication of direction
  rather than a result.
- Reference [3] updated from the arXiv preprint to Physica B: Condensed Matter
  (2026), in press.
- Rebuilt MANIFEST.txt and SHA256SUMS.txt.

## 2026-08-03 public-release v4

- Recomputed the 310 K frequency scan in the canonical Kerr convention
  `(U Omega/2) a^d2 a^2`; 17 points, all converged. Table 3 no longer mixes
  normalizations. New numbers at 6 THz: P0+P1 = 0.9254, <n> = 0.2452,
  |<aa>| = 0.3933.
- Recomputed the Fig. 4 U scan in the same convention; the archived
  `U_scan_quantum.csv` was in the legacy `U n^2` convention and is retained
  only for reference.
- Added the micromagnetic normal-mode analysis, which finds no mode localised
  enough to supply U = 0.1-0.55, and the exchange bound that explains why.
- Added the multimode analysis: the single-mode treatment holds on the 50 GHz
  carrier (IPR = 1.0) and fails at 6 THz (589 modes above threshold, IPR = 53).
- Added the U dependence of the pair-phase transfer, which is kinematic and
  unchanged down to U = 0.02.
- Regenerated all 15 figures with the current generator; added a numerical
  cross-check script for the manuscript.
- Rebuilt MANIFEST.txt and SHA256SUMS.txt.

## 2026-08-01 public-release v3

- Replaced the manuscript and Supplementary Information with the current FINAL Word files.
- Replaced all figure files with the complete PRM Q1/APS-style set (Fig. 1-11 and Fig. S1-S4).
- Added one script that regenerates all figures, its layout audit, and all associated CSV data.
- Added the final corrected notebook.
- Added completed low-damping pair-phase results at alpha=0.001:
  sigma = 22.440 deg (I), 29.948 deg (II), 26.141 deg (III), and 40.705 deg (IV).
- Retained the alpha=0.01 package only as clearly marked legacy material.
- Regenerated manifest and SHA-256 checksums.

## 1.0.0 — 2026-07-24

- Archived legacy notebooks and available manuscript figures.
- Added matched static-versus-resonant protocol audit.
- Added Bogoliubov–Lindblad occupation bridge and anomalous-correlator convention audit.
- Added checkpointed exploratory U–eta scan.
- Added five-phase pair-control test.
- Rewrote Supplementary Information to remove unsupported numerical claims and separate protocol-dependent results.

## 2026-07-24 - phase-control update

- Added stationary five-phase pair-control results and final Figure 5.
- Added `phase_step_test_v2.py`, which uses complex-plane extraction and supersedes the phase-unwrapping response analysis.
- Retained v1 as `phase_step_test_v1_deprecated.py` for provenance with an explicit warning.
- Added final Figure 4, Figure 5, and supplementary step-response figure.
- Added `make_final_figures.py` and a script-level README.
- Updated Supplementary Information with the measured stationary phase transfer and dynamical step-response limits.

## 2026-07-28 public-package update
- Added latest PRM manuscript and revised Supplementary Information.
- Added completed finite-temperature frequency scan through 10 THz.
- Added verified 6-10 THz raw JSON and CSV subset.
- Added combined publication figure and plotting table.
- Added archive audit and protocol-separation warning.
- Retained incomplete run-21 package only under legacy provenance.

## 2026-07-28 final public-package rebuild
- Replaced the earlier Supplementary Information snapshot with `Supplementary_Information_PRM_final.docx` and its PDF rendering.
- Matched the Supplementary Information title to the PRM manuscript title.
- Added Supplement 8 documenting the 310 K thermal Lindblad model, the Kerr-convention boundary, verified 6–10 THz values, and Figure S4.
- Added accessibility metadata for figures and repeating table-header rows.
- Regenerated manifest and SHA-256 checksums and revalidated the complete ZIP.
