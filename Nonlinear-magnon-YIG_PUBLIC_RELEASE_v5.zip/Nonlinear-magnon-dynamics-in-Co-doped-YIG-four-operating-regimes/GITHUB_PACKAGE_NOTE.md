# GitHub upload package

This package is the size-reduced GitHub version of public release v3.

Removed only from this upload package:
- superseded legacy notebooks;
- superseded legacy manuscript files;
- the obsolete alpha=0.01 incomplete checkpoint package;
- stored output cells from the final notebook.

Preserved:
- current manuscript and Supplementary Information;
- all final main and supplementary figures in PDF and PNG;
- all current scripts and numerical data;
- the complete final notebook source code and markdown;
- the completed alpha=0.001 pair-phase results;
- validation report and exact current numerical values.
