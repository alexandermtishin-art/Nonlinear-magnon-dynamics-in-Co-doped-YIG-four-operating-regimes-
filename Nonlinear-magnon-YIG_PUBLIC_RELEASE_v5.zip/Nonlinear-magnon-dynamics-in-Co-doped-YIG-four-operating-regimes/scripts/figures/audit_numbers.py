# -*- coding: utf-8 -*-
"""Cross-check every number that appears in more than one place.

The manuscript has been through many rounds of edits, so the risk is that a
value was updated in one location and not in another.  This walks the main
text and the Supplement and reports, for each quantity, every place it occurs
and whether the occurrences agree.
"""
import re
import sys
from collections import defaultdict
from lxml import etree

W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
def q(t): return '{%s}%s' % (W, t)


def paragraphs(path):
    tree = etree.parse(path)
    out = []
    for p in tree.getroot().iter(q('p')):
        runs = []
        for r in p.iter(q('r')):
            rPr = r.find(q('rPr'))
            va = None
            if rPr is not None and rPr.find(q('vertAlign')) is not None:
                va = rPr.find(q('vertAlign')).get(q('val'))
            txt = ''.join(e.text or '' for e in r.findall(q('t')))
            if not txt:
                continue
            if va == 'superscript':
                runs.append('^' + txt)
            elif va == 'subscript':
                runs.append('_' + txt)
            else:
                runs.append(txt)
        s = ''.join(runs)
        if s.strip():
            out.append(s)
    return out


MAIN = paragraphs('curu/word/document.xml')
SUPP = paragraphs('supp_unp/word/document.xml')
ALL = [('main', s) for s in MAIN] + [('supp', s) for s in SUPP]


def find(pattern, label, where=None):
    """Collect every distinct value matching pattern."""
    hits = defaultdict(list)
    for src, s in ALL:
        if where and src != where:
            continue
        for m in re.finditer(pattern, s):
            hits[m.group(1)].append((src, s[max(0, m.start() - 45):m.start() + 45]))
    return label, hits


CHECKS = [
    # --- phase statistics of the four regimes ---------------------------
    (r'22\.4|29\.9|26\.1|40\.7', 'sigma values (22.4 / 29.9 / 26.1 / 40.7)'),
    # --- occupancies and populations ------------------------------------
    (r'0\.9(?:68|684|64|66)\d*', 'P0+P1 at U = 0.55 (expect 0.9684)'),
    (r'(0\.228\d*)', 'max_t<n> at the reference point (expect 0.2288)'),
    (r'(0\.117\d*|0\.1179)', 'late-time <n> at the reference point (expect 0.117)'),
    # --- microscopic numbers --------------------------------------------
    (r'(1\.3 ?× ?10\^−5|1\.33 ?× ?10\^−5|3 ?× ?10\^−5|3×10\^−5)', 'U of the uniform mode'),
    (r'(1\.5 ?× ?10\^5|1\.51 ?× ?10\^5)', 'N_eff of the cell'),
    (r'(6\.0 ?× ?10\^4|60 ?384)', 'Fe3+ ions per cell'),
    # --- frequencies -----------------------------------------------------
    (r'(200\.?\d* GHz|214 T)', 'anisotropy frequency / field'),
    (r'(2\.03 ?× ?10\^9|3\.1 nm)', 'k and wavelength at 6 THz'),
    (r'(36 GHz|6\.3 GHz|6\.0 GHz|589)', 'mode spectrum numbers'),
    # --- criterion --------------------------------------------------------
    (r'(9\.7 ?× ?10\^−6|3\.9 ?× ?10\^−5|1370 nm|342 nm)', 'alpha criterion numbers'),
    # --- energies ---------------------------------------------------------
    (r'(22–24 aJ|24 aJ|6 J cm)', 'switching energy'),
]

print('=' * 78)
print('CROSS-CHECK OF REPEATED NUMBERS')
print('=' * 78)
for pat, label in CHECKS:
    _, hits = find('(' + pat + ')' if not pat.startswith('(') else pat, label)
    total = sum(len(v) for v in hits.values())
    vals = sorted(hits.keys())
    print('\n%-46s occurrences: %d' % (label, total))
    for v in vals:
        srcs = {s for s, _ in hits[v]}
        print('    %-24s x%-3d  [%s]' % (v, len(hits[v]), ','.join(sorted(srcs))))

# ---------------------------------------------------------------- figures
print('\n' + '=' * 78)
print('FIGURES AND TABLES')
print('=' * 78)
for name, src in (('main', MAIN), ('supp', SUPP)):
    caps_f = [s[:40] for s in src if re.match(r'^Figure S?\d+\.', s)]
    caps_t = [s[:40] for s in src if re.match(r'^Table \d+\.', s)]
    refs_f = sorted({int(m.group(1)) for s in src
                     for m in re.finditer(r'Figs?\.? (\d+)', s)})
    refs_t = sorted({int(m.group(1)) for s in src
                     for m in re.finditer(r'Table (\d+)', s)})
    print('\n[%s] captions: %d figures, %d tables' % (name, len(caps_f), len(caps_t)))
    for c in caps_f + caps_t:
        print('    ', c)
    print('     referenced figures:', refs_f)
    print('     referenced tables :', refs_t)

# ------------------------------------------------------------- references
print('\n' + '=' * 78)
print('REFERENCES')
print('=' * 78)
ref_i = max(i for i, s in enumerate(MAIN) if s.strip() == 'References')
body = '\n'.join(MAIN[:ref_i])
seen = []
for m in re.finditer(r'\[([0-9][0-9,\s\u2013\-]*)\]', body):
    for part in m.group(1).replace('\u2013', '-').split(','):
        part = part.strip()
        mm = re.fullmatch(r'(\d+)\s*-\s*(\d+)', part)
        if mm:
            for n in range(int(mm.group(1)), int(mm.group(2)) + 1):
                if n not in seen:
                    seen.append(n)
        elif part.isdigit():
            n = int(part)
            if n not in seen:
                seen.append(n)
n_ref = sum(1 for s in MAIN[ref_i + 1:] if s.strip())
print('  entries in the list      :', n_ref)
print('  first-appearance ordered :', seen == sorted(seen))
print('  never cited              :', [k for k in range(1, n_ref + 1) if k not in seen])
print('  cited beyond the list    :', [k for k in seen if k > n_ref])
