"""
Normal-mode (eigenmode) analysis of a 20 x 20 x 10 nm^3 Co:YIG cell.

The manuscript uses a normalized Kerr coefficient U = 0.1-0.55 while a
uniformly excited cell of this size gives U ~ 3e-5, and closes the gap by
assuming that the nonlinear response is carried by a strongly confined
sub-mode of N_eff ~ 4-20 spins.  This script tests that assumption directly:
it computes the normal modes of the linearized Landau-Lifshitz equation for
the cell and measures how many spins each mode actually occupies.

MODEL
-----
Finite-difference discretisation on a uniform mesh.  Ground state is uniform
along the easy axis z (Ku = 5e5 J/m^3 dominates the shape anisotropy by a
factor ~40, so the perpendicular state is the equilibrium).  Writing
m = z + (mx, my) with |m_perp| << 1, the linearised torque equation is

    dmx/dt = -gamma0 ( Hz0 my - Hy )
    dmy/dt = -gamma0 ( Hx - Hz0 mx )

    Hx,y = (2A/(mu0 Ms)) Lap m_{x,y} - Ms (N m)_{x,y}
    Hz0  = 2Ku/(mu0 Ms) - Ms (N)_zz-row-sum      (per cell)

giving a real 2N x 2N matrix whose eigenvalues come in pairs +/- i omega.

APPROXIMATIONS, stated plainly
------------------------------
  * dipolar field: point-dipole kernel between distinct cells, analytic
    self-demagnetising factor within a cell.  The dipolar energy density
    mu0 Ms^2/2 = 1.2e4 J/m^3 is ~40x below Ku and ~10^3 below the exchange
    scale at this mesh, so the mode profiles are set by exchange and geometry,
    not by the fine structure of the dipolar kernel.
  * zero temperature, no damping (damping shifts linewidths, not profiles).
  * free (Neumann) boundary conditions, i.e. no surface anisotropy pinning.
    Surface pinning would push modes *away* from the edges, i.e. make them
    less localised, so neglecting it is the optimistic choice for the
    manuscript's assumption.

OUTPUT
------
For every mode: frequency, participation ratio (how many cells carry the
mode), the implied number of spins N_eff, and the normalized Kerr coefficient
that mode would produce, U = omega_a / (2 N_eff Omega), the relation used in
Section 5.1 of the manuscript.
"""
import numpy as np

# ------------------------------------------------------------------ constants
mu0 = 4e-7 * np.pi
muB = 9.2740100783e-24
gamma = 1.760859630e11          # rad s^-1 T^-1
gamma0 = gamma * mu0            # m A^-1 s^-1

# ------------------------------------------------------------------ material
Ms = 1.4e5                      # A/m, YIG
A = 3.65e-12                    # J/m
Ku = 5.0e5                      # J/m^3, value quoted in the manuscript
LX = LY = 20e-9
LZ = 10e-9
OMEGA_HZ = 50e9                 # drive frequency of Regime I / II / IV

# ------------------------------------------------------------------ mesh
NX = NY = 10
NZ = 5
dx, dy, dz = LX / NX, LY / NY, LZ / NZ
CELL_V = dx * dy * dz
N = NX * NY * NZ

idx = np.arange(N)
ix, iy, iz = np.unravel_index(idx, (NX, NY, NZ))
pos = np.stack([(ix + 0.5) * dx, (iy + 0.5) * dy, (iz + 0.5) * dz], axis=1)

spins_per_cell = Ms * CELL_V / muB / 5.0        # 5 muB per Fe3+ (S=5/2, g=2)
print('mesh %d x %d x %d = %d cells, cell = %.2f nm' % (NX, NY, NZ, N, dx * 1e9))
print('spins per cell  : %.1f' % spins_per_cell)
print('spins in cell   : %.0f' % (spins_per_cell * N))


# ------------------------------------------------------------------ exchange
def laplacian():
    """Finite-difference Laplacian with free (Neumann) boundaries."""
    L = np.zeros((N, N))
    grid = np.arange(N).reshape(NX, NY, NZ)
    for ax, (n, h) in enumerate([(NX, dx), (NY, dy), (NZ, dz)]):
        for s in (-1, +1):
            nb = np.roll(grid, s, axis=ax)
            # Neumann: a boundary cell couples to itself instead of wrapping
            sl = [slice(None)] * 3
            sl[ax] = 0 if s == +1 else n - 1
            nb[tuple(sl)] = grid[tuple(sl)]
            L[grid.ravel(), nb.ravel()] += 1.0 / h ** 2
            L[grid.ravel(), grid.ravel()] -= 1.0 / h ** 2
    return L


# ------------------------------------------------------------------ dipolar
def self_demag(a, b, c):
    """Diagonal demagnetising factors of a rectangular prism a x b x c."""
    def f(p, q, r):
        R = np.sqrt(p * p + q * q + r * r)
        return (0.5 * (q * q - r * r) * np.arcsinh(p / np.sqrt(q * q + r * r))
                + 0.5 * (p * p - r * r) * np.arcsinh(q / np.sqrt(p * p + r * r))
                - p * q * np.arctan(p * q / (r * R))
                + r * R / 3.0
                - (p ** 3 + q ** 3 - 2 * r ** 3) / 6.0)
    def N_ax(a_, b_, c_):
        s = 0.0
        for sp, p in ((1, a_ / 2), (-1, -a_ / 2)):
            for sq, q in ((1, b_ / 2), (-1, -b_ / 2)):
                for sr, r in ((1, c_ / 2), (-1, -c_ / 2)):
                    s += sp * sq * sr * f(p, q, r)
        return s / (np.pi * a_ * b_ * c_)
    return N_ax(a, b, c), N_ax(b, c, a), N_ax(c, a, b)


def demag_tensor():
    """N[i,j] such that H_d(i) = -Ms sum_j N[i,j] m(j).  Point dipole for
    i != j, analytic prism self-term for i == j."""
    Nt = np.zeros((3, 3, N, N))
    d = pos[:, None, :] - pos[None, :, :]
    r2 = (d ** 2).sum(axis=2)
    np.fill_diagonal(r2, np.inf)
    r = np.sqrt(r2)
    pref = CELL_V / (4 * np.pi)
    for a in range(3):
        for b in range(3):
            kron = 1.0 if a == b else 0.0
            Nt[a, b] = pref * (kron / r ** 3 - 3 * d[:, :, a] * d[:, :, b] / r ** 5)
    Nxx, Nyy, Nzz = self_demag(dx, dy, dz)
    for a, val in enumerate((Nxx, Nyy, Nzz)):
        np.fill_diagonal(Nt[a, a], val)
    return Nt


print('building operators ...')
Lap = laplacian()
Nt = demag_tensor()

Hex = (2 * A / (mu0 * Ms)) * Lap                 # A/m per unit m
Hd_xx = -Ms * Nt[0, 0]
Hd_xy = -Ms * Nt[0, 1]
Hd_yx = -Ms * Nt[1, 0]
Hd_yy = -Ms * Nt[1, 1]

Hz0 = 2 * Ku / (mu0 * Ms) - Ms * Nt[2, 2].sum(axis=1)
print('anisotropy field      : %.3e A/m  (%.2f T)' % (2 * Ku / (mu0 * Ms),
                                                      mu0 * 2 * Ku / (mu0 * Ms)))
print('mean static z-demag   : %.3e A/m' % (Ms * Nt[2, 2].sum(axis=1).mean()))

Hx_op = Hex + Hd_xx
Hy_op = Hex + Hd_yy
Z = np.diag(Hz0)

# du/dt = M u,  u = (mx, my)
M = np.zeros((2 * N, 2 * N))
M[:N, :N] = gamma0 * Hd_yx                    # from +gamma0 Hy, the my->... part
M[:N, N:] = gamma0 * (Hy_op - Z)
M[N:, :N] = -gamma0 * (Hx_op - Z)
M[N:, N:] = -gamma0 * Hd_xy

print('diagonalising %d x %d ...' % (2 * N, 2 * N))
w, v = np.linalg.eig(M)

freq = np.abs(w.imag) / (2 * np.pi)
order = np.argsort(freq)
seen, modes = set(), []
for k in order:
    f = freq[k]
    if f < 1e6:
        continue
    if any(abs(f - g) < 1e-6 * max(f, 1) for g in seen):
        continue
    seen.add(f)
    modes.append(k)
    if len(modes) >= 25:
        break

print()
print('%-5s %-12s %-14s %-12s %-12s' % ('mode', 'f (GHz)', 'cells occupied',
                                        'N_eff spins', 'U = wa/(2 N_eff W)'))
print('-' * 62)
wa = gamma * 2 * Ku / Ms                      # rad/s, anisotropy frequency
W = 2 * np.pi * OMEGA_HZ
rows = []
for k in modes:
    u = v[:, k]
    amp2 = np.abs(u[:N]) ** 2 + np.abs(u[N:]) ** 2
    amp2 = amp2 / amp2.sum()
    part = 1.0 / (amp2 ** 2).sum()            # inverse participation ratio
    neff = part * spins_per_cell
    U = wa / (2 * neff * W)
    rows.append((freq[k] / 1e9, part, neff, U))
    print('%-5d %-12.2f %-14.1f %-12.0f %-12.3e'
          % (len(rows), freq[k] / 1e9, part, neff, U))

print()
print('most localised of the %d lowest modes:' % len(rows))
best = min(rows, key=lambda r: r[2])
print('  f = %.2f GHz, occupies %.1f of %d cells, N_eff = %.0f spins, U = %.2e'
      % (best[0], best[1], N, best[2], best[3]))
print()
print('manuscript needs N_eff = 4-20 spins for U = 0.1-0.55;')
print('the least extended computed mode is %.0fx larger than that.'
      % (best[2] / 20.0))
