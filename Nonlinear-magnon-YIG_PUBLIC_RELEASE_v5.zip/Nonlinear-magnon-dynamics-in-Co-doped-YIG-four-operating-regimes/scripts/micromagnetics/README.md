# Micromagnetics

Two scripts that test whether the Kerr coefficient used in the Lindblad
calculations, U = 0.1-0.55, can be realized by a mode of the 20 x 20 x 10 nm
Co:YIG cell.

`micromagnetic_modes.py`
: eigenmodes of the linearised Landau-Lifshitz equation on a 2 nm mesh
  (exchange, uniaxial anisotropy, dipolar coupling, free boundaries).  Reports
  the frequency, participation ratio and implied N_eff of every mode, and the
  U each would produce.  Validated against the analytic standing-wave spectrum:
  198.9 GHz computed against 200.2 GHz analytic for the uniform mode.
  Result: no localised mode.  The least extended of the 25 lowest occupies a
  quarter of the cell, N_eff = 3.1e3, U = 6.5e-4.

`mode_bound.py`
: the analytic counterpart.  Tabulates the volume, linear size and exchange
  frequency of a mode with a given spin content.  A mode of 4-20 spins would be
  0.5-0.8 nm across, smaller than the 1.24 nm YIG unit cell, and would sit at
  22-64 THz.

Note on spin counting: N_eff is the spin content S*N_ion, not the number of
formula units.  For this cell M_s = 1.4e5 A/m gives 6.0e4 Fe(3+) ions and
N_eff = 1.5e5, hence U = 1.3e-5 for the uniform mode.
