# Changelog

## 2026-09-17 (same day) — fixed a QuTiP 5.x compatibility bug in a review-check script

- `scripts/review_checks/transition_resolved_dissipator.py` passed `e_ops` as a 5th positional argument to `mesolve`; QuTiP 5.3.1 requires `e_ops` to be keyword-only, so the script raised `TypeError` and could not be run as archived. Fixed by passing it as a keyword (in this case simply omitted, since the script only uses `final_state`).
- Re-ran the corrected script: Regime I single-frequency to transition-resolved P0+P1 = 0.496118 to 0.432786 (-12.8%); Regime III 0.583874 to 0.483644 (-17.2%). Both reproduce the values quoted in Supplement 9 (S9.6) and the Response to Reviewers (M6).
- Regenerated the manifest and SHA-256 checksums.

## 2026-09-17 — GitHub-ready reproducibility release

- Corrected the Regime-IV segmented protocol so the resonant-pump phase is continuous in absolute trajectory time across checkpoints.
- Corrected final Fock probabilities to use `|psi|^2`.
- Excluded the superseded Regime-IV segmented script and its old summary result.
- Added revision audit scripts for the linear QLE cross-check, transition-resolved dissipator sensitivity, and reset-and-read phase basis convergence.
- Added a one-command reproducibility runner and a claim-to-script reproducibility map.
- Strengthened the public-release gate to scan both plain-text files and Word document XML.
- Replaced stale document snapshots with the release-ready Supplementary Information.
- Removed build/notebook-extraction utilities that are not needed to reproduce the published calculations.
- Corrected `.gitignore` so archived result directories are not accidentally omitted when the repository is first committed.
- Clarified the repository license status: no open-source reuse license is specified in this release.
- Regenerated the manifest and SHA-256 checksums.
