# Reproducibility map

This file maps the main numerical claims to the scripts and archived data that support them.

| Claim / check | Script | Archived data / output |
|---|---|---|
| Five-phase pair control and phase-transfer fit | `scripts/five_phase_control.py` | `results/five_phase_pair_control_*.csv` |
| Long-time and publication figures | `scripts/figures/make_all_figures.py`, figure-specific scripts | `figures/`, `results/figure_data/` |
| Room-temperature frequency scan | `scripts/finite_temperature_frequency_scan_to_10THz.py` and archived Colab scan scripts | `results/finite_temperature_310K_frequency_scan/` |
| Corrected thermal-start population protocol | `scripts/protocol_correction/regime_recompute_thermal_protocol_v4.py` | output produced by the script; small-basis reference values are described in the Supplement |
| Regime-IV large-basis thermal-start protocol | `scripts/protocol_correction/regime_IV_corrected_protocol_v8.py` | output produced by the resumable trajectory calculation |
| Regime-II/IV reset-and-read phase-basis convergence | `scripts/review_checks/phase_basis_convergence_audit.py` | `results/pair_phase_std_low_damping_final/results_pair_phase_std.csv` |
| Linear-QLE instability at the revision operating point | `scripts/review_checks/qle_linear_crosscheck.py` | console output from the deterministic integration |
| Transition-resolved Kerr-basis dissipator sensitivity | `scripts/review_checks/transition_resolved_dissipator.py` | console output from the direct comparison |
| Multimode Regime-III sensitivity | `scripts/multimode/` | corresponding archived result files under `results/` |
| Micromagnetic mode-spacing estimates | `scripts/micromagnetics/` | `results/micromagnetics/` |

## What is not combined

Several quantities in the manuscript come from intentionally different protocols and should not be mixed:

- thermal-start `P0+P1` values and reset-and-read phase widths are separate observables;
- the static effective-pair-drive frequency scan and the resonantly modulated phase-control protocol are separate calculations;
- the normalized-model Kerr parameter and the materials-derived Co:YIG Kerr scale are distinct layers of the analysis.

The Supplementary Information is the authoritative protocol description for these distinctions.
