# Scripts

Run scripts from the repository root unless a file states otherwise.

## Entry points

- `run_checks.py` — one-command release/audit runner. Default mode runs the lightweight checks; `--full` also runs the transition-resolved dissipator calculation.
- `release_gate.py` — scans public-facing text and DOCX content for workflow-status language that must not appear in a public release.

## Production calculations

- `protocol_correction/regime_recompute_thermal_protocol_v4.py` — corrected thermal-start calculations for the finite-temperature protocol.
- `protocol_correction/regime_IV_corrected_protocol_v8.py` — corrected large-basis, segmented, resumable Regime-IV calculation with continuous absolute-time pump phase and `|psi|^2` final populations.

## Revision audits

- `review_checks/phase_basis_convergence_audit.py` — verifies the archived Regime-II and Regime-IV reset-and-read phase convergence values.
- `review_checks/qle_linear_crosscheck.py` — demonstrates the unbounded linear `U=0` QLE dynamics at the revision operating point.
- `review_checks/transition_resolved_dissipator.py` — direct Kerr-basis transition-resolved dissipator sensitivity check for Regimes I and III.

## Other groups

- `canonical_convention/` — canonical-convention scans.
- `figures/` — publication-figure generation and numerical figure audits.
- `micromagnetics/` — mode-spacing estimates.
- `multimode/` — multimode Regime-III calculations.

The superseded segmented Regime-IV implementation is not part of this release.
