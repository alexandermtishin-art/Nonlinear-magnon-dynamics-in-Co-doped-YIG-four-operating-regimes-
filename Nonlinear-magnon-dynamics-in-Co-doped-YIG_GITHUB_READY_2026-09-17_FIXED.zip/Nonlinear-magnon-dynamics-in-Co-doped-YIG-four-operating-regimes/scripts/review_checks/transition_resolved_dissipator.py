#!/usr/bin/env python3
"""Transition-resolved Kerr-basis dissipator check for Regimes I and III.

This reproduces the sensitivity calculation described in Supplement 9:
E_n/Omega = n + (U_audit/2)n(n-1),
omega_n/Omega = 1 + U_audit(n-1),
and each adjacent transition uses its own Bose occupation n_th(f_n).
The resonant pair drive is G(t)=eta*Omega/2*sin(2*Omega*t+phi).

Expected revision values at N=25, U_audit=0.55, eta=1.2,
alpha=1e-3, kappa*t=3:
  Regime I:  P0+P1 about 0.433 (transition-resolved) vs 0.496 (single-frequency)
  Regime III:P0+P1 about 0.484 (transition-resolved) vs 0.584 (single-frequency)
The 13-17% shifts apply to P0+P1 only and are not general error bounds.
"""
import numpy as np
from qutip import basis, destroy, mesolve, Qobj

HBAR = 1.054571817e-34
KB = 1.380649e-23
OMEGA = 1.0
U_AUDIT = 0.55
ETA = 1.2
ALPHA = 1.0e-3
KAPPA = 2.0*ALPHA*OMEGA
N = 25
KTARGET = 3.0
TMAX = KTARGET/KAPPA

REGIMES = {
    'I': (50e9, 4.0),
    'III': (6e12, 310.0),
}


def nth(freq_hz, T):
    return 1.0/np.expm1(HBAR*2*np.pi*freq_hz/(KB*T))


def build():
    a=destroy(N); ad=a.dag(); n=ad*a
    H0=OMEGA*n + 0.5*U_AUDIT*OMEGA*ad*ad*a*a
    pair=ad*ad+a*a
    return a,ad,n,H0,pair


def coeff(t, args=None):
    return 0.5*ETA*OMEGA*np.sin(2*OMEGA*t)


def anharmonic_gibbs(freq_hz,T):
    ns=np.arange(N,dtype=float)
    e=ns + 0.5*U_AUDIT*ns*(ns-1.0)
    beta_e=(HBAR*2*np.pi*freq_hz/(KB*T))*e
    w=np.exp(-(beta_e-beta_e.min())); w/=w.sum()
    return Qobj(np.diag(w), dims=[[N],[N]])


def transition_cops(freq_hz,T):
    cops=[]
    for n in range(1,N):
        omega_rel=1.0 + U_AUDIT*(n-1)
        nt=nth(freq_hz*omega_rel,T)
        down=np.sqrt(KAPPA*(nt+1.0)*n) * basis(N,n-1)*basis(N,n).dag()
        up=np.sqrt(KAPPA*nt*n) * basis(N,n)*basis(N,n-1).dag()
        cops += [down,up]
    return cops


def single_cops(a,ad,freq_hz,T):
    nt=nth(freq_hz,T)
    return [np.sqrt(KAPPA*(nt+1))*a, np.sqrt(KAPPA*nt)*ad]


def run(regime):
    f,T=REGIMES[regime]
    a,ad,nop,H0,pair=build()
    t=np.linspace(0,TMAX,3001)
    H=[H0,[pair,coeff]]
    rho_bare=np.diag([(1/(1+nth(f,T)))*(nth(f,T)/(1+nth(f,T)))**n for n in range(N)])
    rho_bare=Qobj(rho_bare/rho_bare.trace(),dims=[[N],[N]])
    rho_gibbs=anharmonic_gibbs(f,T)
    rs=mesolve(H,rho_bare,t,single_cops(a,ad,f,T),options={'nsteps':1000000,'rtol':1e-7,'atol':1e-9}).final_state
    rd=mesolve(H,rho_gibbs,t,transition_cops(f,T),options={'nsteps':1000000,'rtol':1e-7,'atol':1e-9}).final_state
    ps=np.real(np.diag(rs.full())); pd=np.real(np.diag(rd.full()))
    return ps[:2].sum(),pd[:2].sum()

if __name__=='__main__':
    for r in ('I','III'):
        single,dressed=run(r)
        print(f"Regime {r}: single_frequency_P0+P1={single:.6f} transition_resolved_P0+P1={dressed:.6f} relative_change={(dressed/single-1):+.2%}")
