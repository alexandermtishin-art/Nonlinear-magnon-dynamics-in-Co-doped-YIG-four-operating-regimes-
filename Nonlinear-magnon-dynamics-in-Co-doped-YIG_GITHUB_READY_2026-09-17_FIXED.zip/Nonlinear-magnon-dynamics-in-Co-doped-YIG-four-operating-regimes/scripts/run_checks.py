#!/usr/bin/env python3
"""Run the public-release and core reproducibility checks from one entry point."""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PY = sys.executable

QUICK = [
    [PY, str(ROOT / "scripts" / "release_gate.py")],
    [PY, str(ROOT / "scripts" / "review_checks" / "phase_basis_convergence_audit.py")],
    [PY, str(ROOT / "scripts" / "review_checks" / "qle_linear_crosscheck.py"), "--n-th", "1.2166"],
]
FULL_EXTRA = [
    [PY, str(ROOT / "scripts" / "review_checks" / "transition_resolved_dissipator.py")],
]


def run(cmd: list[str]) -> None:
    print("\n$ " + " ".join(cmd), flush=True)
    subprocess.run(cmd, cwd=ROOT, check=True)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--full", action="store_true", help="also run the transition-resolved dissipator calculation")
    args = ap.parse_args()

    for cmd in QUICK:
        run(cmd)
    if args.full:
        for cmd in FULL_EXTRA:
            run(cmd)
    print("\nPASS: requested reproducibility checks completed.")


if __name__ == "__main__":
    main()
