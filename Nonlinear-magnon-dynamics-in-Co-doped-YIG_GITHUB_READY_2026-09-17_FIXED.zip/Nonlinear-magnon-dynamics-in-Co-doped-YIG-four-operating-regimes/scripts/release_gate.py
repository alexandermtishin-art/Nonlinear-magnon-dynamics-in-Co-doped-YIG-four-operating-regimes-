#!/usr/bin/env python3
"""Public-release text gate.

Scans public-facing Markdown/text/CFF files and Word document XML for workflow
status language that should not appear in a public release. Scientific uses of
similar words inside Python source are intentionally not scanned.
"""
from pathlib import Path
import re
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
BANNED = [
    "pending",
    "ongoing",
    "in progress",
    "re-verification",
    "will be inserted",
    "deferred until",
    "calculation is running",
    "calculation is in progress",
    "preliminary",
    "tbd",
    "todo",
    "[regime_iv_final]",
]
TEXT_EXTS = {".md", ".txt", ".cff"}
ALLOW = {"MANIFEST.txt", "SHA256SUMS.txt"}


def visible_text(path: Path) -> str:
    if path.suffix.lower() in TEXT_EXTS:
        return path.read_text(encoding="utf-8", errors="ignore")
    if path.suffix.lower() == ".docx":
        chunks = []
        try:
            with zipfile.ZipFile(path) as zf:
                for name in zf.namelist():
                    if not (name.startswith("word/") and name.endswith(".xml")):
                        continue
                    xml = zf.read(name).decode("utf-8", errors="ignore")
                    chunks.append(re.sub(r"<[^>]+>", " ", xml))
        except zipfile.BadZipFile:
            return ""
        return "\n".join(chunks)
    return ""


hits = []
for p in ROOT.rglob("*"):
    if not p.is_file() or p.name in ALLOW:
        continue
    if p.suffix.lower() not in TEXT_EXTS | {".docx"}:
        continue
    text = visible_text(p).lower()
    for term in BANNED:
        if term in text:
            hits.append((p.relative_to(ROOT), term))

if hits:
    for p, term in hits:
        print(f"FAIL {p}: {term}")
    sys.exit(1)
print("PASS: no workflow-status language in public-facing text or DOCX content.")
