# Nonlinear magnon dynamics in Co-doped YIG — reproducibility package

This repository contains the scripts, numerical outputs, figure data, figures, and Supplementary Information supporting the manuscript **“Operating regimes and materials limits of nonlinear magnon dynamics in Co-doped YIG”** (MAGMA-D-26-01870).

The package is organized to keep three numerical roles separate:

1. **Normalized-model dynamics and figures** — single-mode calculations and publication-figure generation.
2. **Finite-temperature operating-regime calculations** — thermal Lindblad and quantum-trajectory protocols.
3. **Revision audits** — basis convergence, linear-QLE, and transition-resolved dissipator checks that delimit the claims.

The materials-level conclusion is intentionally narrow: realistic uniform Co:YIG Kerr is too small for the Fock-confinement mechanism explored in the normalized model, while the pair-phase response is the part of the model that remains robust under the materials constraint.

## Quick start

From the repository root:

```bash
python -m venv .venv
```

Activate the environment:

```bash
# Linux/macOS
source .venv/bin/activate

# Windows PowerShell
.venv\Scripts\Activate.ps1
```

Install the dependencies:

```bash
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

Run the lightweight release checks:

```bash
python scripts/run_checks.py
```

The quick check verifies the public-release text gate, the archived Regime-II/IV phase-basis convergence values, and the linear-QLE instability test. To include the transition-resolved Kerr-basis dissipator calculation:

```bash
python scripts/run_checks.py --full
```

## Repository map

```text
scripts/
  protocol_correction/   corrected thermal-start production protocols
  review_checks/         revision-specific numerical audits
  canonical_convention/  canonical-convention scans
  figures/               figure generation and figure-number audits
  micromagnetics/        mode-spacing estimates
  multimode/             multimode Regime-III checks
results/                  archived numerical outputs and figure data
figures/                  publication and supplementary figures (PNG/PDF)
docs/                     release-ready Supplementary Information
```

For a claim-to-script map, see [`REPRODUCIBILITY_MAP.md`](REPRODUCIBILITY_MAP.md).

## Regime-IV corrected protocol

Use:

```text
scripts/protocol_correction/regime_IV_corrected_protocol_v8.py
```

This is the corrected large-basis Regime-IV trajectory protocol. Relative to the superseded segmented branch it makes two essential implementation corrections:

- the resonant-pump phase is propagated in **absolute trajectory time** across checkpoint segments;
- final Fock probabilities are computed from **`|psi|^2`**, not from `real(psi)^2`.

The script is designed for long resumable execution and uses a checkpoint directory defined in its configuration block. For Colab reproduction, mount persistent storage and point `CHECKPOINT_DIR` to a fresh directory before running the script.

The room-temperature 50-GHz phase statistic (`sigma ≈ 40.7 deg`) belongs to a separate reset-and-read transient calculation with its own basis-convergence audit. It is not a thermal steady-state phase-error rate.

## Main audit commands

```bash
python scripts/review_checks/phase_basis_convergence_audit.py
python scripts/review_checks/qle_linear_crosscheck.py --n-th 1.2166
python scripts/review_checks/transition_resolved_dissipator.py
```

The transition-resolved dissipator calculation is the heaviest of these three checks and requires QuTiP from `requirements.txt`.

## Conventions

Revision/audit scripts use

```text
H_Kerr = (U_audit * Omega / 2) a^dagger^2 a^2
G(t)   = (eta * Omega / 2) sin(2 Omega t + phi)
```

Older figure scripts retain the conventions of the corresponding archived calculations. The Supplementary Information states the convention used for each protocol and explains the generic quadratic-anisotropy decomposition underlying the effective pair drive.

## Release integrity

Before uploading a release, run:

```bash
python scripts/release_gate.py
python -m py_compile $(find scripts -name '*.py' -print)   # Linux/macOS
sha256sum -c SHA256SUMS.txt                                # Linux/macOS
```

On Windows, the first command is platform-independent; the checksum file can be verified with any SHA-256 utility.

## Citation

GitHub can read `CITATION.cff` directly. The repository currently points to the associated manuscript by title and manuscript number; a journal DOI can be added after publication.

## License status

No open-source license is granted by this repository. The code and data are made available for inspection and reproducibility of the associated manuscript. Reuse beyond that scope requires permission from the author.
