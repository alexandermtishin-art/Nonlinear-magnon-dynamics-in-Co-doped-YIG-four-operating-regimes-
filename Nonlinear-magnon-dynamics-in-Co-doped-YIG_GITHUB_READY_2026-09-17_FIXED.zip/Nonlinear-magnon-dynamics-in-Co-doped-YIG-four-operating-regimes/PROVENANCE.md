# Provenance

This repository was rebuilt from the earlier public reproducibility archive after the revision audit of the finite-temperature protocols.

The retained figure scripts, figure data, finite-temperature frequency-scan outputs, micromagnetic estimates, multimode calculations, and canonical-convention scans originate from the earlier archive. The revision-specific files listed below supersede their earlier counterparts where applicable.

Changes in this rebuilt release:

- `scripts/protocol_correction/regime_IV_corrected_protocol_v8.py` replaces the superseded segmented Regime-IV implementation;
- the old Regime-IV summary JSON associated with that superseded implementation is excluded;
- `scripts/review_checks/qle_linear_crosscheck.py` adds the linear-QLE check;
- `scripts/review_checks/transition_resolved_dissipator.py` adds the Kerr-basis transition-resolved dissipator check;
- `scripts/review_checks/phase_basis_convergence_audit.py` verifies the archived reset-and-read phase-basis convergence values;
- `scripts/run_checks.py` provides a single entry point for the core checks;
- `scripts/release_gate.py` enforces the public-text gate;
- `docs/Supplementary_Information_release_ready.docx` is the release-ready Supplementary Information.

The working Colab notebook is not part of the public repository because it contains obsolete intermediate branches. Standalone scripts in `scripts/` are the reproducibility source of record.
