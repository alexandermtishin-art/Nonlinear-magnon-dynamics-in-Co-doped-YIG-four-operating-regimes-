"""
=============================================================================
REGIME IV -- corrected protocol v9d, persistent self-copy + auto-recovery Colab version
=============================================================================
Physics/numerics retained from v8:
- absolute trajectory time in the resonant pair-pump phase;
- final Fock probabilities from |psi|^2;
- N=550 thermal-start segmented mcsolve for Regime IV;
- COMPUTE_SIGMA=False by default for the corrected P0+P1 revalidation.

v9d STORAGE/REPRODUCIBILITY SAFETY:
- mounts Google Drive at a dedicated fresh mountpoint, avoiding any stale/nonempty /content/drive collision;
- migrates the four recovered v8 checkpoint files into the persistent Drive folder if needed;
- performs a write/read persistence probe on Drive;
- checks that the recovered batch0 and batch1 are present before continuing;
- saves immutable segment-numbered state files and atomically commits the
  progress JSON that points to the corresponding state. A disconnect can
  therefore lose at most the currently running segment, never desynchronize
  state and progress;
- writes batch JSON and final summary atomically and verifies them by reading
  them back before deleting per-trajectory checkpoint files;
- uses deterministic SHA-256-derived seeds for all NEW/restarted segments,
  avoiding Python's process-randomized hash() seeds;
- records and checks a run-config file so a checkpoint cannot silently be
  resumed with incompatible physical/numerical parameters.

CURRENT RECOVERY MODE:
The script expects the already-restored v8 checkpoint directory
  <dedicated Drive mount>/MyDrive/regime4_checkpoints_v8_absphase
with at least regimeIV_phi0_batch0.json and regimeIV_phi0_batch1.json.
It will load those, resume traj2 from its saved progress/state, then continue
through TOTAL_TRAJ=8. Set REQUIRE_EXISTING_BATCH01=False only for a deliberate
fresh campaign in a new checkpoint folder.
=============================================================================
"""

import json
import os
import time
import hashlib
import sys
import subprocess
import shutil
import zipfile
from pathlib import Path

import numpy as np

# ---------------------------------------------------------------------------
# DEDICATED GOOGLE DRIVE MOUNT
# ---------------------------------------------------------------------------
# We deliberately DO NOT use /content/drive here. That path may already
# contain stale local files from an earlier failed Colab session, which makes
# drive.mount() refuse to mount. Instead we try dedicated mountpoints.

def mount_google_drive_dedicated():
    try:
        from google.colab import drive
    except ImportError as e:
        raise RuntimeError(
            "STOP: this recovery script is intended to run in Google Colab."
        ) from e

    candidates = [
        Path("/content/gdrive_regime4_persistent"),
        Path("/content/gdrive_regime4_persistent_2"),
        Path("/content/gdrive_regime4_persistent_3"),
    ]

    last_error = None
    for mountpoint in candidates:
        # If a previous successful mount in this SAME runtime is still visible,
        # use it directly. The Drive folder itself is the important check.
        if (mountpoint / "MyDrive").is_dir():
            print(f"✓ Using existing Drive mount: {mountpoint}")
            return mountpoint

        # Never delete a nonempty stale mountpoint. Try the next clean name.
        if mountpoint.exists():
            try:
                nonempty = any(mountpoint.iterdir())
            except Exception:
                nonempty = True
            if nonempty:
                print(f"! Skipping nonempty stale mountpoint: {mountpoint}")
                continue

        try:
            drive.mount(str(mountpoint), force_remount=False)
            mydrive = mountpoint / "MyDrive"
            if not mydrive.is_dir():
                raise RuntimeError(
                    f"Drive mount returned but {mydrive} is missing."
                )
            print(f"✓ Google Drive mounted persistently at: {mountpoint}")
            return mountpoint
        except Exception as e:
            last_error = e
            print(f"! Could not use mountpoint {mountpoint}: {type(e).__name__}: {e}")

    raise RuntimeError(
        "STOP: could not mount Google Drive at any dedicated mountpoint. "
        "No calculation has started."
    ) from last_error


DRIVE_MOUNT = mount_google_drive_dedicated()
DRIVE_ROOT = DRIVE_MOUNT / "MyDrive"

# Make a fresh Colab runtime self-contained.
try:
    from qutip import destroy, thermal_dm, mesolve, mcsolve, basis, qsave, qload
except ImportError:
    print("QuTiP not found; installing it once for this Colab runtime...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "qutip", "-q"])
    from qutip import destroy, thermal_dm, mesolve, mcsolve, basis, qsave, qload

# ---------------------------------------------------------------------------
# CONFIG -- edit these
# ---------------------------------------------------------------------------
REGIME = "IV"
CHECKPOINT_DIR = DRIVE_ROOT / "regime4_checkpoints_v8_absphase"
TOTAL_TRAJ = 8

# Persist THIS script itself on Google Drive so a Colab runtime restart cannot
# delete the only runnable copy. This does not alter the physics or checkpoints.
PERSISTENT_SCRIPT_NAME = "regime_IV_corrected_protocol_v9d_persistent_selfcopy.py"
PERSISTENT_SCRIPT_PATH = CHECKPOINT_DIR / PERSISTENT_SCRIPT_NAME

def persist_this_script_copy():
    CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)
    candidates = sorted(Path("/content").glob("regime_IV_corrected_protocol_v9d_persistent_selfcopy*.py"))
    if not candidates:
        # If running from the already-persistent copy after a restart, nothing to copy.
        if PERSISTENT_SCRIPT_PATH.exists():
            print(f"✓ Persistent script already present: {PERSISTENT_SCRIPT_PATH}")
            return
        print("! Could not find a local v9d script copy to persist; calculation can continue, but keep a backup.")
        return
    src = candidates[-1]
    if src.resolve() != PERSISTENT_SCRIPT_PATH.resolve():
        shutil.copy2(src, PERSISTENT_SCRIPT_PATH)
    if not PERSISTENT_SCRIPT_PATH.exists() or PERSISTENT_SCRIPT_PATH.stat().st_size == 0:
        raise RuntimeError("STOP: failed to persist the v9d script itself to Google Drive.")
    print(f"✓ Script itself saved persistently: {PERSISTENT_SCRIPT_PATH}")

persist_this_script_copy()

# Safety: for THIS recovered campaign, do not allow an accidental blank-folder
# start. Once this campaign is complete, leave it True; batch0/batch1 remain.
REQUIRE_EXISTING_BATCH01 = True
BASE_SEED = 26091801
RUN_CONFIG_NAME = "regimeIV_v9_run_config.json"
PERSISTENCE_MARKER_NAME = ".regimeIV_v9_persistent_drive_verified"

COMPUTE_SIGMA = False  # default: only revalidate P0+P1; see module note
PHASE_SAMPLES_PER_PUMP = 8
SEGMENT_KAPPA_T = 0.1     # lowered from 0.5 after testing: kappa*t=0.5 (tmax=250)
                          # triggered QuTiP's "could not find the collapse time"
                          # error at N=550 for some states; kappa*t=0.1 (tmax=50)
                          # was verified to succeed on the same state/seed that
                          # failed at 0.5. This also means checkpoints land
                          # roughly every ~80s of compute, not every ~12 min.
MIN_SEGMENT_KAPPA_T = 0.01  # floor for the auto-retry-with-shorter-segment
                            # fallback below, in case 0.1 itself occasionally fails
MESOLVE_N_CUTOFF = 100

print(f"CPU cores visible to this process: {os.cpu_count()}")

# ---------------------------------------------------------------------------
# PHYSICAL CONSTANTS AND MODEL (unchanged from v4/v5)
# ---------------------------------------------------------------------------
HBAR = 1.054571817e-34
KB = 1.380649e-23

OMEGA = 1.0
U_AUDIT = 0.55
ETA = 1.2
ALPHA = 1.0e-3
KAPPA = 2.0 * ALPHA * OMEGA

KAPPA_T_TARGET = 3.0
TMAX = KAPPA_T_TARGET / KAPPA
SEGMENT_TIME = SEGMENT_KAPPA_T / KAPPA   # normalized time per segment

REGIME_TABLE = {
    "I":   dict(freq_hz=50e9,  T_K=4.0,   N=25),
    "II":  dict(freq_hz=50e9,  T_K=77.0,  N=220),
    "III": dict(freq_hz=6e12,  T_K=310.0, N=25),
    "IV":  dict(freq_hz=50e9,  T_K=310.0, N=550),
}


def _migrate_recovered_v8_files_if_needed():
    """
    One-time recovery helper. If the persistent Drive folder does not yet
    contain batch0/batch1, recover the four known-good v8 files from either:
      1) the old /content/drive path,
      2) the already-extracted /content/restore_regime4 folder, or
      3) the uploaded regime4_checkpoints_v8_absphase*.zip itself.
    The DESTINATION is the confirmed dedicated Google Drive mount.
    """
    required_names = [
        "regimeIV_phi0_batch0.json",
        "regimeIV_phi0_batch1.json",
        "regimeIV_phi0_traj2_progress.json",
        "regimeIV_phi0_traj2_state.qu",
    ]
    if all((CHECKPOINT_DIR / n).exists() for n in required_names[:2]):
        return

    source_candidates = [
        Path("/content/drive/MyDrive/regime4_checkpoints_v8_absphase"),
        Path("/content/restore_regime4/regime4_checkpoints_v8_absphase"),
    ]

    for srcdir in source_candidates:
        try:
            ok = srcdir.is_dir() and all((srcdir / n).exists() for n in required_names)
        except OSError:
            ok = False
        if not ok:
            continue

        print(f"✓ Found recovered v8 checkpoint source: {srcdir}")
        for name in required_names:
            src = srcdir / name
            dst = CHECKPOINT_DIR / name
            if not dst.exists():
                shutil.copy2(src, dst)
                print(f"    migrated to persistent Drive: {name}")
        return

    # Final automatic fallback: recover directly from the uploaded ZIP.
    zips = sorted(Path("/content").glob("regime4_checkpoints_v8_absphase*.zip"))
    for zpath in reversed(zips):
        try:
            with zipfile.ZipFile(zpath, "r") as zf:
                names = zf.namelist()
                chosen = {}
                for req in required_names:
                    matches = [n for n in names if n.endswith("/" + req) or n == req]
                    if not matches:
                        chosen = {}
                        break
                    chosen[req] = matches[0]
                if len(chosen) != len(required_names):
                    continue

                print(f"✓ Recovering v8 checkpoint directly from ZIP: {zpath.name}")
                for req, member in chosen.items():
                    dst = CHECKPOINT_DIR / req
                    if not dst.exists():
                        data = zf.read(member)
                        with open(dst, "wb") as f:
                            f.write(data)
                            f.flush()
                            try:
                                os.fsync(f.fileno())
                            except OSError:
                                pass
                        print(f"    recovered to persistent Drive: {req}")
                return
        except zipfile.BadZipFile:
            continue


def verify_persistent_drive():
    # DRIVE_MOUNT was returned only after google.colab.drive.mount succeeded
    # (or an already-live dedicated mount from this runtime was detected).
    if not DRIVE_ROOT.is_dir():
        raise RuntimeError(f"STOP: mounted Drive root is missing: {DRIVE_ROOT}")

    CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)

    # Real write/read probe in the dedicated mounted Drive.
    probe = CHECKPOINT_DIR / ".regime4_persistence_probe"
    token = f"{time.time_ns()}-{os.getpid()}"
    with open(probe, "w") as f:
        f.write(token)
        f.flush()
        try:
            os.fsync(f.fileno())
        except OSError:
            pass
    if probe.read_text() != token:
        raise RuntimeError("STOP: Google Drive write/read persistence probe failed.")
    probe.unlink(missing_ok=True)

    # If this is the first safe run, migrate the recovered v8 files from the
    # old /content/drive or restore folder into the confirmed persistent Drive.
    _migrate_recovered_v8_files_if_needed()

    marker = CHECKPOINT_DIR / PERSISTENCE_MARKER_NAME
    marker.write_text(
        f"verified persistent Google Drive checkpoint directory\nmount={DRIVE_MOUNT}\n"
    )
    # Read back marker too.
    if "verified persistent Google Drive" not in marker.read_text():
        raise RuntimeError("STOP: persistence marker readback failed.")

    print(f"✓ Persistent Google Drive verified: {DRIVE_ROOT}")
    print(f"✓ Checkpoint directory: {CHECKPOINT_DIR}")

def atomic_write_json(path: Path, obj, indent=None):
    """Write JSON via temp file + replace, then read it back to verify."""
    path = Path(path)
    tmp = path.with_name(path.name + ".tmp")
    with open(tmp, "w") as f:
        json.dump(obj, f, indent=indent)
        f.flush()
        try:
            os.fsync(f.fileno())
        except OSError:
            pass
    os.replace(tmp, path)
    with open(path) as f:
        check = json.load(f)
    return check


def stable_seed(tag: str, traj_i: int) -> int:
    """Stable across Colab/Python restarts; unlike built-in hash()."""
    payload = f"{BASE_SEED}|{tag}|{traj_i}".encode("utf-8")
    digest = hashlib.sha256(payload).digest()
    return int.from_bytes(digest[:8], "big") % (2**31 - 1)


def expected_run_config():
    cfg = REGIME_TABLE[REGIME]
    return {
        "version": "v9c_dedicated_mount_auto_recovery",
        "regime": REGIME,
        "freq_hz": cfg["freq_hz"],
        "T_K": cfg["T_K"],
        "N": cfg["N"],
        "OMEGA": OMEGA,
        "U_AUDIT": U_AUDIT,
        "ETA": ETA,
        "ALPHA": ALPHA,
        "KAPPA": KAPPA,
        "KAPPA_T_TARGET": KAPPA_T_TARGET,
        "SEGMENT_KAPPA_T": SEGMENT_KAPPA_T,
        "TOTAL_TRAJ": TOTAL_TRAJ,
        "COMPUTE_SIGMA": COMPUTE_SIGMA,
        "BASE_SEED": BASE_SEED,
    }


def verify_or_create_run_config():
    p = CHECKPOINT_DIR / RUN_CONFIG_NAME
    expected = expected_run_config()
    if p.exists():
        with open(p) as f:
            old = json.load(f)
        if old != expected:
            raise RuntimeError(
                "STOP: checkpoint run-config does not match this script.\n"
                f"Stored: {old}\nCurrent: {expected}"
            )
        print(f"✓ Run configuration matches: {p.name}")
    else:
        atomic_write_json(p, expected, indent=2)
        print(f"✓ Run configuration recorded: {p.name}")


def verify_recovered_campaign_guard(tag="regimeIV_phi0"):
    """Prevent an accidental fresh run in the wrong/empty Drive folder."""
    if not REQUIRE_EXISTING_BATCH01:
        return
    required = [
        CHECKPOINT_DIR / f"{tag}_batch0.json",
        CHECKPOINT_DIR / f"{tag}_batch1.json",
    ]
    missing = [p.name for p in required if not p.exists()]
    if missing:
        raise RuntimeError(
            "STOP: recovered campaign guard failed. Missing: " + ", ".join(missing) +
            "\nThis usually means the wrong Drive/folder is mounted. "
            "The script will NOT start trajectory 0 from scratch."
        )
    print("✓ Recovery guard passed: batch0 and batch1 are present.")


def print_checkpoint_inventory():
    print("✓ Existing checkpoint files:")
    for p in sorted(CHECKPOINT_DIR.iterdir()):
        print("   ", p.name)

MESOLVE_OPTS = {
    "method": "adams", "nsteps": 1_000_000, "atol": 1e-8, "rtol": 1e-6,
    "progress_bar": False, "store_final_state": True,
}
MCSOLVE_OPTS = {
    "nsteps": 500_000, "atol": 1e-7, "rtol": 1e-5,
    "progress_bar": "text",
    "store_final_state": True,
    "map": "serial",
    # Collapse-time (quantum jump) root-finding options. QuTiP's default
    # norm_steps is small and can run out of bisection iterations at large
    # N before it brackets the jump time tightly enough, raising "Could not
    # find the collapse time within desired tolerance" -- this was hit at
    # N=550 even after halving the segment length repeatedly, which points
    # to a tolerance problem, not a step-size problem. Loosened here per the
    # error message's own suggestion.
    "norm_steps": 200,
    "norm_tol": 1e-3,
    "norm_t_tol": 1e-6,
}
# Used once, only if a segment still fails even with the options above --
# substantially more permissive, at the cost of jump-time precision.
MCSOLVE_OPTS_FALLBACK = dict(MCSOLVE_OPTS)
MCSOLVE_OPTS_FALLBACK.update({"norm_steps": 2000, "norm_tol": 1e-2, "norm_t_tol": 1e-4})


def thermal_occupation(freq_hz: float, T_K: float) -> float:
    if T_K <= 0.0:
        return 0.0
    x = HBAR * 2.0 * np.pi * freq_hz / (KB * T_K)
    return 1.0 / np.expm1(x)


def thermal_tail(n_th: float, N: int) -> float:
    if n_th <= 0:
        return 0.0
    return (n_th / (1.0 + n_th)) ** N


class PairCoeff:
    def __init__(self, phi_d: float, t_origin: float = 0.0):
        self.phi_d = phi_d
        self.t_origin = float(t_origin)

    def __call__(self, t, args=None):
        # CRITICAL: t supplied by mcsolve is local to the current segment.
        # The physical resonant pump must remain continuous across checkpoints.
        t_abs = t + self.t_origin
        return 0.5 * ETA * OMEGA * np.sin(2.0 * OMEGA * t_abs + self.phi_d)


def build_operators(N: int):
    a = destroy(N)
    ad = a.dag()
    n_op = ad * a
    H0 = OMEGA * n_op + 0.5 * U_AUDIT * OMEGA * ad * ad * a * a
    pair = ad * ad + a * a
    return a, ad, n_op, H0, pair


def collapse_operators(a, ad, n_th: float):
    c_ops = [np.sqrt(KAPPA * (n_th + 1.0)) * a]
    if n_th > 0.0:
        c_ops.append(np.sqrt(KAPPA * n_th) * ad)
    return c_ops


def sample_thermal_fock(N: int, n_th: float, rng) -> int:
    x = n_th / (1.0 + n_th) if n_th > 0 else 0.0
    probs = (1.0 - x) * x ** np.arange(N)
    probs = probs / probs.sum()
    return int(rng.choice(N, p=probs))


def solve_segment_robust(H0, pair, phi_d, psi, c_ops, n_op, a, seg_time, seed,
                          depth=0, t_offset=0.0):
    """
    Run mcsolve for one segment of length seg_time starting from psi.
    QuTiP's stochastic collapse-time bisection occasionally fails to
    converge ("Could not find the collapse time within desired tolerance")
    on long single calls at large N; this was verified locally to be tied
    to segment length, not to the specific state or random seed (the same
    state/seed that failed at kappa*t=0.5 succeeded at kappa*t=0.1). As a
    safety net beyond the lowered default segment length, if a segment
    still fails, this recursively retries it as two half-length segments
    (down to MIN_SEGMENT_KAPPA_T), which costs a little overhead only on
    the rare segment that needs it, rather than failing the whole run.
    t_offset is the absolute (trajectory-start-relative) time at the start
    of this segment. It is used BOTH to keep the resonant pump phase continuous
    across segments and to return absolute sample times for phase analysis.
    Returns (mean_n_values, pair_re_values, pair_im_values, t_values, final_ket).
    """
    if COMPUTE_SIGMA:
        pump_period = np.pi / OMEGA
        dt_out = pump_period / PHASE_SAMPLES_PER_PUMP
        n_pts = max(3, int(np.ceil(seg_time / dt_out)) + 1)
        e_ops = [n_op, a * a]
    else:
        # Final P0+P1 is obtained from the final ket; a light output grid is
        # sufficient for the auxiliary late-time <n> estimate.
        n_pts = max(5, int(seg_time / 25))
        e_ops = [n_op]
    tlist = np.linspace(0.0, seg_time, n_pts)

    def _try(options):
        result = mcsolve([H0, [pair, PairCoeff(phi_d, t_origin=t_offset)]], psi, tlist,
                          c_ops=c_ops, e_ops=e_ops, ntraj=1,
                          seeds=int(seed), options=options)
        psi_next = extract_ket(result.final_state, psi.shape[0])
        mean_n = np.real(np.asarray(result.expect[0])).tolist()
        if COMPUTE_SIGMA:
            pair_c = np.asarray(result.expect[1], dtype=complex)
            pair_re = pair_c.real.tolist()
            pair_im = pair_c.imag.tolist()
        else:
            pair_re = []
            pair_im = []
        t_vals = (tlist + t_offset).tolist()
        return mean_n, pair_re, pair_im, t_vals, psi_next

    try:
        return _try(MCSOLVE_OPTS)
    except RuntimeError as e:
        if "collapse time" not in str(e):
            raise
        # Tier 1: same segment length, much more permissive jump-time
        # tolerance. This alone resolved the failure in local testing.
        try:
            print(f"    [retry] segment of kappa*t={seg_time*KAPPA:.3f} hit the "
                  f"collapse-time tolerance; retrying same length with "
                  f"looser norm tolerance")
            return _try(MCSOLVE_OPTS_FALLBACK)
        except RuntimeError as e2:
            if "collapse time" not in str(e2):
                raise
            # Tier 2: still failing -- fall back to halving the segment,
            # which at least changes the numerics enough to sometimes help,
            # even though tolerance (not segment length) was the root cause.
            half_kappa_t = (seg_time * KAPPA) / 2.0
            if half_kappa_t < MIN_SEGMENT_KAPPA_T:
                raise
            print(f"    [retry] looser tolerance still failed; retrying as "
                  f"two halves of kappa*t={half_kappa_t:.3f} each")
            mn1, pr1, pi1, t1, psi_mid = solve_segment_robust(
                H0, pair, phi_d, psi, c_ops, n_op, a, seg_time / 2.0, seed * 2,
                depth + 1, t_offset=t_offset)
            mn2, pr2, pi2, t2, psi_final = solve_segment_robust(
                H0, pair, phi_d, psi_mid, c_ops, n_op, a, seg_time / 2.0, seed * 2 + 1,
                depth + 1, t_offset=t_offset + seg_time / 2.0)
            return mn1 + mn2, pr1 + pr2, pi1 + pi2, t1 + t2, psi_final


def extract_ket(final_state, N: int):
    """Return a normalized ket from mcsolve's final state.
    QuTiP versions may return either a ket directly or a rank-1 projector."""
    if getattr(final_state, "isket", False):
        return final_state.unit()
    if getattr(final_state, "isoper", False):
        evals, ekets = final_state.eigenstates(eigvals=1, sort="high")
        return ekets[0].unit()
    raise TypeError(f"Unsupported mcsolve final_state type: {getattr(final_state, 'type', type(final_state))}")


# --------------------------- exact path (small N, unchanged) ---------------

def run_exact(N: int, n_th: float, phi_d: float, tmax: float):
    a, ad, n_op, H0, pair = build_operators(N)
    c_ops = collapse_operators(a, ad, n_th)
    rho0 = thermal_dm(N, n_th)
    tlist = np.linspace(0.0, tmax, max(50, int(tmax * 2)))
    t0 = time.time()
    result = mesolve([H0, [pair, PairCoeff(phi_d, t_origin=0.0)]], rho0, tlist,
                      c_ops=c_ops, e_ops=[n_op, a * a], options=MESOLVE_OPTS)
    runtime = time.time() - t0
    pops = np.real(np.diag(result.final_state.full()))
    pops = np.maximum(pops, 0.0); pops /= pops.sum()
    mean_n = np.real(np.asarray(result.expect[0]))
    return {
        "P0": float(pops[0]), "P1": float(pops[1]),
        "P0_plus_P1": float(pops[0] + pops[1]),
        "mean_n_late": float(mean_n[len(mean_n) * 2 // 3:].mean()),
        "n_traj": 1, "method": "mesolve", "runtime_s": runtime,
    }


# ---------------------- segmented single-trajectory mcsolve ----------------

def _checkpoint_state_candidates(traj_tag: str):
    return sorted(CHECKPOINT_DIR.glob(f"{traj_tag}_state_seg*.qu"))


def _load_checkpoint_state(traj_tag: str, progress: dict):
    # v9 progress explicitly names the immutable state committed with it.
    state_name = progress.get("state_file")
    if state_name:
        state_file = CHECKPOINT_DIR / state_name
        if not state_file.exists():
            raise RuntimeError(
                f"STOP: progress points to missing state file: {state_file}"
            )
        base = str(state_file)[:-3] if str(state_file).endswith('.qu') else str(state_file)
        return qload(base), state_file

    # Legacy v8 checkpoint recovered from the archive.
    legacy_base = CHECKPOINT_DIR / f"{traj_tag}_state"
    legacy_file = Path(str(legacy_base) + ".qu")
    if not legacy_file.exists():
        raise RuntimeError(
            f"STOP: progress exists for {traj_tag}, but no matching state file exists."
        )
    return qload(str(legacy_base)), legacy_file


def _save_segment_checkpoint(traj_tag: str, psi, progress: dict):
    """
    Commit protocol:
      1) save immutable state for this completed segment;
      2) verify it can be loaded;
      3) atomically replace progress.json pointing to that exact state.
    Therefore progress.json is the commit marker. A crash before step 3 leaves
    the previous progress/state pair valid and merely causes one segment to be
    recomputed.
    """
    segs_done = int(progress["segs_done"])
    progress_path = CHECKPOINT_DIR / f"{traj_tag}_progress.json"

    final_state_file = CHECKPOINT_DIR / f"{traj_tag}_state_seg{segs_done:03d}.qu"
    tmp_base = CHECKPOINT_DIR / f"{traj_tag}_state_seg{segs_done:03d}.tmp"
    tmp_file = Path(str(tmp_base) + ".qu")
    tmp_file.unlink(missing_ok=True)

    qsave(psi, str(tmp_base))
    if not tmp_file.exists():
        raise RuntimeError(f"STOP: qsave did not create {tmp_file}")

    # Verify the saved state BEFORE making progress point to it.
    psi_check = qload(str(tmp_base))
    if psi_check.shape != psi.shape:
        raise RuntimeError("STOP: saved checkpoint state failed shape verification.")

    os.replace(tmp_file, final_state_file)

    committed = dict(progress)
    committed["state_file"] = final_state_file.name
    check = atomic_write_json(progress_path, committed)

    if int(check.get("segs_done", -1)) != segs_done:
        raise RuntimeError("STOP: checkpoint progress readback failed.")
    if check.get("state_file") != final_state_file.name:
        raise RuntimeError("STOP: checkpoint state/progress linkage failed.")

    # Verify the final referenced state is readable at its final Drive path.
    qload(str(final_state_file)[:-3])
    print(f"    ✓ checkpoint safely committed on Drive: {segs_done}/{int(np.ceil(TMAX / SEGMENT_TIME))}")

    # Keep the referenced state and at most one previous version. Unreferenced
    # newer temp/orphan states are harmless; remove very old versions.
    states = _checkpoint_state_candidates(traj_tag)
    keep = set(states[-2:])
    for p in states:
        if p not in keep:
            try:
                p.unlink()
            except Exception:
                pass


def _cleanup_trajectory_checkpoints(traj_tag: str):
    progress_path = CHECKPOINT_DIR / f"{traj_tag}_progress.json"
    progress_path.unlink(missing_ok=True)
    legacy_file = CHECKPOINT_DIR / f"{traj_tag}_state.qu"
    legacy_file.unlink(missing_ok=True)
    for p in CHECKPOINT_DIR.glob(f"{traj_tag}_state_seg*.qu"):
        p.unlink(missing_ok=True)
    for p in CHECKPOINT_DIR.glob(f"{traj_tag}_state_seg*.tmp.qu"):
        p.unlink(missing_ok=True)


def run_one_trajectory_segmented(N: int, n_th: float, phi_d: float,
                                  tmax_total: float, traj_tag: str, seed: int):
    """
    Run ONE trajectory in SEGMENT_TIME-sized chunks. Resume from the last
    atomically committed segment. This function deliberately DOES NOT delete
    checkpoint files at completion; the caller deletes them only after the
    final batch JSON has been safely written and verified.
    """
    progress_path = CHECKPOINT_DIR / f"{traj_tag}_progress.json"

    a, ad, n_op, H0, pair = build_operators(N)
    c_ops = collapse_operators(a, ad, n_th)
    n_segments = int(np.ceil(tmax_total / SEGMENT_TIME))

    if progress_path.exists():
        with open(progress_path) as f:
            progress = json.load(f)
        psi, state_file = _load_checkpoint_state(traj_tag, progress)
        segs_done = int(progress["segs_done"])
        if not (0 <= segs_done <= n_segments):
            raise RuntimeError(f"STOP: invalid segs_done={segs_done} for {traj_tag}")
        if psi.shape[0] != N:
            raise RuntimeError(
                f"STOP: checkpoint Hilbert dimension {psi.shape[0]} != expected N={N}"
            )
        print(f"  [{traj_tag}] resuming from segment {segs_done}/{n_segments}")
        print(f"  [{traj_tag}] state file: {state_file.name}")
    else:
        rng = np.random.default_rng(seed)
        n0 = sample_thermal_fock(N, n_th, rng)
        psi = basis(N, n0)
        progress = {
            "segs_done": 0,
            "n0": n0,
            "mean_n": [],
            "pair_re": [],
            "pair_im": [],
            "t": [],
            "seed_base": int(seed),
        }
        segs_done = 0
        print(f"  [{traj_tag}] NEW trajectory, deterministic seed={seed}, n0={n0}")

    t_traj_start = time.time()
    for seg in range(segs_done, n_segments):
        this_len = min(SEGMENT_TIME, tmax_total - seg * SEGMENT_TIME)
        seg_t_offset = seg * SEGMENT_TIME

        t0 = time.time()
        mean_n_seg, pair_re_seg, pair_im_seg, t_seg, psi = solve_segment_robust(
            H0, pair, phi_d, psi, c_ops, n_op, a, this_len, int(seed + seg),
            t_offset=seg_t_offset)
        seg_runtime = time.time() - t0

        progress["mean_n"].extend(mean_n_seg)
        progress["pair_re"].extend(pair_re_seg)
        progress["pair_im"].extend(pair_im_seg)
        progress["t"].extend(t_seg)
        progress["segs_done"] = seg + 1

        _save_segment_checkpoint(traj_tag, psi, progress)

        print(f"  [{traj_tag}] segment {seg+1}/{n_segments} done in "
              f"{seg_runtime:.1f}s (kappa*t so far = {(seg+1)*SEGMENT_KAPPA_T:.2f}, "
              f"traj elapsed {time.time()-t_traj_start:.0f}s)")

    mean_n_full = np.array(progress["mean_n"])
    if len(mean_n_full) == 0:
        raise RuntimeError("STOP: completed trajectory has empty mean_n history.")
    mean_n_late = mean_n_full[len(mean_n_full) * 2 // 3:]

    final_probs = np.abs(psi.full().ravel()) ** 2
    final_probs = np.maximum(final_probs, 0.0)
    total = final_probs.sum()
    if total <= 0:
        raise RuntimeError("STOP: final state probabilities have zero norm.")
    final_probs /= total

    out = {
        "n0_sampled": progress["n0"],
        "n_traj": 1,
        "P0": float(final_probs[0]),
        "P1": float(final_probs[1]),
        "P0_plus_P1": float(final_probs[0] + final_probs[1]),
        "mean_n_late": float(mean_n_late.mean()),
        "t": progress["t"],
        "pair_re": progress["pair_re"],
        "pair_im": progress["pair_im"],
        "seed_base": int(seed),
        "checkpoint_version": "v9c_dedicated_mount_auto_recovery",
    }
    return out


def _unique_sorted_series(t, z):
    """Sort one trajectory's samples and average duplicate time stamps."""
    t = np.asarray(t, dtype=float)
    z = np.asarray(z, dtype=complex)
    order = np.argsort(t)
    t = t[order]
    z = z[order]
    uniq, inv = np.unique(t, return_inverse=True)
    if len(uniq) == len(t):
        return t, z
    acc = np.zeros(len(uniq), dtype=complex)
    cnt = np.zeros(len(uniq), dtype=float)
    np.add.at(acc, inv, z)
    np.add.at(cnt, inv, 1.0)
    return uniq, acc / cnt


def compute_sigma_deg(batches, tmax_total):
    """
    Ensemble-average <aa>(t) after interpolating every trajectory onto one
    common ABSOLUTE-time grid. This remains valid if recursive retry splitting
    created different native output grids in different trajectories.
    """
    if not COMPUTE_SIGMA:
        return None
    if any(("t" not in b or "pair_re" not in b or "pair_im" not in b) for b in batches):
        return None
    if any(len(b["pair_re"]) == 0 for b in batches):
        return None

    pump_period = np.pi / OMEGA
    dt = pump_period / PHASE_SAMPLES_PER_PUMP
    common_t = np.arange(0.0, tmax_total + 0.5 * dt, dt)

    interp_pairs = []
    for b in batches:
        t = np.asarray(b["t"], dtype=float)
        z = np.asarray(b["pair_re"], dtype=float) + 1j * np.asarray(b["pair_im"], dtype=float)
        t, z = _unique_sorted_series(t, z)
        re_i = np.interp(common_t, t, z.real)
        im_i = np.interp(common_t, t, z.imag)
        interp_pairs.append(re_i + 1j * im_i)

    ens_pair = np.mean(np.asarray(interp_pairs), axis=0)
    phi_pair = np.angle(ens_pair) + 2.0 * OMEGA * common_t
    late_mask = common_t >= (tmax_total * 2.0 / 3.0)
    theta = phi_pair[late_mask]
    if len(theta) < 2:
        return None
    R = np.abs(np.mean(np.exp(1j * theta)))
    R = np.clip(R, 1e-15, 1.0 - 1e-12)
    return float(np.degrees(np.sqrt(-2.0 * np.log(R))))

def run_trajectories_for_phase(N: int, n_th: float, phi_d: float, tmax: float,
                                total_traj: int, tag: str):
    batches = []
    for i in range(total_traj):
        batch_path = CHECKPOINT_DIR / f"{tag}_batch{i}.json"
        if batch_path.exists():
            with open(batch_path) as f:
                b = json.load(f)
            # Minimal integrity check before trusting a finished trajectory.
            for key in ("P0", "P1", "P0_plus_P1", "mean_n_late", "n_traj"):
                if key not in b:
                    raise RuntimeError(f"STOP: {batch_path.name} is missing key {key}")
            print(f"  [{tag}] trajectory {i} (1 traj): loaded from checkpoint")
        else:
            traj_tag = f"{tag}_traj{i}"
            seed = stable_seed(tag, i)
            b = run_one_trajectory_segmented(
                N, n_th, phi_d, tmax, traj_tag, seed=seed
            )

            # CRITICAL ORDER: batch first, verify readback, only then delete the
            # resumable per-segment state/progress files.
            b_check = atomic_write_json(batch_path, b)
            if abs(float(b_check["P0_plus_P1"]) - float(b["P0_plus_P1"])) > 1e-15:
                raise RuntimeError(f"STOP: batch readback verification failed: {batch_path}")
            print(f"    ✓ final batch safely committed on Drive: {batch_path.name}")
            _cleanup_trajectory_checkpoints(traj_tag)

            print(f"  [{tag}] trajectory {i} done -> "
                  f"P0+P1={b['P0_plus_P1']:.10e}, "
                  f"<n>_late={b['mean_n_late']:.6f}")
        batches.append(b)

        w = np.array([bb["n_traj"] for bb in batches], dtype=float)
        p0_run = np.average([bb["P0"] for bb in batches], weights=w)
        p1_run = np.average([bb["P1"] for bb in batches], weights=w)
        p01_per = np.array([bb["P0_plus_P1"] for bb in batches], dtype=float)
        spread = p01_per.std(ddof=0) if len(batches) > 1 else float("nan")
        sem = (p01_per.std(ddof=1) / np.sqrt(len(p01_per))) if len(p01_per) > 1 else float("nan")
        print(f"  [{tag}] running total: {int(w.sum())} traj, "
              f"P0+P1={p0_run+p1_run:.10e}, "
              f"population SD={spread:.3e}, SEM={sem:.3e}")

    w = np.array([b["n_traj"] for b in batches], dtype=float)
    p0 = np.average([b["P0"] for b in batches], weights=w)
    p1 = np.average([b["P1"] for b in batches], weights=w)
    mean_n = np.average([b["mean_n_late"] for b in batches], weights=w)
    p01_per = np.array([b["P0_plus_P1"] for b in batches], dtype=float)
    sigma_deg = compute_sigma_deg(batches, tmax)

    if sigma_deg is not None:
        print(f"  [{tag}] sigma (circular std, ensemble over {int(w.sum())} "
              f"trajectories) = {sigma_deg:.2f} deg")
    elif COMPUTE_SIGMA:
        print(f"  [{tag}] sigma could not be computed because one or more "
              f"batch files lack t/pair_re/pair_im histories.")

    sample_sd = float(p01_per.std(ddof=1)) if len(p01_per) > 1 else None
    sem = float(sample_sd / np.sqrt(len(p01_per))) if sample_sd is not None else None

    return {
        "n_traj_total": int(w.sum()),
        "P0": float(p0),
        "P1": float(p1),
        "P0_plus_P1": float(p0 + p1),
        "mean_n_late": float(mean_n),
        "cross_batch_population_sd": float(p01_per.std(ddof=0)) if len(batches) > 1 else None,
        "sample_sd_P0_plus_P1": sample_sd,
        "sem_P0_plus_P1": sem,
        "sigma_deg": sigma_deg,
        "method": "mcsolve-segmented-v9c-dedicated-mount-auto-recovery",
    }


def main():
    # Nothing computational is allowed before these three checks pass.
    verify_persistent_drive()
    verify_recovered_campaign_guard(tag=f"regime{REGIME}_phi0")
    verify_or_create_run_config()
    print_checkpoint_inventory()

    cfg = REGIME_TABLE[REGIME]
    n_th = thermal_occupation(cfg["freq_hz"], cfg["T_K"])
    N = cfg["N"]
    tail = thermal_tail(n_th, N)
    use_mcsolve = N > MESOLVE_N_CUTOFF

    n_segments = int(np.ceil(TMAX / SEGMENT_TIME))
    print("=" * 79)
    print(f"REGIME {REGIME}: T={cfg['T_K']} K, f={cfg['freq_hz']/1e9:.3g} GHz, "
          f"n_th={n_th:.4f}, N={N}")
    print(f"thermal-only tail bound P(n>=N) = {tail:.2e}")
    print(f"COMPUTE_SIGMA = {COMPUTE_SIGMA}")
    print(f"Method: {'segmented mcsolve (' + str(n_segments) + ' segments/trajectory), target ' + str(TOTAL_TRAJ) + ' traj, phi_d=0 only' if use_mcsolve else 'exact mesolve, all 5 phases'}")
    print(f"tmax = {TMAX:.1f} (normalized units), target kappa*tmax = {KAPPA_T_TARGET}, "
          f"segment kappa*t = {SEGMENT_KAPPA_T}")
    print("=" * 79)

    tag = f"regime{REGIME}_phi0"
    print(f"\n--- phi_d = 0.0000 rad ---")
    if use_mcsolve:
        result = run_trajectories_for_phase(N, n_th, 0.0, TMAX, TOTAL_TRAJ, tag)
    else:
        result = run_exact(N, n_th, 0.0, TMAX)

    print(f"  -> P0={result['P0']:.10e} P1={result['P1']:.10e} "
          f"P0+P1={result['P0_plus_P1']:.10e}"
          + (f"  SEM={result['sem_P0_plus_P1']:.3e}"
             if result.get("sem_P0_plus_P1") is not None else "")
          + (f"  sigma={result['sigma_deg']:.2f} deg"
             if result.get("sigma_deg") is not None else ""))

    summary_path = CHECKPOINT_DIR / f"regime{REGIME}_summary.json"
    payload = {
        "regime": REGIME,
        "n_th": n_th,
        "N": N,
        "thermal_tail_bound": tail,
        "run_config": expected_run_config(),
        "result": result,
    }
    atomic_write_json(summary_path, payload, indent=2)
    print(f"\n✓ FINAL SUMMARY safely saved and verified: {summary_path}")


if __name__ == "__main__":
    main()
